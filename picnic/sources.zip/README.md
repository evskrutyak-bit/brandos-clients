# picnic — исходники проекта BrandOS

Все артефакты в Markdown (для loft — также docx/pdf первоисточников DR).
Загружай в AI-инструменты команды как контекст для работы со своим брендом.

## Что внутри

- `picnic/` — артефакты по модулям M0-M11 (структура повторяет хаб)
- `manifest.json` — метаданные пакета (slug, hub_version, generated_at, files)

## Поддержка

Хаб с интерактивной версией: https://clients.brand-os.ru/picnic/
Контакт: BrandOS · brand-os.ru
