# TASK_PACKET → Codex: HTML M3-02 «Продуктовая линейка» (verbatim build)

> От: Claude (продакшен/оркестратор Alien Cat). Дата: 2026-06-11.
> Тип: HTML-сборка модульного артефакта Нейроупаковки 2.0 (brandos-artifacts).
> Статус: owner-accepted MD готов. **Сборка — да. Деплой/hub — НЕТ** (до owner review HTML).

## Источник (единственный)
- **Source MD:** `M3-продукт/M3-02-Линейка-роли-цены/M3-02-CLIENT.md`
- **Provenance (sha256[:16]):** `9d510811b2e51d77`
- Статус MD: OWNER-ACCEPTED + CLIENT_READY (Дима, 2026-06-11; вариант Б — без материального слоя).
- Только этот файл. `_superseded/`, `_archive-hve-pilot/`, старый `M3-02-Архитектура-продукта/M3-02-CLIENT.md`, `*-DRAFT`, `*-SAMPLE` — НЕ источник.

## Что собрать
- Один клиентский HTML-артефакт по модулю M3-02 через **brandos-artifacts (builder v2)**, фаза M3 (emerald).
- **Verbatim:** текст HTML = текст MD без перефраза. HTML ≠ MD по тексту = hard blocker.
- **Hero:** 4 stat-cards строго из frontmatter `hero_stats` (value/label/desc/source). Hero = self-description документа (не предмета).
- **Hub-возврат обязателен:** toplink «К хабу клиента →» + nav-пилюля «К хабу» (единый канон, см. `feedback_hub_link_required`).
- **Имя файла — ASCII:** `M3-02-PRODUKTOVAYA-LINEYKA.html` (middle-dot/кириллица в имени запрещены).
- Структура: 5 разделов (форматы / из чего цена / выбор при заказе / сервис / что дальше). Таблиц нет — формат-карточки S/M/L/F и буллеты.

## Жёстко
- **Деплой и обновление хаба — НЕ делать.** Только локальный HTML.
- Subagent при сборке **не объявляет готовность/публикацию** — готовность объявляет Claude после independent HTML_READY-гейта.
- CSS-inject extra перед `</style>`, не replace `</head>`.
- Никакой кухни процесса в видимом тексте; язык = как в MD.

## После сборки Codex (контур приёмки)
1. Codex отдаёт WORKER_RESULT: путь к HTML + provenance, какой builder, 6-check самопроверка.
2. **Claude** — independent HTML_READY gate: verbatim против `9d510811b2e51d77`, признаки сборки v2 (компоненты, нет голых `---`, layout не плоский), hub-link present, ASCII-имя, hero = 4 карточки из MD.
3. **Owner review HTML** глазами.
4. Только после owner-accept — **отдельный go на deploy + hub** (счётчик артефактов, карточка M3-02). Independent DEPLOY_QC за Claude на live (E16).

## Контекст
- Это НОВЫЙ M3-02 = «Продуктовая линейка» (форматы/цены/сервис). Старый M3-02 «Архитектура/Изделие» — superseded (описание изделия ушло в `source/IZDELIE-ALIAN-CAT.md` как факт-файл).
- Документ внутренний по жанру, но публикуется в хаб как M-артефакт (как M3-01).
