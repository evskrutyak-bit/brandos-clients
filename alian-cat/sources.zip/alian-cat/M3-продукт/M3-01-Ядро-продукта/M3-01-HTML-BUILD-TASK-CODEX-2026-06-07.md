---
id: 2026-06-07-alian-cat-m3-01-html-verbatim
worker: Codex HTML build (verbatim render)
created_by: Claude (методчат, owner-go Дима 2026-06-07)
target: alian-cat M3-01 «Ядро продукта» v3 — клиентский HTML
expects: WORKER_RESULT + HTML + screenshots
status: done — Codex собрал HTML + (по отдельному owner-go) задеплоил; owner-accept HTML+hub; deploy fb1a307; live verified
---

> ✅ **ЗАКРЫТО 2026-06-07.** Codex выполнил verbatim build, owner принял HTML и хаб, Codex задеплоил (`fb1a307`). Live: `clients.brand-os.ru/alian-cat/M3/M3-01-YADRO-PRODUKTA.html?v=fb1a307`. Independent verifier PASS (Claude≠Codex). Этап M3-01 закрыт.

# TASK_PACKET — HTML M3-01 v3 (дословный render)

> ⚠️ **READ-ONLY ДЛЯ ИСПОЛНИТЕЛЯ. Действие: ПРОЧИТАЙ (Read) и собери по нему.** НЕ создавай и НЕ перезаписывай этот файл. Свой результат пиши в новый HTML + WORKER_RESULT, не в этот packet.
>
> Owner-go: Дима, 2026-06-07. Это owner-override стандартного правила «HTML собирает Claude» (`feedback_codex_artefact_handoff`): для M3-01 выбран **Codex-builder verbatim**, потому что прошлый Claude-HTML молча менял текст и сломал v1. Твоя задача — render БЕЗ авторской правки прозы.

## Goal
Собрать один клиентский HTML-документ M3-01 «Ядро продукта» **дословным render'ом** из owner-accepted MD `M3-01-CLIENT-v3.md`, для owner-review. **НЕ deploy, НЕ hub, НЕ push** — только сборка + скриншоты.

## Context to load
- **Источник текста (единственный):** `M3-продукт/M3-01-Ядро-продукта/M3-01-CLIENT-v3.md` — owner-accepted MD. Это весь и единственный текст документа.
- Rulebook вёрстки: `_правила/brandos-artifacts/` (01-tokens … 09-artifact-assembly + `changelog.md`, актуальная запись v1.3 hero-loft).
- `_правила/changelog/2026-06-06-m3-html-verbatim-render.md` — правило HTML = дословный render.
- Правило первого экрана: `_правила/rules/m3-m8-artifact-production-canon.md` §1 (hero = self-description документа; раздел 1 = тезис предмета).
- Companion (НЕ в HTML, только для понимания): `M3-01-SOURCE-LEDGER-v3.md`, `M3-01-AUTHOR-EVIDENCE-v3.md`.

## Allowed files
- Создать `M3-продукт/M3-01-Ядро-продукта/html/M3-01-YADRO-PRODUKTA.html` (ASCII-имя, как в прошлой сборке).
- Создать скриншоты `html/M3-01-*-desktop.png`, `html/M3-01-*-mobile.png`.
- Создать `M3-01-HTML-BUILD-RESULT-CODEX-2026-06-07.md` (WORKER_RESULT).

## Forbidden files / zones
- **НЕ менять текст** `M3-01-CLIENT-v3.md` ни на слово. HTML body-текст == MD дословно. Перефраз / «улучшение» прозы = hard blocker.
- НЕ трогать `M3-01-SOURCE-LEDGER-v3.md`, `-AUTHOR-EVIDENCE-v3.md`, `-CLIENT-READY-GATE-v3.md`, `_superseded/`.
- НЕ deploy / hub / push / sources.zip. НЕ трогать M3-02, M2, другие модули.
- Companion-ledger (источники) НЕ вставлять в HTML — kitchen-clean, он живёт отдельным файлом.

## Task
1. Render `M3-01-CLIENT-v3.md` в HTML по rulebook brandos-artifacts (hero-loft v1.3): токены, base, hero, structure, компоненты, таблица §4 как таблица.
2. **Hero/первый экран = self-description документа** (что за документ / какое решение помогает принять / что внутри / чем не является) — по §1 канона. H1 = «Что Alien Cat продаёт по сути». Главный тезис предмета — в раздел 1, не в hero.
3. **Hub-возврат обязателен:** toplink «К хабу клиента →» + nav-пилюля «К хабу» (canon `feedback_hub_link_required`).
4. Fade-up секции: IntersectionObserver `threshold: 0` (не 0.12 — длинные секции белеют, `feedback_artifact_fade_threshold_bug`).
5. ASCII-имя файла (middle-dot/кириллица в имени → пустая страница в Safari).
6. Скриншоты desktop + mobile (Playwright с CSS-override для fade-up, иначе opacity:0).

## Definition of done
- **CONTENT_SYNC text-diff = 0 расхождений:** видимый текст HTML body дословно равен `M3-01-CLIENT-v3.md` (включая таблицу §4 — все колонки и строки, без обрезки). Это главный критерий.
- 0 pageerrors в консоли; все секции/блоки на месте.
- Hero = self-description (проходит hero-displacement test); раздел 1 = тезис предмета.
- Hub-toplink + nav-пилюля present; ASCII-имя; fade-up не белеет.
- Скриншоты приложены; в WORKER_RESULT указан provenance (sha256 source MD).
- **НЕ объявлять HTML_READY / готовность к публикации** — это делает Claude после CLIENT-LANGUAGE-PREFLIGHT + 6-check (`feedback_subagent_build_no_publish_claim`). Ты сдаёшь «собрано + self-checks», не «готово к деплою».

## Output format
WORKER_RESULT (формат `dev/orchestrator/TASK-PACKET.md`): Status / What was done / Files changed / Checks (content-sync diff, pageerrors, hero, hub-link, screenshots) / Risks / Needs decision / Recommended next item. Плюс сам HTML + скриншоты.

## Stop and escalate if
- Текст MD кажется требующим правки — **НЕ править**, остановиться и вернуть Claude/owner (правка прозы — не зона билдера).
- Конфликт rulebook (artifact vs hub) или не хватает данных.
- Любая необходимость трогать запрещённые зоны.

## После сдачи (вне твоей зоны, для справки)
Claude прогонит HTML_READY-гейт (verbatim-сверка + ai-ness grep + hub-link + first-screen + визуальный чек скриншотов) → owner review → только потом отдельный owner-go на deploy/hub.
