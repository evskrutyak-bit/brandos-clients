# TASK для Codex — HTML-сборка + deploy M3-01 v4 (замена live-v3)

> ⚠️ **READ-ONLY ВХОД.** Файлы ниже — ЧИТАТЬ, не перезаписывать и не править. Ты собираешь HTML и деплоишь; клиентский MD, IZDELIE, M3-03 не трогаешь. Текст рендеришь verbatim — HTML ≠ MD по тексту = ошибка.

## Контекст
`M3-01-CLIENT-v4.md` — **owner-accepted** (2026-06-11, «лучший артефакт»), пересобран в field-test. Заменяет live-v3 (`M3/M3-01-YADRO-PRODUKTA.html`, deploy `fb1a307`). M3-03 (операционная модель) — internal, на хаб НЕ идёт.

## Источник (читать)
- **Source MD:** `neyroupakovka/alian-cat/M3-продукт/M3-01-Ядро-продукта/M3-01-CLIENT-v4.md`
- **Provenance (sha256[:16] source MD):** `a1aac3009c29d69b` — записать в HTML; DEPLOY_QC сверит live против него.
- Frontmatter готов: `hero_stats` (4 карточки) + `nav` (7 пунктов) + status/version. Брать их из frontmatter, не выдумывать.

## Сборка
1. Verbatim render тела MD (заголовок «Что Alien Cat продаёт на самом деле» + разделы 1–7) в HTML — **дословно, без перефраза**. Таблица опор §2 рендерится как таблица.
2. Builder v2 / BrandOS-artifacts canon (hero-loft, фазовая палитра M3). Hero — из `hero_stats` (value/label/desc/source).
3. **hub-возврат обязателен:** toplink «К хабу клиента →» + nav-пилюля «К хабу» (единый текст, как на других live-артефактах).
4. Имя файла — **ASCII**, тот же путь, что у live-v3: `M3-01-YADRO-PRODUKTA.html` (замена существующего).
5. Provenance-блок в HTML = `a1aac3009c29d69b`.
6. Скриншоты desktop + mobile (`*-desktop.png`, `*-mobile.png`) в `html/`.

## Deploy
- Репо `evskrutyak-bit/brandos-clients`, branch `main`.
- Заменить `alian-cat/M3/M3-01-YADRO-PRODUKTA.html` собранным HTML из v4.
- Hub: карточка M3-01 уже есть (счётчик артефактов **не меняется**) — обновить только если изменился статус/дата; содержимое страницы M3-01 теперь = v4.
- Коммит: `feat(alian-cat): M3-01 v4 owner-accepted rebuild`.

## После деплоя — стоп, передать Claude на DEPLOY_QC (E16)
НЕ объявляй готовность сам. Claude независимо проверит live (`?v=<commit>`): provenance live == `a1aac3009c29d69b`, HTTP 200, размер ≈ локальному, hub-возврат present, stale-маркеры (старые формулировки v3 / «развилк» / кухня) = 0, HTML-текст == MD (без перефраза).

## Границы
НЕ трогать: `M3-01-CLIENT-v4.md` и прочие MD, `IZDELIE`, M3-02/03/04, другие live-артефакты. Только сборка+деплой M3-01 v4.

---
*TASK Codex · M3-01 v4 HTML+deploy · 2026-06-11 · verbatim, hub-link, provenance a1aac3009c29d69b, DEPLOY_QC за Claude.*
