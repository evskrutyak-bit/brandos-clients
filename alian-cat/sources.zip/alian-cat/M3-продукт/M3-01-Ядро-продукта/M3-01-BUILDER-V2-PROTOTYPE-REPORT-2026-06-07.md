# M3-01 Builder v2 Prototype — report

## Scope

Prototype only. HTML_READY, deploy, hub/state and rollout to M3-03 were not touched.

Source MD:
- `M3-01-CLIENT-v3.md`

Output:
- `_codex-html-regression/M3-01-V3-BUILDER-V2-PROTOTYPE.html`
- `_codex-html-regression/M3-01-V3-BUILDER-V2-PROTOTYPE-desktop.png`
- `_codex-html-regression/M3-01-V3-BUILDER-V2-PROTOTYPE-mobile.png`

Target reference:
- `picnic/M2-исследования/M2-06-KARTINA/B2C/M2-06-KARTINA-B2C-v2.html`

## What changed in builder

- `---` renders as `<hr class="section-divider">`, not visible text.
- Strong leading paragraphs render as `observation-card`.
- Key decision paragraphs render as `decision-box`.
- Ordered open questions render as `question-card`.
- Bold-item lists render as `check-list`.
- Final "Если коротко" renders as `summary-card`.
- Status words such as "требует уточнения", "ориентир", "подтверждено" render as body badges.
- Text remains verbatim; only wrapper/classes changed.

## Prototype component evidence

- `observation-card`: present.
- `decision-box`: present.
- `question-card`: present.
- `summary-card`: present.
- `check-list`: present.
- `section-divider`: present.
- `badge--amber` / `badge--blue` / `badge--green`: present where source terms exist.

## Checks

`brandos_artifact_check.py`:

```text
BRANDOS_ARTIFACT_CHECK: PASS
```

`brandos_artifact_smoke.py`:

```text
desktop: _codex-html-regression/M3-01-V3-BUILDER-V2-PROTOTYPE-desktop.png
mobile: _codex-html-regression/M3-01-V3-BUILDER-V2-PROTOTYPE-mobile.png
BRANDOS_ARTIFACT_SMOKE: PASS
```

Additional grep:
- visible `---` text: 0.
- provenance hash: `6e41b190a451cd46`.

## Not done

- No deploy.
- No HTML_READY stamp.
- No M3-03 rebuild.
- No source text edit.

## Next gate

Method contour should compare prototype visually against KARTINA-level body richness and decide whether the component mapping is good enough before rollout to M3-03.
