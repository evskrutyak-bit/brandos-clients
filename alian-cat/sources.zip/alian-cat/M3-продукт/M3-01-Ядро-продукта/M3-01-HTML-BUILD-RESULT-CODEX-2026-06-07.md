# WORKER_RESULT — M3-01 HTML build Codex

## Status

`BUILT_FOR_VERIFICATION`

HTML собран как локальная версия для owner-review и последующего HTML_READY-гейта у Claude. `HTML_READY`, deploy, hub и push не объявлялись и не выполнялись.

## What Was Done

- Собран `html/M3-01-YADRO-PRODUKTA.html` из единственного источника `M3-01-CLIENT-v3.md`.
- Основной HTML в `html/` пересобран через актуальный builder v2; это уже не только прототип из `_codex-html-regression/`.
- Видимый текст MD не изменялся; добавлен только frontmatter `hero_stats`, чтобы Codex не выбирал stat-cards сам.
- HTML сделан как verbatim render: H1, вводный блок, все 7 разделов, списки и таблица раздела 4 перенесены дословно по видимому тексту.
- Таблица раздела 4 сохранена как `<div class="table-wrap"><table class="table-brandos">...` со всеми 3 колонками и 5 строками.
- Layout пересобран по единому контейнер-стандарту: один `--container-max`, `.body-content{max-width:none}`, стабильная `.stat-grid`, таблицы через динамический `--table-min`.
- Вставлен provenance:
  - source sha256: `6e41b190a451cd46e0dc325c55c81b49249881d16e49db724308f915b9fa1f98`
  - html comment: `built_from_client_md_hash: 6e41b190a451cd46`
- Hero собран по `hero-loft` v1.3: `.toplink`, `.nav-loft`, `.hero-loft`, `.badge`, 4 `.stat-card`.
- Hub-возврат добавлен: `К хабу клиента →` в toplink + `К хабу` в nav.
- IntersectionObserver использует `threshold: 0`.
- Скриншоты сняты с CSS override для `.fade-up`.

## Files Changed

- `html/M3-01-YADRO-PRODUKTA.html`
- `html/M3-01-YADRO-PRODUKTA-desktop.png`
- `html/M3-01-YADRO-PRODUKTA-mobile.png`
- `M3-01-CLIENT-v3.md` (только frontmatter `hero_stats`)
- `M3-01-HTML-BUILD-RESULT-CODEX-2026-06-07.md`

## Artifact Brief

| Поле | Значение |
|---|---|
| Клиентский якорь | Alien Cat / дизайнерская интерьерная мебель для кошек |
| Главный инсайт | Покупатель платит не за когтеточку, а за мебель для дома, которой кошка реально пользуется. |
| Решение клиента | Едино назвать суть продукта перед линейкой, ценами, позиционированием и каналами. |
| Запретные направления | Не зоотовар, не чистый декор, не масс-маркет, не обещания по нагрузкам без подтверждения. |
| Рабочая ставка | Мебель для дома, которой пользуется кошка; доказательство через составляющие продукта. |
| Доказательная карта | Материалы/фактура, интерьерная форма, прочность, изготовление под заказ, сервис. |
| Справочный слой | Открытые вопросы по нагрузкам, сервису, ролям S/M/L, спросу 75-100 тыс.+. |
| Визуальный мотив | Спокойный рабочий документ команды: сначала суть, затем доказательства и границы. |

## Checks

| Check | Result |
|---|---|
| Source hash | `6e41b190a451cd46e0dc325c55c81b49249881d16e49db724308f915b9fa1f98` |
| HTML provenance | `6e41b190a451cd46` |
| `brandos_artifact_check.py` | PASS: content-completeness, provenance, `hero_stats`, static layout contract |
| `brandos_artifact_smoke.py` | PASS: desktop + mobile bounding-box layout |
| Sections | 7 |
| H1 | 1 |
| Builder v2 components | source pattern does not require `cluster-grid` / `whitespace-map` / `metric-card`; regular table render preserved |
| v1.3 hard classes | `.toplink` 1 / `.nav-loft` 1 / `.hero-loft` 1 / `.badge` 1 / `.stat-card` 4 |
| Hub-link | 2 visible links: `К хабу клиента →`, `К хабу` |
| Fade-up | `threshold: 0` |
| Container layout | PASS: `.body-content{max-width:none}`, single `.container`, symmetric padding |
| Table layout | PASS: table wrapped, dynamic `--table-min` (3 columns → 760px default) |
| Kitchen-clean grep | PASS: `MCP/Exa/Firecrawl/source-data/SOURCE/LEDGER/owner/Claude/Codex/Agent/pipeline/прогон/заход/выгрузк/развилк/field-test/KARTINA/JTBD/HTML_READY` = 0 |
| Playwright desktop | PASS: 0 pageerrors, H1 visible, 7 sections, 4 stat-cards, no layout overflow |
| Playwright mobile | PASS: 0 pageerrors, H1 visible, 7 sections, 4 stat-cards, no layout overflow |
| Screenshots | `html/M3-01-YADRO-PRODUKTA-desktop.png`, `html/M3-01-YADRO-PRODUKTA-mobile.png` |
| HTML_READY/deploy | NOT SET |

## Risks

- `hero_stats` now exists in `M3-01-CLIENT-v3.md`, but it was added by Codex as a mechanical frontmatter contract from the already accepted stat-cards. The visible document body was not edited.
- `href="../../../"` is correct for local nested review from `M3-01-Ядро-продукта/html/`. Deploy copy may need URL remap to the live flat hub scheme.

## Needs Decision

- Claude should run the formal HTML_READY 6-check and decide whether the scoped `data-sync` content diff satisfies the TASK_PACKET intent.
- Owner eye-check after Claude verification.
- Deploy/hub remains a separate owner-go.

## Recommended Next Item

Run Claude HTML_READY gate on `html/M3-01-YADRO-PRODUKTA.html`, with special attention to:

- verbatim content region vs `M3-01-CLIENT-v3.md`;
- mobile hero height and readability;
- deploy-time hub href remap.
