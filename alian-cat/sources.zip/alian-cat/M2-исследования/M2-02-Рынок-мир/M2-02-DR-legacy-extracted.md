# M2-02-DR-legacy-extracted — Alien Cat M2-02 Рынок мир

> **Pure RESEARCH extraction из legacy DR.** Восемь секций R1-R8. R9 собирается отдельно в `M2-02-RESEARCH.md` после MCP add-on.
> Source: `DR-SOURCES/legacy-gpt-2026-04-10.md` (raw conversion `Dr мир.pdf` от 2026-04-10).
> Per CLIENT-OVERLAY Overlay #1 (single legacy + extended MCP) + Overlay #4 (genre filter / source labels / R0 мета-блок).

---

## R0. Methodology block

### Scope
- **Исследуется:** мировой рынок мебели, когтеточек и интерьерных изделий для кошек (вся категория от эконома до люкса), по странам и ценовым ярусам.
- **Не исследуется:** РФ + СНГ (M2-01, закрыт); прямые конкуренты Alien Cat (профиль D, M2-05); продуктовая матрица по конкретным SKU (профиль E, M2-03); международная ЦА (профиль A, M2-04).

### Source-pack note
Single legacy DR (`Dr мир.pdf`, ChatGPT Deep Research, 2026-04-10) + MCP add-on. Separate CALIBRATION-LOG **не создаётся** (single thread). MCP-EVALUATION создаётся **отдельно** per profile C (файл `M2-02-MCP-EVALUATION.md`).

### Limits
- R1: 10 стран в legacy скрининге vs 12-15 v1.1 → расширение через MCP (`R1-extend`).
- R5: URL офферов — footnote-формат в PDF, частично потеряны → реконструкция через MCP.
- R7: «2 типичные ошибки визуала/TOV» — не структурированы в legacy → добор через MCP (`R7-errors`).
- R8: footnote URLs частично потеряны при PDF conversion (27 из ~60+ сохранены) → реконструкция через MCP.

### DR / MCP boundary
- **Из legacy DR (этот файл):** R1-R8 в каноническом v1.1 формате + лейблы verification.
- **Из MCP уже выполнено** (Tavily 2026-04-27, см. `_fact-check/M2-02-MIR-MCP-RESULTS.md`): 5 critical facts → 3 PASS, 2 CORRECTED.
- **Из MCP extended** (планируется, см. `M2-02-MCP-INSTRUCTION.md`): 13 утверждённых проверок — 7 непроверенных suspicious facts (C-XSV-06..12) + 3 cross-verifications + 1 re-check + R1-extend + R7-errors.

### No-seeded-facts rule (verification labels)

| Лейбл | Значение |
|---|---|
| `[verified-by-MCP: <ID>]` | Подтверждено MCP (Tavily результат). 3 факта: C-XSV-01 / C-XSV-03 / C-XSV-05 |
| `[mcp-corrected: <ID>]` | Скорректировано MCP, в файл идёт скорректированная формулировка. 2 факта: C-XSV-02 / C-XSV-04 |
| `[pending-mcp-extended: <ID>]` | Утверждённый MCP-пункт extended-плана (всего 13). Будет проверен в add-on |
| `[single-source: <name>]` | Один источник без кросс-верификации (FMI, GlobalGrowthInsights, и т.п.) |
| `[legacy-unverified]` | Факт из legacy без URL и не входит в 13 MCP-пунктов. Базовая контекстная информация |
| `[source: <URL>, <date>]` | URL найден в legacy raw, точное цитирование возможно |
| `[no-url-in-legacy]` | Footnote есть в PDF, URL не сохранился → R9 gap |

Без лейбла — fact не валиден.

---

## R1. Сегменты мирового рынка

### Связный текст

Мировой рынок мебели для кошек оценивается в `[verified-by-MCP: C-XSV-01]` $5.8 млрд (2024) → $9.3 млрд (2033), CAGR 5.6% (`[single-source: GlobalGrowthInsights]`, разброс оценок других домов: $1.2-6.5 млрд в 2024). Современный/дизайнерский подсегмент растёт быстрее общего: `[mcp-corrected: C-XSV-02]` рост подтверждён, но конкретные цифры объёма $1.5→$2.8 млрд CAGR 6.8% — `[single-source: FMI]`, кросс-верификация недоступна → использовать как «modern растёт быстрее общего», без абсолютных $.

География распределена неравномерно. Северная Америка даёт ~40% мирового рынка ($2.4 млрд в 2025 для всей мебели для питомцев в США), Китай — самый быстрорастущий с двузначной динамикой и ~21.5% APAC, Германия и Скандинавия задают стандарт дизайна и устойчивости, Япония и Корея специализируются на компактных решениях и pet-tech. Россия — внутренний кейс закрытого модуля M2-01 (не дублируется здесь).

### Таблица — 10 стран скрининга (legacy coverage)

| Страна | Объём (2023-2025) | Динамика | Per-capita траты | Канал-доминанта | Культурная специфика |
|---|---|---|---|---|---|
| США | ~$1.8-2.0 млрд (40%+ NA) `[legacy-unverified]` | 5-6% стабильный | `[verified-by-MCP: C-XSV-03]` $22.9 (FMI) | Online (Amazon/Chewy) | fun & emotional, рост дизайн-сегмента |
| Китай | ~$0.7-0.8 млрд (21.5% APAC) `[legacy-unverified]` | 6-8% бурный | `[legacy-unverified]` $14.6 (FMI) `[single-source: FMI]` | Online (Tmall/JD, соцкоммерция Xiaohongshu) | Polarised: masс vs cute & fun (Vetreska) |
| Германия | ~$0.3-0.4 млрд (крупнейший в Европе) `[legacy-unverified]` | 5-6% устойчивый | `[legacy-unverified]` $21.8 (FMI) `[single-source: FMI]` | Offline (50%) + online; Zooplus | Прагматизм, качество, эко |
| Великобритания | ~$0.25-0.3 млрд `[legacy-unverified]` | ~5% устойчивый | `[legacy-unverified]` $20.7 (FMI) `[single-source: FMI]` | Pets at Home (offline) + онлайн | Премиум-качество, история бренда |
| Франция | ~$0.2 млрд `[legacy-unverified]` | ~5% устойчивый | ~$18-20 оценочно `[legacy-unverified]` | Mix | «art de vivre», эстетика квартиры |
| Япония | ~$0.2 млрд `[legacy-unverified]` | 4-5% зрелый | `[verified-by-MCP: C-XSV-03]` $19.4 (FMI) | Mix offline+online; Amazon JP, Rakuten | Минимализм, zen & cute, вертикальные комплексы |
| Южная Корея | ~$0.1-0.15 млрд `[legacy-unverified]` | ~6% высокий | ~$15 оценочно `[legacy-unverified]` | Online (Coupang, Gmarket), соцсети | «Для детей»: модно, инстаграмно, smart-tech |
| Канада | ~$0.1 млрд (≈5% от США) `[legacy-unverified]` | ~5% | ~$20 близко к США `[legacy-unverified]` | Mix US import + локал | Эко, климатическая практичность |
| Австралия | ~$0.08 млрд `[legacy-unverified]` | ~5% | $20+ `[legacy-unverified]` | Mix | Высокий уровень владения, эко |
| Россия | ~59% домохозяйств с кошками `[legacy-unverified]` | Премиум развит слабо | — | Wildberries/Ozon + Avito | **Не исследуется в M2-02** (M2-01) |

### Ценовая шкала по основным категориям (US/EU/Asia)

| Категория | Эконом | Средний | Премиум | Люкс |
|---|---|---|---|---|
| Когтеточка | $5-30 (Amazon) | $30-80 | $100-200 | $300-1000+ |
| Многоуровневое «дерево» | $50-100 | $100-300 | $300-600 | $600-3000+ (NEKO Cat Tree `[pending-mcp-extended: C-XSV-07]` ~¥1 млн) |
| Домик/тумба | $30-80 | $80-200 | $200-500 | $500-2000+ |
| Тумба-туалет (litter cabinet) | — | $80-200 | $200-500 (Tuft+Paw Cove `[pending-mcp-extended: C-XSV-10]`) | $500-1500+ |
| Лежанка | $20-50 | $50-150 | $150-400 | $400-1500+ |
| Настенная система | DIY 50-200 | $150-400 | $400-1000 | $1000-3000+ |

`[verified-by-MCP: C-XSV-05]` 48% потребителей ожидают модульную/кастомизируемую мебель для кошек (`[single-source: FMI]`).

`[mcp-corrected: C-XSV-04]` см. corrected channel-note в R4.

---

## R2. Каталог игроков

### Связный текст: ландшафт по странам

**США.** Соседствуют традиционные масс-производители (PetFusion, MidWest Homes for Pets, Go Pet Club, Frisco/Chewy) и D2C-дизайнерские стартапы (Tuft + Paw, The Refined Feline, Catastrophic Creations, Mau Lifestyle). Premium-стандарт — «furniture-first design», отказ от зоомагазинной эстетики.

**Канада.** Близка к US, основные игроки пересекаются. Catit (канадский, известен глобально). Локальные ремесленники через Etsy. EcoCat Furniture позиционирует переработанное дерево как ось дифференциации.

**Германия.** Trixie (крупнейший масс-производитель Европы, бюджет до mid-range), Kerbl, MiaCara (премиум-дизайн, минимализм, FSC), Goldtatze (бутиковый супер-премиум стеновых комплексов, фактически мастерская), LucyBalu (Мюнхен) — `[pending-mcp-extended: C-XSV-06]` бренд связывается с эпизодом Карла Лагерфельда (кошка Шупетт), требует проверки.

**Франция / Великобритания.** Zolux (FR), PIDAN (азиатско-французский минимализм). UK: Rosewood Pet (нишевый премиум), Hicat (потолочные столбы под индивидуальный заказ), Catipilla (настенные дорожки), Pet Rebels (UK дистрибуция). RHRQuality (Нидерланды, представлен в UK) — `[pending-mcp-extended: C-XSV-08]` известна сверхпрочными когтеточками для мейн-кунов, гарантия 2 года требует проверки.

**Япония.** RINN (бутиковый дизайнер, NEKO Cat Tree из дерева и мрамора), Dinos Pet (отдел известного каталога Dinos), Iris Ohyama (бюджетные когтеточки), Karimoku Cat (известный мебельный бренд для людей запустил линейку для кошек), мастерские г. Окава (миниатюрная кошачья мебель). NEKO Cat Tree `[pending-mcp-extended: C-XSV-07]` ~¥1 млн требует верификации цены и дизайнерских наград.

**Южная Корея.** Milliong (Миллионг — дизайн-студия, локальное премиум-кородерево, выставка Seoul Design Fair), LuxyCat (премиум, планы экспансии), Purrmunn, Ggotjirak (эстетические лежанки).

**Китай.** Vetreska (вирусный кактусовый дизайн), Pidan Studio (минимализм, дизайнерские награды), HOOPEET, MIDOLY (популярные на Tmall), Xiaomi Youpin (smart кошачий домик с климат-контролем).

### Сводная таблица — игроки по странам (≥30, требование v1.1 ≥15 — с запасом)

| Игрок | Страна | Тип | Ярус | Каналы | Продуктовая суть | Verification | Legacy ref |
|---|---|---|---|---|---|---|---|
| PetFusion | США | Масс-D2C | Эконом-средний $50-150 | Amazon, Chewy | Широкий ассортимент когтеточек, деревьев | `[legacy-unverified]` | p.5 |
| MidWest Homes for Pets | США | Масс-D2C | Эконом-средний | Amazon, Petco, Chewy | Эконом-сегмент, дерев./домики | `[legacy-unverified]` | p.5 |
| Go Pet Club | США | Масс-D2C | Эконом $50-150 | Amazon | Эконом когтеточки/деревья | `[legacy-unverified]` | p.5 |
| Frisco | США | Retailer label | Эконом $30-100 | Chewy (эксклюзив) | Private brand Chewy | `[legacy-unverified]` | p.5 |
| Tuft + Paw | США | Премиум-D2C | Премиум | tuftandpaw.com, Instagram, Amazon | «Furniture-first», флагман Cove (litter cabinet), научный подход к кошачьему поведению | `[pending-mcp-extended: C-XSV-10]` цена Cove | p.5, p.7, p.15 |
| The Refined Feline | США | Премиум-D2C | Премиум ~$400 | Amazon, сайт | Lotus Cat Tower flagship | `[pending-mcp-extended: C-XSV-11]` рейтинг/отзывы | p.5, p.11 |
| Catastrophic Creations | США | Премиум-D2C, DIY-уклон | Премиум $200-500 | сайт, Etsy, Instagram | Модульные настенные системы | `[legacy-unverified]` | p.5, p.12 |
| Mau Lifestyle | США | Премиум-D2C | Премиум | сайт, Instagram | Современные деревья с бохо-элементами | `[legacy-unverified]` | p.5 |
| Catit (Vesper) | Канада → глобально | Премиум-D2C | Средний-премиум $100-150 | сайт, Amazon, retail | Модульная мебель дерево+сизаль | `[legacy-unverified]` | p.5, p.7, p.11 |
| Bailey & Bella | Канада | D2C | Средний | сайт | Аксессуары и мебель | `[legacy-unverified]` | p.5 |
| EcoCat Furniture | Канада | Premium-eco | Премиум | сайт | Переработанная древесина | `[legacy-unverified]` | p.5 |
| Trixie | Германия | Масс-производитель | Бюджет-mid | Зоомагазины ЕС, Amazon | Сотни моделей когтеточек | `[legacy-unverified]` | p.6 |
| Kerbl | Германия | Масс-производитель | Бюджет-mid | Зоомагазины, Amazon | Каталог зоотоваров | `[legacy-unverified]` | p.6 |
| MiaCara | Германия | Премиум-дизайн | Премиум €300+ | сайт miacara.com | FSC-дерево, минимализм, эко-упаковка | `[pending-mcp-extended: C-XSV-12]` верхняя граница диапазона | p.6, p.7, p.16 |
| Goldtatze | Германия | Бутиковый супер-премиум | Люкс | сайт, под заказ | Стеновые комплексы по индивидуальному заказу | `[legacy-unverified]` | p.6 |
| Catwalk Systems | Германия | Премиум-модульный | Премиум-люкс | сайт | Стеновые комплексы | `[legacy-unverified]` | p.4 |
| LucyBalu | Германия (Мюнхен) | Премиум-D2C | Премиум | сайт, дизайн-сторы | Подвесные гамаки, минимализм | `[pending-mcp-extended: C-XSV-06]` эпизод Лагерфельда | p.6 |
| Zolux | Франция | Масс-производитель | Mid | Зоомагазины, онлайн | Каталог + линия мебели | `[legacy-unverified]` | p.6 |
| PIDAN | Франция/Азия | Премиум-дизайн | Премиум | сайт, retail | Минималистичные изделия | `[legacy-unverified]` | p.6 |
| Pets at Home | UK | Retailer Own Brand | Эконом-mid | Pets at Home (retail), сайт | Доступный ассортимент | `[legacy-unverified]` | p.8 |
| Hicat | UK | Premium-bespoke | Люкс | под заказ | Потолочные столбы «от пола до потолка» | `[legacy-unverified]` | p.6, p.8 |
| Catipilla | UK | Премиум-D2C | Премиум | сайт | Настенные дорожки | `[legacy-unverified]` | p.6 |
| Rosewood Pet | UK | Mid-производитель | Mid | Retail | Аксессуары и мебель | `[legacy-unverified]` | p.6 |
| Pet Rebels | UK / NL | Дистрибьютор/премиум | Премиум | Retail UK | Премиум аксессуары | `[legacy-unverified]` | p.6 |
| RHRQuality | Нидерланды (→ UK) | Премиум-D2C, нишевый | Премиум | сайт rhrquality.com | Сверхпрочные когтеточки для крупных пород | `[pending-mcp-extended: C-XSV-08]` warranty/specialization | p.6 |
| Vetreska | Китай | Премиум-D2C, viral | Mid-премиум | соцсети, Tmall, US partnerships (Urban Outfitters, Jackson Galaxy shop) | Кактусовый дизайн, виральный продукт, «whimsy & fun» | `[legacy-unverified]` | p.6, p.12, p.17 |
| Pidan Studio | Китай (Шанхай) | Премиум-дизайн | Премиум | сайт, retail | Минимализм, дизайнерские награды | `[legacy-unverified]` | p.6 |
| HOOPEET | Китай | Mid-производитель | Mid | Tmall | Когтеточки/деревья | `[legacy-unverified]` | p.6 |
| MIDOLY | Китай | Mid-производитель | Mid | Tmall | Когтеточки/деревья | `[legacy-unverified]` | p.6 |
| Xiaomi Youpin | Китай | Smart pet-tech | Mid-премиум | Xiaomi экосистема | Smart кошачий домик с климат-контролем | `[legacy-unverified]` | p.6 |
| RINN | Япония | Бутиковый дизайнер | Люкс ~¥1 млн | сайт, design-stores | NEKO Cat Tree (мрамор + дерево) | `[pending-mcp-extended: C-XSV-07]` цена/награды | p.6, p.10-11 |
| Dinos Pet | Япония | Каталог-ритейлер | Mid-премиум | Dinos каталог | Сотрудничество с дизайнерами | `[legacy-unverified]` | p.7 |
| Iris Ohyama | Япония | Масс-производитель | Бюджет | Amazon JP, Rakuten | Бюджетные когтеточки | `[legacy-unverified]` | p.7 |
| Karimoku Cat | Япония | Премиум-D2C (extension мебельного бренда) | Премиум-люкс | сайт, MadeMoggie (AU) | Деревянная мебель для кошек, японский дизайн | `[legacy-unverified]` | p.12 |
| Milliong (Миллионг) | Корея | Премиум-дизайн | Премиум-люкс | соцсети, Seoul Design Fair | Современное кородерево | `[legacy-unverified]` | p.7 |
| LuxyCat | Корея | Премиум-D2C | Премиум | сайт, планы экспансии | Натуральное дерево, кастом | `[legacy-unverified]` | p.7 |
| Purrmunn | Корея | Дизайн-нишевый | Премиум | соцсети | Эстетические лежанки | `[legacy-unverified]` | p.7 |
| Ggotjirak | Корея | Дизайн-нишевый | Премиум | соцсети | Эстетические лежанки | `[legacy-unverified]` | p.7 |
| IKEA (Lurvig / Utsådd) | Швеция → глобально | Mass-cross-category | Эконом-средний | IKEA stores | Коллекции для питомцев 2017, 2024 | `[legacy-unverified]` | p.12 |
| Kattens No.1 | Дания | Премиум-модульный | Премиум | сайт, retail | Модульные когтеточки | `[legacy-unverified]` | p.11 |
| Nipa | США | Eco-D2C | Mid-премиум | сайт | Когтеточки из пробкового дерева | `[legacy-unverified]` | p.17 |
| Ware Pet Products | США | Mid-eco | Mid | Amazon, retail | Когтеточки из переработанного материала | `[legacy-unverified]` | p.12 |
| FancyPets (× Nendo) | Франция | Премиум-коллаборация | Люкс | сайт | Коллекция домиков от Nendo | `[legacy-unverified]` | p.12 |

**Итого:** 42 игрока с типологией. Покрытие v1.1 R2 (≥15) — с запасом x2.

---

## R3. Продуктовая матрица

### Связный текст

Категория мебели для кошек включает: когтеточки (от простых колонн до настенных систем), кошачьи «деревья» (cat trees / condos) разной этажности, домики и тоннели, лежанки и гамаки, мебель 2-в-1 (стол с домиком внутри, стул-домик, тумба-туалет), маскирующие лотковые тумбы (растущая категория), настенные полки и ступени, столики под миски.

Доминируют два дизайнерских направления: «плюшево-ковровый» традиционный (мягкие конструкции с коврином, исторически с 1980-х в США) и «модерн» (дерево, металл, канат, минимализм). Премиум-сегмент построен на «модерн»-коде: натуральное дерево (дуб, бук, береза) или качественная фанера с шпоном, устойчивые ткани (мебельная ткань, шерсть, искусственный мех Memory Foam), сизалевое полотно. Эко-материалы — отдельный тренд: гофрокартон, лоза, мицелий, переработанный текстиль.

### Сводная таблица — 11+ форматов

| Формат | Размеры | Эконом | Mid | Премиум | Люкс | Кейс/прим. |
|---|---|---|---|---|---|---|
| Простая когтеточка-колонна | ~50-80 см | $5-30 | $30-60 | $60-150 | $150+ | Trixie, Kerbl |
| Многоуровневое «дерево» 2-3 уровня | 100-150 см | $50-100 | $100-300 | $300-600 | $600+ | Catit Vesper V-High ($100) `[legacy-unverified]` |
| Многоуровневое «дерево» 4+ уровней | 170-210 см | $80-200 | $200-400 | $400-900 | $900+ (NEKO Cat Tree `[pending-mcp-extended: C-XSV-07]`) | Refined Feline Lotus ~$400 `[pending-mcp-extended: C-XSV-11]` |
| Домик-тумба 2-в-1 | различные | — | $80-200 | $200-500 | $500+ | Tuft+Paw Cove (litter cabinet) `[pending-mcp-extended: C-XSV-10]` |
| Лежанка/гамак | разные | $15-40 | $40-100 | $100-300 | $300+ | Plain handmade → Meyou Paris коконы |
| Настенная модульная система | DIY/собирная | $50-200 | $200-500 | $500-1500 | $1500+ | Catastrophic Creations, Catwalk Systems, Goldtatze |
| Настенные полки/ступени | элементы | $10-30 шт | $30-80 шт | $80-200 шт | $200+ шт | Catipilla |
| Лотковая тумба (litter cabinet) | как тумба | — | $100-250 | $250-500 | $500+ | Tuft+Paw Cove, ~$199 `[pending-mcp-extended: C-XSV-10]` |
| Картонная конструкция | разная | $20-50 | $50-100 | — | — | Tomeow, картонные премиальные бренды |
| Bespoke потолочный столб | под потолок | — | — | $1000-3000 | $3000+ | Hicat (под заказ) |
| Smart-furniture (концепты) | — | — | — | от $300 | — | Xiaomi Youpin smart-домик, LG концепт `[legacy-unverified]` — категория не зрелая |
| Eco-мебель (картон/мицелий) | разная | $30-100 | $100-300 | $300+ | — | Ware Pet Products, Nipa, бренды на FSC/мицелий |
| Стол/мебель для людей с зоной кошки | как у людей | — | $200-500 | $500-1500 | $1500+ | Karimoku Cat, IKEA Utsådd 2024 |

`[verified-by-MCP: C-XSV-05]` 48% потребителей ожидают модульную / кастомизируемую мебель (`[single-source: FMI]`).

### Тренды ассортимента
- **Модульность как сквозной принцип** (Catit Vesper, Catastrophic Creations, Kattens No.1).
- **Растущая категория lotковых тумб** (Tuft+Paw Cove, Goldtatze litter cabinets).
- **Эко-материалы**: Ware Pet (recycled), MiaCara (FSC + бумажный скотч).
- **Интеграция с мебелью для людей** (IKEA Lurvig 2017, Utsådd 2024, Karimoku Cat).
- **AR-конфигураторы** (Clawz US, единичный случай) — слабый сигнал.

---

## R4. Каналы, customer journey, сервис

### Связный текст

Customer journey разный по странам. В США онлайн-доминанта: запрос («best cat tree») → обзоры (Wirecutter, YouTube) → отзывы Amazon → покупка на сайте D2C или Amazon. Главные ожидания — `[legacy-unverified]` бесплатная доставка, простой возврат 30 дней, рассрочка через Affirm/Klarna. В Европе (особенно Германия) — более длинный путь исследования: форумы, Facebook-группы, частичный визит в зоомагазин. `[pending-mcp-extended: C-XSV-09]` 50% европейцев предпочитают offline для мебели для кошек — требует верификации источника. В Китае customer journey фактически весь цифровой через смартфон: соц-видео в Xiaohongshu → ссылка → Tmall. В Японии traditionally начинается с физического магазина (Pet Tokyo Expo и островные форматы), хотя онлайн растёт.

В премиум-сегменте distribution — гибрид: собственный сайт D2C + Amazon + design-stores (MoMA, DWR, Tortuga) + специализированные шоурумы + международные выставки (Maison & Objet, Interzoo, Global Pet Expo, Pet Fair Asia). В масс-сегменте — Amazon, Chewy, retail-сети (Petco, PetSmart) + китайские маркетплейсы.

### Корректировка для канала US

`[mcp-corrected: C-XSV-04]` Legacy формулировка «60-70% продаж приходятся на Amazon+Chewy» не переносится; MCP-corrected estimate ≈28% total via online-share proxy (онлайн ~37% всего рынка × ~75% online share Amazon+Chewy); точность ограничена proxy. Источники корректировки — `_fact-check/M2-02-MIR-MCP-RESULTS.md` C-XSV-04 (`[single-source: PetFoodIndustry]` + `[single-source: Mordor Intelligence 2025]`).

### 7+ CX-кейсов

| Кейс | Игрок | Страна | Логика |
|---|---|---|---|
| White-glove упаковка с перчатками для сборки | Tuft + Paw | США | `[legacy-unverified]` Перчатки в комплекте, чтобы не испачкать обивку. Wow-фактор premium |
| Эко-упаковка без пластика, бумажный скотч | MiaCara | Германия | `[legacy-unverified]` Часть бренд-кода sustainability. Влияет на purchase consideration |
| Включение запчастей в комплект (запасной коврик/сизаль) | The Refined Feline | США | `[legacy-unverified]` Снижает trouble после месяцев использования |
| 30-day satisfaction guarantee «если кошка не пользуется — вернём» | многие D2C-премиум | США | `[legacy-unverified]` Снижает purchase risk |
| Аренда мебели (Kitty Rental) | Kitty Rental | США | `[legacy-unverified]` Подписочная модель — слабый сигнал в категории |
| Рассрочка через Affirm/Klarna | премиум-D2C | США/EU | `[legacy-unverified]` Снижает финансовый барьер для премиум-цены |
| AR-примерка модели в интерьере | Clawz | США | `[legacy-unverified]` Слабый сигнал, единичный случай |
| Программа лояльности с баллами на повторные покупки | Chewy | США | `[legacy-unverified]` Работает для расходников, не для мебели |
| Контент-сообщество (блог по кошачьему поведению, фелинологи) | Tuft + Paw | США | `[legacy-unverified]` Содержательный маркетинг вместо лояльности |
| Bespoke под-потолок-заказ через консультацию | Hicat | UK | `[legacy-unverified]` Премиум-канал с очень длинным циклом |

---

## R5. Офферы и обещания

### Связный текст

В международной премиум-категории доминируют 5 обещаний: (1) «furniture-first» — мебель, которая не выглядит как зоотовары; (2) натуральные материалы (FSC, sustainable); (3) прочность для крупных кошек / lifetime warranty; (4) ручная работа / авторский подход; (5) кастом / made-to-order. В масс-сегменте офферы упрощаются до функциональных аргументов: цена, ассортимент, доступность через Amazon.

Региональная специфика. США: эмоциональный, часто с юмором, «for life with cats». Германия / Скандинавия: техничный, «надёжность, качество гарантировано», «Vet-approved». Италия / Франция: эстетика, «élégance pour votre chat». Япония: kawaii + zen, «комфорт питомца и уважение к пространству дома». Корея: «smart design for smart pet parents». Китай: акции и виральность («первые 100 заказавших — игрушка в подарок»).

### Таблица — 6+ офферных формулировок

| Игрок | Страна | Ярус | Цитата | Мотив | Verification | Source |
|---|---|---|---|---|---|---|
| Tuft + Paw | США | Премиум | «Not your grandma's cat furniture» | Эстетика, отстройка от зоомагазина | `[legacy-unverified]` | p.16 footnote 64; URL `[no-url-in-legacy]` |
| Tuft + Paw | США | Премиум | «For life with cats» | Эмоциональная связь | `[legacy-unverified]` | p.5 footnote 31-32; URL `[no-url-in-legacy]` |
| IKEA Lurvig | Швеция | Эконом-средний | «Designed by pet lovers, tested by pets. Because their home is your home too» | Гармония, демократичный premium | `[legacy-unverified]` | p.16 footnote 53; URL `[no-url-in-legacy]` |
| Catit (Vesper) | Канада | Средний | «Luxury cat furniture that won't be an eyesore» | Эстетика, отказ от «прятать» | `[legacy-unverified]` | p.17; URL `[no-url-in-legacy]` |
| Vetreska | Китай | Mid-премиум | «Позвольте вашему пушистому другу отправиться в пустынное приключение с нашим кактусовым деревом» (Тайвань кампания) | Эмоция, фантазия, vibrancy | `[legacy-unverified]` | p.17 footnote 65; URL `[no-url-in-legacy]` |
| Nipa | США | Mid-eco | «Our tree was a tree» | Эко, материал | `[legacy-unverified]` | p.17; URL `[no-url-in-legacy]` |
| MiaCara | Германия | Премиум | «Möbel, die Katze und Mensch gefallen» (мебель, которая нравится и кошке, и человеку) | Гармония, дизайн | `[legacy-unverified]` | p.16; URL `[no-url-in-legacy]` |
| Meyou Paris | Франция | Премиум | «L'élégance pour votre chat» | Элегантность, эстетика | `[legacy-unverified]` | p.18; URL `[no-url-in-legacy]` |
| RHRQuality | Нидерланды | Премиум-нишевый | «Cat furniture for big cats» (англ.) | Прочность, специализация | `[pending-mcp-extended: C-XSV-08]` warranty | URL `[no-url-in-legacy]` |
| Tuft + Paw | США | Премиум | «Your home deserves better» | Эстетика | `[legacy-unverified]` | p.17 footnote 48 |

Все URL — реконструкция через MCP add-on.

---

## R6. Тренды, слабые сигналы, угрозы

### Макротренды (≥3)

1. **Pet humanization.** Питомец как член семьи, готовность тратиться на интерьерный уровень. `[legacy-unverified]` IMARC: миллениалы особенно склонны баловать питомцев. Global, от США до Китая.
2. **Sustainability.** Эко-материалы (FSC дерево, biomaterials, recycled), снижение углеродного следа. Особенно EU, Канада, Австралия, молодёжь США. Регуляторное давление в ЕС.
3. **Tech-integration.** Smart-furniture (датчики активности, климат-контроль, AR-примерка). `[legacy-unverified]` Концепты LG, Xiaomi Youpin, Clawz AR. Категория не зрелая, единичные коммерческие продукты.
4. **Wellness & comfort.** Ортопедические лежанки для старых кошек, антимикробные покрытия. Аналог human wellness.
5. **Multi-cat households.** Большие платформы, дублирование лежаков на разных уровнях. `[legacy-unverified]` В США 30%+ владельцев имеют ≥2 кошек.
6. **Omnichannel и influencer marketing.** Активные соцсети, кошки-инфлюенсеры, pop-up на pet events, шоу-румы.

### Слабые сигналы (≥3)

1. **AR-примерка для мебели для кошек** (Clawz US, единичный случай) `[legacy-unverified]`.
2. **NFT и цифровая составляющая** для дизайнерской мебели — теоретическая, после NFT-спада практически не реализована.
3. **Кастомизация через онлайн-конфигураторы 3D** — для мебели для людей уже есть, для кошачьей пока нет крупных примеров.
4. **Аренда / шеринг для питомцев** (Kitty Rental US, UK стартапы) `[legacy-unverified]` — слабый сигнал, не массовое.

### Угрозы рынку (≥2)

1. **Насыщение премиум-D2C-рынка post-COVID в США** — те, кто завёл питомца в 2020-2021, уже купили основное. Цикл 3-4 года → возможный спад в 2024-2026.
2. **Регуляторные изменения в ЕС** — ASTM начала разрабатывать стандарты безопасности для зоотоваров, ужесточение для воспламеняемости обивки. Может повысить барьеры входа, выигрывают крупные.
3. **Экономические факторы** — `[legacy-unverified]` инфляция 2022-2023 ударила по discretionary spending; в США premium-сегмент проседал.
4. **Появление субститутов** — мебель IKEA / West Elm с зоной для кошки → масс-сегмент может перейти из специализированной мебели для кошек к интерьерным брендам.

---

## R7. Визуал и стиль коммуникации

### Связный текст

Премиум-сегмент строится на «quiet luxury»: студийная съёмка изделия в интерьерах с реальной кошкой; нейтральные палитры (бежевый, дерево, белый, тёплый чёрный); типографика serif или humanist sans-serif; фотостиль editorial. Доминирующий tone of voice — educational и тёплый, без зоомагазинной инфантильности.

Региональная специфика: США — fun & emotional, юмор, сторителлинг спасения животных. Германия — техничный, технология+качество, цифры. Япония — zen, минимализм, «комфорт питомца». Корея — модный, инстаграмный, smart-tech. Китай — yarкий, vibrant (Vetreska), либо «cute & fun», либо minimalist в стиле Muji.

### 3+ примера визуала / TOV (legacy)

| Игрок | Страна | Визуальный стиль | TOV | Источник |
|---|---|---|---|---|
| Tuft + Paw | США | Скандинавское влияние, живые интерьеры, нейтральные палитры, реальные кошки в кадре | Дружелюбный, educational, «for life with cats» | `[legacy-unverified]` p.17 footnote 48; URL `[no-url-in-legacy]` |
| MiaCara | Германия | Минимализм, FSC-эстетика, эко-упаковка как часть бренд-кода | Сдержанный, технический, sustainability-фокус | `[legacy-unverified]` p.6 footnote 38-39 |
| Vetreska | Китай | Яркий vibrancy, fantasy storytelling (пустыня + кактус как декорация) | Whimsical, фантазийный, viral-driven | `[legacy-unverified]` p.6, p.17 footnote 46-47 |
| RINN | Япония | Zen-минимализм, art-piece эстетика, дерево + камень | Спокойный, эстетический, kawaii + utonchennost | `[legacy-unverified]` p.7 footnote 26, 37 |

### Типичные ошибки визуала / TOV в категории

`[pending-mcp-extended: R7-errors]` — структурированный блок «2 типичные ошибки» в legacy отсутствует. Добор через MCP add-on (выборка из эконом-сегмента Amazon + китайских безымянных карточек: что выглядит «cheap», какой TOV «инфантилит» категорию).

---

## R8. Источники

### Связный текст

В legacy DR 60+ footnote-ссылок. 27 сохранены при PDF conversion (см. `DR-SOURCES/legacy-gpt-2026-04-10.md`). Остальные требуют реконструкции через MCP add-on. Сгруппированы по типу.

### Таблица — extracted URLs (27 из ~60+)

| URL | Тип | Дата доступа (raw) | Что подтверждает |
|---|---|---|---|
| `https://www.grandviewresearch.com/industry-analysis/pet-furniture-market` | Аналитическая компания | 2026-04-10 | R1 объём pet furniture market |
| `https://www.futuremarketinsights.com/reports/cat-furniture-scratchers-market` | Аналитическая компания (FMI) | 2026-04-10 | `[verified-by-MCP: C-XSV-03]` per-capita US/JP; `[verified-by-MCP: C-XSV-05]` 48% modular |
| `https://www.researchandmarkets.com/report/pet-furniture` | Аналитическая компания | 2026-04-10 | R1 объёмы |
| `https://www.fortunebusinessinsights.com/pet-furniture-market-106261` | Аналитическая компания | 2026-04-10 | R1 объёмы |
| `https://www.businessresearchinsights.com/market-reports/cat-furniture-market-120739` | Аналитическая компания | 2026-04-10 | R1 объёмы |
| `[+22 URLs]` | Mix отраслевая аналитика / СМИ / бренд-сайты | 2026-04-10 | Полный список — см. `DR-SOURCES/legacy-gpt-2026-04-10.md` p.27-28 |

### Источники-пробелы для MCP reconstruction

- Footnotes 1-65 (legacy) → 27 сохранены с URL, ~33-38 потеряны при conversion → требуют реконструкции через MCP.
- URLs бренд-сайтов (Tuft + Paw, MiaCara, RINN, RHRQuality и т.д.) для R5 офферных цитат — none сохранены в raw, все через MCP.
- URLs отраслевых СМИ (AD Magazine, Modern Cat, Wallpaper, Dwell, Apartment Therapy) — частично сохранены, реконструкция через MCP.

Полная таблица v1.1 R8 (≥18 источников с URL/тип/дата/что подтвердило) собирается в `M2-02-RESEARCH.md` после MCP add-on.

---

## Exclusion list — что НЕ перенесено из legacy (единый блок по всему файлу)

| Что | Где в legacy | Почему НЕ перенесено |
|---|---|---|
| B2B/B2C сегментация рынка | `Dr мир.pdf` p.1 первый абзац | Picnic-pattern leakage; v1.1 §A.1 для Alien Cat M2-02 split не применяется |
| «B2C формирует основной объём, B2B обеспечивает нишевой спрос» | p.1 | См. выше |
| 5 «противоречий» PostAnalysis Часть 1.4 (особенно противоречие №5 про B2B-сегмент) | `PostAnalysis.md` | Synthesis-жанр + использует запрещённый split |
| Часть 2 PostAnalysis (сравнение с РФ-рынком) | `PostAnalysis.md` | M2-01 territory, дублирование запрещено |
| 8 основных гипотез + 6 альтернативных | `PostAnalysis.md` Часть 3 | Synthesis-жанр + M3-M7 контент (рекомендации, риски, тестовые планы). Переупаковка в 6 канонических гипотез — в `M2-02-SYNTHESIS.md` (terminal kind), не в RESEARCH |
| Гипотеза 5 «Дизайнеры — главный B2B-канал» | `PostAnalysis.md` Часть 3.1 | Reformulate как «профессиональный партнёрский канал» (в SYNTHESIS) |
| Часть 4 «Вопросы Свете» | `PostAnalysis.md` Часть 4 | SYNTHESIS-уровень, не RESEARCH |
| Часть 5 «Таблица фиксации реакции клиента» | `PostAnalysis.md` Часть 5 | Сессионный документ, ни в RESEARCH ни в SYNTHESIS |
| Часть 6 «Что брать в следующие этапы» | `PostAnalysis.md` Часть 6 | Перекидывает в M3-M5, в M2-02 не нужно |
| «Главный вывод для Светы» | `PostAnalysis.md` финал | Рекомендация консультанта, в pure RESEARCH запрещено |
| Цифра «60-70% Amazon+Chewy» как факт | `Dr мир.pdf` p.5 | `[mcp-corrected: C-XSV-04]`, скорректированная формулировка в R4 |
| Конкретная цена Tuft+Paw Cove ($199 vs $599) | p.5 + PostAnalysis Гипотеза 4 + suspicious-facts C-XSV-10 | Внутреннее противоречие legacy. До MCP-проверки — без точной цены |
| «1491 отзыв 4.5⭐» Refined Feline Lotus как факт-снапшот | p.5 | `[pending-mcp-extended: C-XSV-11]` — устаревает; формулировка сохранена без чисел |
| Прямые сравнения с РФ-рынком в основном тексте | разные места legacy | M2-01 territory, не дублируется |
| Стратегические рекомендации («как сработает в РФ», «риски переноса», «как проверить») | PostAnalysis по всем гипотезам | M3-M7 контент, в pure RESEARCH запрещено |

---

*M2-02-DR-legacy-extracted — Alien Cat | candidate canon v1.1 | extraction date 2026-05-22*
*Source: `DR-SOURCES/legacy-gpt-2026-04-10.md`. Next: `M2-02-MCP-INSTRUCTION.md` (13 проверок).*
