# M2-02-RESEARCH — Мировой рынок мебели, когтеточек и интерьерных изделий для кошек

> Pure RESEARCH compilation per v1.1 §5.1. Internal artefact. Не показывать клиенту.
> Source-pack: single legacy DR thread + extended MCP add-on per `CLIENT-OVERLAY.md` Overlay #1.
> Дата сборки: 2026-05-22.

---

## R0. Methodology block

### Scope
Исследуется мировой рынок мебели, когтеточек и интерьерных изделий для кошек целиком — от эконом-сегмента (массовые когтеточки) до люкса и авторского кастома, по странам и ценовым ярусам. Россия и СНГ не исследуются (закрыто в M2-01). Прямые конкуренты Alien Cat и продуктовая матрица по конкретным SKU — за рамками (профили D / E). Международная ЦА в детальной сегментации — за рамками (профиль A).

### Source-pack note
Single legacy DR thread (`Dr мир.pdf`, ChatGPT Deep Research, 2026-04-10) + extended MCP add-on (Exa MCP, 2026-05-22). Separate CALIBRATION-LOG не создаётся (single thread). MCP-EVALUATION создан отдельно per profile C (`M2-02-MCP-EVALUATION.md`). 4-голосный gate: GO 4/4.

### Limits
- Per-capita траты на cat furniture для DE / UK / CN — `[single-source: FMI]`, кросс-верификация недоступна.
- Конкретные дизайнерские награды RINN NEKO Cat Tree — media-coverage есть, премии не верифицированы.
- Direct measure доли Amazon + Chewy именно в cat furniture (не cat scratching post) — composite estimate ~39%.
- Конкретная цифра % спроса на bespoke modular — `[single-source: FMI]`. Тренд — multi-source PASS.
- Cat furniture offline share для Западной Европы как агрегат — fragmented per-country.
- Cat furniture рынки Норвегии / Финляндии / Австрии / Тайваня / ОАЭ — без публичных данных.

### DR / MCP boundary
- Из legacy DR: R1 (10 стран скрининг), R2 (42 игрока с типологией), R3 (форматы и материалы), R4 (customer journey по странам), R5 (офферные формулировки), R6 (тренды), R7 (визуал).
- Из MCP add-on: 7 corrections (LucyBalu/Choupette, RHRQuality warranty, Europe offline, Tuft+Paw Cove price, Refined Feline reviews, MiaCara range, Amazon+Chewy share); 6-7 стран R1-extend; 2 типичные ошибки визуала; verifications/cross-checks.

### No-seeded-facts rule
Все fact-claims в этом файле снабжены лейблами verification: `[verified-by-MCP: <ID>]` / `[mcp-corrected: <ID>]` / `[single-source: <name>]` / `[legacy-unverified]`. Без лейбла — fact не валиден.

---

## R1. Сегменты мирового рынка

### Связный текст

Мировой рынок мебели для кошек структурирован по трём осям: география, ценовой ярус, тип игрока. По данным агрегированных отчётов рынок оценивается в `[verified-by-MCP: C-XSV-01]` $5.79 млрд (2024) → $9.45 млрд (2033), CAGR 5.6% (`[single-source: GlobalGrowthInsights]`, разброс других домов $1.2-6.5 млрд в 2024 в зависимости от методологии и охвата). Современный/дизайнерский подсегмент растёт быстрее общего рынка: `[verified-by-MCP: Cross-1]` CAGR 6.8% (Stratistics MRC оценивает Designer Pet Furniture в $2.3 млрд в 2026 → $4.0 млрд к 2034). Абсолютные суммы для cat-only designer сегмента варьируются по методологии: $1.5-2.3 млрд в 2025-2026. Премиум растёт опережающими темпами относительно масс-маркета — это макротренд, подтверждённый Mordor Intelligence, Euromonitor, FMI и Stratistics MRC.

Деньги сосредоточены в Северной Америке (~40% мирового рынка), рост ускоряется в Азии (Китай 21.5% APAC доли, двузначная динамика per-pet spending), эталон дизайн-стандарта формируют Европа (Германия, Скандинавия) и Япония. После расширения скрининга через MCP добавляются Италия, Нидерланды, Бельгия, Швеция/Дания, Польша/CEE, Гонконг, Сингапур — всего 16-17 значимых страновых рынков для категории.

### Таблица — 16-17 стран в скрининге

| Страна | Объём (2023-2025) | Динамика | Per-capita траты | Канал-доминанта | Культурная специфика | Source-label |
|---|---|---|---|---|---|---|
| США | ~$1.8-2.0 млрд (40%+ NA pet furniture) | 5-6% стабильный | `[verified-by-MCP: C-XSV-03]` $22.9 (FMI) | Online (Amazon + Chewy ~39%, см. R4) | Fun & emotional, premium DTC | legacy + MCP |
| Канада | ~$0.1 млрд (≈5% от США) | ~5% | ~$20 близко к США `[legacy-unverified]` | Mix import + local | Эко, климатическая практичность | legacy |
| Германия | ~$0.3-0.4 млрд (крупнейший в Европе); 20-25% EU cat tree volume | 5-6% устойчивый | $21.8 `[single-source: FMI]` | Mix offline (Fressnapf 50-55% pet beds) + online (Zooplus + Amazon DE 30-35%) | Прагматизм, эко, FSC, vet-approved | legacy + MCP IndexBox |
| Великобритания | ~$0.25-0.3 млрд | ~5% устойчивый | $20.7 `[single-source: FMI]` | E-commerce 35%, Pets at Home offline 65% | Премиум-качество, history бренда | legacy + MCP Euromonitor |
| Франция | ~$0.2 млрд | ~5% устойчивый | ~$18-20 `[legacy-unverified]` | Mix | «Art de vivre», эстетика интерьера | legacy |
| **Италия** ⭐ R1-extend | ~15-18% EU cat tree volume | ~5% устойчивый | без публичных данных | E-commerce + design stores | Notable taste for design-led cat trees in urban areas; small artisans Milano/Roma | `[verified-by-MCP: R1-extend]` |
| **Нидерланды** ⭐ R1-extend | ~7-10% EU cat tree volume; major trade hub | ~5-6% | без публичных данных | Sophisticated e-commerce | 1.9 млн котов; trade hub re-export; high cat density | `[verified-by-MCP: R1-extend]` |
| **Швеция / Дания / Скандинавия** ⭐ R1-extend | без отдельных cifr, дизайн-стандарт | — | без публичных данных | E-commerce | 72% NA / 68% EU prefer Scandinavian aesthetics | `[verified-by-MCP: R1-extend]` |
| **Бельгия** ⭐ R1-extend | small | ~5% | без публичных данных | E-commerce | Premium-eco, design+circular economy | `[verified-by-MCP: R1-extend]` |
| **Польша / CEE** ⭐ R1-extend | growing volume | growing | low per-cat spend | Mix retail + e-commerce | Cat ownership 35-45% households; secondary warehouse hub | `[verified-by-MCP: R1-extend]` |
| Япония | ~$0.2 млрд | 4-5% зрелый | `[verified-by-MCP: C-XSV-03]` $19.4 (FMI) | Mix offline + online (Amazon JP, Rakuten) | Минимализм, zen & cute, вертикальные комплексы для тесного жилья | legacy + MCP |
| Южная Корея | ~$0.1-0.15 млрд | ~6% высокий | ~$15 `[legacy-unverified]` (Statista shows $38.8 на all pet supplies) | Online (Coupang, Gmarket) + соцсети | «Для детей»: модно, инстаграмно, smart-tech (LG AeroCat) | legacy + Statista |
| Китай | ~$0.7-0.8 млрд (21.5% APAC) | 6-8% бурный | $14.6 `[single-source: FMI]` (Statista shows $8.7 на all pet supplies — другой scope) | Online (Tmall, JD, соцкоммерция Xiaohongshu) | Polarised: масс-фабрики vs Vetreska cute & fun | legacy + Statista |
| **Гонконг** ⭐ R1-extend | premium smart segment | — | без публичных данных | E-commerce + retail | LG AeroCat HK$5,990 launch Aug 2025 → premium smart pet-tech segment | `[verified-by-MCP: R1-extend]` |
| **Сингапур** ⭐ R1-extend | premium smart segment | — | без публичных данных | E-commerce | LG AeroCat S$799-899 launch Jul 2025 | `[verified-by-MCP: R1-extend]` |
| Австралия | ~$0.08 млрд | ~5% | $20+ `[legacy-unverified]` (Statista $226 all pet supplies) | Mix | Высокий уровень владения, эко | legacy + Statista |
| Швейцария | premium import market | — | — | DE-imports | MiaCara CHF prices, premium-tier consumer | `[mcp-partial]` |

⭐ — добавлены через MCP R1-extend.

### Ценовая шкала по основным категориям

| Категория | Эконом | Средний | Премиум | Люкс |
|---|---|---|---|---|
| Простая когтеточка | $5-30 (Amazon, китайский импорт) | $30-80 (Catit Vesper Lite) | $100-200 | $300-1000+ |
| Многоуровневое «дерево» 2-3 уровня | $50-100 (PetFusion, Frisco) | $100-300 (Catit Vesper V-High) | $300-600 | $600-3000+ |
| Многоуровневое «дерево» 4+ уровней | $80-200 | $200-400 | $400-900 (Refined Feline Lotus ~$400 `[mcp-corrected: C-XSV-11]`) | $900-3000+ (RINN NEKO `[verified-by-MCP: C-XSV-07]` ¥1,000,000 ≈ $7-9k) |
| Лотковая тумба (litter cabinet) | — | $80-200 | $200-500 (Tuft+Paw Cove `[verified-by-MCP: C-XSV-10]` $199 USD) | $500-1500+ |
| Настенная система | DIY 50-200 | $150-400 | $400-1000 (MiaCara Alto `[mcp-corrected: C-XSV-12]` от $565) | $1000-3000+ (Goldtatze bespoke, Hicat потолочные столбы) |
| Лежанка / гамак | $15-40 | $40-100 | $100-300 | $300-1500+ (Meyou Paris коконы) |
| Smart cat furniture | — | — | от $300 | $600-800 (LG AeroCat) |

**Контекстная информация.** В Германии диапазон pet beds сосредоточен в €80-200, что подтверждается IndexBox 2026. В Японии диапазон cat trees ¥2,000 - ¥150,000 (Iris Ohyama бюджет → RINN люкс). В Корее ₩100k-₩500k (LuxyCat, Milliong). В Китае ¥100-¥2,000 на массовом онлайне (HOOPEET, MIDOLY) + premium ¥2,000+ (Vetreska, Pidan Studio). Граница «премиум» начинается в США на ~$200-300, в Европе — €200-300, в Японии — ¥30,000-50,000, в Корее — ₩200,000-300,000.

### Выбор 5 стран для глубокого разбора в R2-R5

Из 16-17 стран в широком скрининге для глубокого разбора в R2-R5 выбраны **5 ключевых: США, Германия, Великобритания, Япония, Китай**. Обоснование выбора по 3 критериям:

| Страна | Размер рынка | Культурная значимость для категории | Наличие данных |
|---|---|---|---|
| **США** | Крупнейший: ~40% NA pet furniture, ~$574 млн food halls + cat tree сегмент | Главный поставщик дизайн-трендов (Tuft+Paw furniture-first), стандарт DTC-механики, US-инфраструктура Amazon/Chewy | Высокое: IBISWorld, APPA, IndexBox, DataIntelo, VMR |
| **Германия** | Крупнейший EU: ~$0.3-0.4 млрд, 20-25% EU cat tree volume | Стандарт качества и sustainability, FSC-эстетика (MiaCara, Goldtatze), Vet-approved дискурс | Высокое: ZZF 2024 report, IndexBox DE Pet Bed Market, FEDIAF, Euromonitor |
| **Великобритания** | ~$0.25-0.3 млрд | Премиум-качество и история бренда (Hicat, Catipilla); связка с дизайн-каналом (design-stores) | Высокое: Euromonitor UK, NABMA market data, design-media |
| **Япония** | ~$0.2 млрд | Эталон minimalist / zen эстетики и compact-living решений (RINN, Karimoku Cat, depachika формат); поставщик art-piece premium-стандарта | Среднее: JDSA, USDA Japan 2025, Modern Cat, Designboom |
| **Китай** | ~$0.7-0.8 млрд, 21.5% APAC; самый быстрорастущий | Полярный рынок: масс-фабрики vs viral premium (Vetreska); образец photogenic-driven маркетинга и соцкоммерции; smart pet-tech early adoption | Среднее: USDA China 2025, Moojing Global, Tmall публичные данные, FMI Modern |

**Резерв на следующий уровень детализации** (без полного deep-dive в R2): **Южная Корея** (быстрорастущий премиум-рынок + smart pet-tech via LG AeroCat) и **Италия** (R1-extend: 15-18% EU cat tree volume + Susy FSC + Catit IT присутствие; design-led культурно). Их данные включены в R1 и R2 сводных таблицах, но без отдельных страновых блоков.

**Что НЕ вошло в 5 deep:** Канада (рынок-сателлит US, культурно совпадает), Франция (`[legacy-unverified]` cifry, нет independent брендов первого ряда в данных), Австралия (малый объём, культурная специфика к US близка), Нидерланды/Бельгия/Скандинавия (R1-extend через IndexBox EU, но без отдельных страновых-объёмных данных). Эти страны представлены в R2 каталоге игроков и R6 трендах, но не дублируются деталями.

---

## R2. Каталог международных игроков

### Связный текст: ландшафт по странам

**США.** Соседствуют масс-производители (PetFusion, MidWest Homes for Pets, Go Pet Club, Frisco) и D2C-дизайнерские стартапы (Tuft + Paw, The Refined Feline, Catastrophic Creations, Mau Lifestyle). Премиум-стандарт сегмента — «furniture-first design»: отказ от зоомагазинной эстетики, мебель для кошки как интерьерный объект. Один игрок — Tuft + Paw — функционирует как эталон в категории через слоган «Not your grandma's cat furniture», сотрудничество с фелинологами, флагман Cove (тумба-туалет) `[verified-by-MCP: C-XSV-10]` стабильно $199 USD с 2021 года. По данным IndexBox US Cat Tree Marketplace 2026: 817 offers, 34 distinct brands, средняя цена $96.70, общее число отзывов 763,446, средний рейтинг 3.82 (что указывает на широко распространённые проблемы восприятия качества в эконом-сегменте). Лидеры по reviews — Yaheetech, Go Pet Club, Feandrea.

**Канада.** Рынок близок к США. Catit (HQ Канада) известен глобально через линию Vesper (модульная мебель дерево+sisal). Ремесленники продают через Etsy. EcoCat Furniture позиционируется через переработанную древесину.

**Германия.** Trixie — крупнейший масс-производитель Европы (бюджет → mid-range). Kerbl — каталог зоотоваров. MiaCara — премиум-дизайн, минимализм, FSC-дерево, эко-упаковка без пластика; диапазон `[mcp-corrected: C-XSV-12]` €169 (Parete отдельный модуль) — $565+ (Alto Wall Climber базовая структура), аксессуары от €25. Goldtatze — бутиковый супер-премиум стеновых комплексов под индивидуальный заказ. LucyBalu (Мюнхен) — премиум-D2C, основан в июле 2019, известен через `[mcp-corrected: C-XSV-06]` PR-кооперацию с Choupette (кошка Карла Лагерфельда) через её хранителя Françoise Caçote в начале 2020 года (Лагерфельд умер 19 февраля 2019 — за ~5 месяцев до основания бренда; физически гамак не покупал — это была кооперация с командой Choupette после смерти Лагерфельда); Limited Edition SWING × Choupette запущена 7 октября 2020 через Instagram Choupette; UK launch сентябрь 2020; 2022 Future On Stage Award; 2024 Maison & Objet Paris appearance (привезли Choupette несмотря на правило no-animals).

**Франция / Великобритания.** Zolux (FR, масс), PIDAN (азиатско-французский минимализм), Meyou Paris (премиум коконы, made in France). UK: Pets at Home (retailer own brand, эконом-mid), Rosewood Pet (нишевый mid), Hicat (премиум-bespoke потолочные столбы под заказ), Catipilla (премиум настенные дорожки), Pet Rebels (UK дистрибуция). RHRQuality (HQ Netherlands, Cartografenweg 34, Waalwijk; представлен в UK и 15 European countries) `[mcp-corrected: C-XSV-08]` специализация на крупных породах подтверждена (модели Maine Coon Lounge, Maine Coon Tower Plus, Royal Cat Palace XXL до 12 кошек одновременно), warranty — 1 год (не 2, как утверждалось в legacy), sisal 12-20 cm thick, нагрузка до 40 кг, 500,000+ satisfied customers per RHR official.

**Италия / Нидерланды / Скандинавия / Бельгия (R1-extend).** Италия: Susy® — FSC-сертифицированный картон, made in Italy, 100% recyclable. Нидерланды: Mikaste — sustainable Japandi премиум; RHRQuality (производство и HQ). Швеция: Cat Flat by 24Storage — премиум-кабинет (walnut veneer) со скрытыми внутри уровнями для кошки и FSC-материалами, дизайнер Eleonor Moschevitz. Дания: Kattens No.1 — модульные когтеточки. Бельгия: Twisting Cat — Twist модель 2-в-1 (designer cat tree + scratching post), recycled wood + cardboard, made in Belgium.

**Япония.** RINN (бутиковый дизайнер, NEKO Cat Tree `[verified-by-MCP: C-XSV-07]` ¥1,000,000 excl. tax, limited 22 units/year, дизайнер Yoh Komiyama; материалы: Greek marble base, Japanese hardwood Hida region, Kvadrat textile Denmark, Japanese hemp rope; запуск 2017; design-media coverage в Designboom, Modern Cat, Japan Design Net, Yanko Design). Karimoku Cat — extension мебельного бренда, японский дизайн (продаётся через MadeMoggie в Австралии). Dinos Pet — отдел известного каталога Dinos, коллаборации с дизайнерами. Iris Ohyama — масс-производитель бюджетных когтеточек. Мастерские г. Окава — миниатюрная кошачья мебель.

**Южная Корея.** Milliong (Миллионг) — дизайн-студия, локальное премиум-кородерево, выставка Seoul Design Fair. LuxyCat — премиум-D2C, натуральное дерево, кастом, планы экспансии. Purrmunn, Ggotjirak — нишевые эстетические лежанки.

**Китай.** Vetreska — вирусный кактусовый дизайн (продавался через Urban Outfitters и Jackson Galaxy shop в США), «whimsy & fun» УТП. Pidan Studio (Шанхай) — минимализм, дизайнерские награды. HOOPEET, MIDOLY — популярные на Tmall mid-производители. Xiaomi Youpin — smart кошачий домик с климат-контролем (экосистема Xiaomi).

**Smart / IoT segment (cross-country).** LG PuriCare AeroCat Tower — серийный smart cat furniture продукт, запущен в Корее, расширен в Сингапуре (July 2025, S$799-899), Гонконге (August 2025, HK$5,990 ≈ $760), Малайзии. Интегрирует air purification + heated dome seat + pet care tracking через LG ThinQ app. PETKIT — pet-tech категория (Purobot Ultra automatic litter box с AI camera, 2024-2025), близкая категория к smart pet furniture.

### Сводная таблица — 42+ международных игрока (расширенная относительно legacy)

| Игрок | Страна | Тип | Ярус | Каналы | Verification |
|---|---|---|---|---|---|
| PetFusion | США | Масс-D2C | Эконом-средний ($50-150) | Amazon, Chewy | `[legacy-unverified]` |
| MidWest Homes for Pets | США | Масс-D2C | Эконом-средний | Amazon, Petco, Chewy | `[legacy-unverified]` |
| Go Pet Club | США | Масс-D2C | Эконом ($50-150) | Amazon | `[legacy-unverified]` |
| Frisco | США | Retailer label (Chewy) | Эконом ($30-100) | Chewy эксклюзив | `[legacy-unverified]` |
| Yaheetech | США / global | Масс-D2C | Эконом (~$53) | Amazon, Walmart | `[verified-by-MCP: IndexBox]` |
| Feandrea | США / global | Масс-D2C | Эконом-средний (~$106) | Amazon | `[verified-by-MCP: IndexBox]` |
| Tuft + Paw | США | Премиум-D2C | Премиум | tuftandpaw.com, Instagram, Amazon | `[verified-by-MCP: C-XSV-10]` (Cove $199 USD) |
| The Refined Feline | США | Премиум-D2C | Премиум (~$400) | Amazon, Wayfair, сайт | `[mcp-corrected: C-XSV-11]` |
| Catastrophic Creations | США | Премиум-D2C, DIY | Премиум ($200-500) | Etsy, сайт, Instagram | `[legacy-unverified]` |
| Mau Lifestyle | США | Премиум-D2C | Премиум | сайт, Instagram | `[legacy-unverified]` |
| Frond Design Studios | США | Премиум-D2C | Премиум | сайт | `[verified-by-MCP: FMI Modern]` |
| Catit (Vesper) | Канада → global | Премиум-D2C | Средний-премиум ($100-150) | сайт, Amazon, retail | `[legacy-unverified]` |
| Bailey & Bella | Канада | D2C | Средний | сайт | `[legacy-unverified]` |
| EcoCat Furniture | Канада | Premium-eco | Премиум | сайт | `[legacy-unverified]` |
| Trixie | Германия | Масс-производитель | Бюджет-mid | Зоомагазины ЕС, Amazon | `[legacy-unverified]` |
| Kerbl | Германия | Масс-производитель | Бюджет-mid | Зоомагазины, Amazon | `[legacy-unverified]` |
| MiaCara | Германия | Премиум-дизайн | Премиум €169 - $565+ | сайт miacara.com | `[mcp-corrected: C-XSV-12]` |
| Goldtatze | Германия | Бутиковый супер-премиум | Люкс | сайт, под заказ | `[legacy-unverified]` |
| Catwalk Systems | Германия | Премиум-модульный | Премиум-люкс | сайт | `[legacy-unverified]` |
| LucyBalu | Германия (Мюнхен) | Премиум-D2C | Премиум | сайт, дизайн-сторы | `[mcp-corrected: C-XSV-06]` (Choupette story corrected) |
| Karlie | Германия | Mid-производитель | Mid | Retail | `[verified-by-MCP: FMI Modern]` |
| Zolux | Франция | Масс-производитель | Mid | Зоомагазины, онлайн | `[legacy-unverified]` |
| PIDAN | Франция/Азия | Премиум-дизайн | Премиум | сайт, retail | `[legacy-unverified]` |
| Meyou Paris | Франция | Премиум-D2C | Премиум | meyou-paris.com, made in France | `[verified-by-MCP]` (сайт активен) |
| FancyPets × Nendo | Франция | Премиум-коллаборация | Люкс | сайт | `[legacy-unverified]` |
| Pets at Home | UK | Retailer Own Brand | Эконом-mid | Pets at Home retail, сайт | `[legacy-unverified]` |
| Hicat | UK | Premium-bespoke | Люкс | под заказ | `[legacy-unverified]` |
| Catipilla | UK | Премиум-D2C | Премиум | сайт | `[legacy-unverified]` |
| Rosewood Pet | UK | Mid-производитель | Mid | Retail | `[legacy-unverified]` |
| Pet Rebels | UK / NL | Дистрибьютор-премиум | Премиум | Retail UK | `[legacy-unverified]` |
| Archie & Oscar | UK | Premium-D2C | Премиум | сайт | `[verified-by-MCP: FMI Modern]` |
| Omlet | UK | Premium-D2C | Премиум | сайт | `[verified-by-MCP: FMI Modern]` |
| Made.com | UK | Lifestyle retailer | Mid-premium | сайт | `[verified-by-MCP: FMI Modern]` |
| RHRQuality | Нидерланды → UK, 15 стран | Премиум-нишевый | Премиум | rhrquality.com, rhrpets.com | `[mcp-corrected: C-XSV-08]` |
| Mikaste | Нидерланды | Премиум sustainable Japandi | Премиум | mikaste.com | `[verified-by-MCP: R1-extend]` |
| Susy | Италия | FSC-eco D2C | Mid (cardboard) | susy.pet | `[verified-by-MCP: R1-extend]` |
| Twisting Cat | Бельгия | Премиум sustainable | Премиум | twistingcat.com, made in Belgium | `[verified-by-MCP: R1-extend]` |
| IKEA (Lurvig 2017 / Utsådd 2024) | Швеция → global | Mass-cross-category | Эконом-средний | IKEA stores | `[legacy-unverified]` |
| Cat Flat by 24Storage | Швеция | Премиум-кабинет дизайн | Премиум | 24Storage / design стор | `[verified-by-MCP: R1-extend]` |
| Kattens No.1 | Дания | Премиум-модульный | Премиум | сайт, retail | `[legacy-unverified]` |
| Modernist Cat | Северная Америка | Mid-mid-century modern | Mid-premium ($99-1159) | сайт | `[verified-by-MCP: Apartment Therapy]` |
| Hilde & Phil | США | Premium-furniture-integrated | Премиум ($379+ Cat-e-Corner) | сайт | `[verified-by-MCP: Apartment Therapy 2025]` |
| KATRIS | США | Premium-modular | Премиум | сайт | `[verified-by-MCP: Dwell]` |
| Aelfie × Yarinsky | США (Brooklyn) | Premium-art | Премиум | Cooler Gallery | `[verified-by-MCP: Dwell]` |
| RINN | Япония | Бутиковый дизайнер | Люкс ¥1M | сайт, design-stores | `[verified-by-MCP: C-XSV-07]` |
| Dinos Pet | Япония | Каталог-ритейлер | Mid-premium | Dinos | `[legacy-unverified]` |
| Iris Ohyama | Япония | Масс-производитель | Бюджет (¥1,000-3,000) | Amazon JP, Rakuten | `[legacy-unverified]` |
| Karimoku Cat | Япония | Премиум-D2C (extension) | Премиум-люкс | сайт, MadeMoggie AU | `[legacy-unverified]` |
| Milliong (Миллионг) | Корея | Премиум-дизайн | Премиум-люкс | соцсети, Seoul Design Fair | `[legacy-unverified]` |
| LuxyCat | Корея | Премиум-D2C | Премиум | сайт, планы экспансии | `[legacy-unverified]` |
| Vetreska | Китай | Премиум-D2C, viral | Mid-премиум | соцсети, Tmall, Urban Outfitters US | `[legacy-unverified]` |
| Pidan Studio | Китай (Шанхай) | Премиум-дизайн | Премиум | сайт, retail | `[legacy-unverified]` |
| HOOPEET / MIDOLY | Китай | Mid-производители | Mid (¥100-2000) | Tmall, JD | `[legacy-unverified]` |
| Xiaomi Youpin | Китай | Smart pet-tech | Mid-premium | Xiaomi экосистема | `[legacy-unverified]` |
| LG (PuriCare AeroCat) | Корея → SG, HK, MY | Smart pet-tech | Премиум (S$799-899, HK$5,990) | LG online + retail | `[verified-by-MCP: R7-errors related]` |
| PETKIT | Китай → SEA | Pet-tech | Премиум | сайт, Amazon | `[verified-by-MCP]` |
| Nipa | США | Eco-D2C (cork) | Mid-премиум | сайт | `[legacy-unverified]` |
| Ware Pet Products | США | Mid-eco | Mid | Amazon, retail | `[legacy-unverified]` |
| ModKitty | США | Eco-D2C (zero plastic) | Mid-premium | сайт | `[verified-by-MCP]` |
| Shichic | США | Eco-D2C (recycled oak) | Mid | сайт | `[verified-by-MCP]` |

**Итого:** 50+ международных игроков с типологией. v1.1 R2 gate (≥15) — покрытие x3+.

---

## R3. Продуктовая матрица — мировые форматы

### Связный текст

Категория мебели для кошек включает 13+ форматов, организованных вокруг трёх функциональных групп: рекреация (когтеточки, кошачьи деревья), укрытие (домики, тоннели, тумбы-домики), интеграция в человеческую мебель (мебель 2-в-1, лотковые тумбы, столики-лежанки). Доминируют два эстетических направления: «плюшево-ковровый» традиционный (мягкие конструкции с ковролином, исторически с 1980-х в США) и «модерн» (дерево, металл, канат, минимализм). Премиум-сегмент построен на «модерн»-коде: натуральное дерево (дуб, бук, береза) или качественная фанера с шпоном, устойчивые ткани (мебельная ткань, шерсть, искусственный мех Memory Foam), сизалевое полотно (или конопляный канат у RINN, polyamide у MiaCara Alto).

Растущие подкатегории — лотковые тумбы (litter cabinets: Tuft+Paw Cove $199, Goldtatze bespoke), модульные настенные системы (Catastrophic Creations, Catwalk Systems, MiaCara Alto, Catipilla), мебель 2-в-1 (Hilde & Phil Cat-e-Corner $379, Karimoku Cat книжные полки с кошачьим лазом). Эко-материалы выходят отдельной осью: FSC-сертифицированное дерево (MiaCara, Goldtatze), recycled materials (Susy cardboard, Twisting Cat wood+cardboard, Nipa cork, Ware Pet recycled), мицелий и biomaterials (исследовательский ярус). Smart-furniture категория начала переходить из концептов в серийное производство в 2024-2025: LG PuriCare AeroCat Tower с IoT-tracking (S$799-899, HK$5,990) — первый кросс-страновой серийный smart cat furniture продукт. Xiaomi Youpin smart cat domik с климат-контролем — китайский серийный. PETKIT pet-tech (близкая категория — auto litter boxes с AI camera).

### Сводная таблица — 13+ форматов

| Формат | Размеры | Эконом | Mid | Премиум | Люкс | Примеры |
|---|---|---|---|---|---|---|
| Простая когтеточка-колонна | 50-80 см | $5-30 | $30-60 | $60-150 | $150+ | Trixie, Kerbl, Iris Ohyama |
| Многоуровневое «дерево» 2-3 уровня | 100-150 см | $50-100 | $100-300 (Catit Vesper V-High ~$100) | $300-600 | $600+ | Vesper, Catit |
| Многоуровневое «дерево» 4+ уровней | 170-210 см | $80-200 | $200-400 (Yaheetech ~$53 avg, Feandrea ~$106 avg) | $400-900 (Refined Feline Lotus ~$400 `[mcp-corrected]`) | $900-7,500+ (RINN NEKO ¥1M `[verified-by-MCP: C-XSV-07]`) | Lotus, NEKO, Maine Coon Tower |
| Домик-тумба / cat condo | различные | — | $80-200 | $200-500 | $500-2000+ | RHRQuality Cat Penthouse, Vesper House |
| Лотковая тумба (litter cabinet) | как тумба | — | $100-250 | $250-500 (Tuft+Paw Cove $199 USD `[verified-by-MCP: C-XSV-10]`) | $500+ (Goldtatze bespoke) | Cove, Cat Flat 24Storage |
| Лежанка / гамак | разные | $15-40 | $40-100 | $100-300 | $300-1500+ (Meyou Paris коконы, LucyBalu SWING × Choupette) | Mau plush, Meyou |
| Настенная модульная система | DIY / собирная | DIY $50-200 | $200-500 | $500-1500 (MiaCara Alto от $565 `[mcp-corrected: C-XSV-12]`) | $1500+ (Goldtatze, Hicat) | Alto, Catastrophic, Hicat |
| Настенные полки / ступени | элементы | $10-30 шт | $30-80 шт | $80-200 шт (MiaCara Parete €169) | $200+ шт | Parete, Catipilla |
| Картонная конструкция | разная | $20-50 | $50-100 (Susy FSC) | — | — | Tomeow, Susy, Ware Pet |
| Bespoke потолочный столб | под потолок | — | — | $1000-3000 | $3000+ | Hicat |
| Мебель 2-в-1 (стол / диван / комод + зона для кошки) | как обычная мебель | — | $200-500 | $500-1500 (Cat-e-Corner $379, Cat Flat) | $1500+ (Karimoku Cat) | Hilde & Phil, Karimoku |
| Smart cat furniture | разная | — | — | $300-900 (LG AeroCat S$799-899) | $900-1500+ | LG AeroCat, Xiaomi Youpin |
| Eco / FSC / mycelium | разная | $30-100 (картон) | $100-300 (FSC entry) | $300-800+ (MiaCara, Twisting Cat) | — | Susy, Twisting Cat, MiaCara, Mikaste |

**Контекстная информация по трендам ассортимента.**

- **Модульность как сквозной принцип** — подтверждено в MCP add-on. Тренд multi-source: `[verified-by-MCP: Cross-3]` (DataIntelo, FMI Modern, ResearchAndMarkets, Pmarketresearch — модульность / customization как key driver). Конкретная цифра «48% expecting bespoke» — `[verified-by-MCP: C-XSV-05]` (Tavily-сверка дословной цитаты FMI) + `[single-source: FMI]` (кросс-верификация не найдена в не-FMI источниках).
- **Растущая категория lotковых тумб** — Tuft+Paw Cove (`[verified-by-MCP: C-XSV-10]` $199 USD), Goldtatze litter cabinets bespoke. Тренд connected с pet humanization (скрыть «зооэлемент» в интерьерном объекте).
- **Эко-материалы** — отдельная ось дифференциации (R9 verdict #5 PASS).
- **Интеграция с мебелью для людей** — IKEA Lurvig 2017, Utsådd 2024; Karimoku Cat; Hilde & Phil Cat-e-Corner.
- **Smart cat furniture** — серийное производство стартовало 2024-2025 (LG AeroCat кросс-страновой запуск Korea → SG/HK/MY).

---

## R4. Каналы продаж, customer journey, сервис

### Связный текст

Customer journey варьируется по странам. В США онлайн-доминанта: запрос («best cat tree») → обзоры (Wirecutter, YouTube) → отзывы Amazon → покупка через Amazon или D2C-сайт. Главные ожидания: бесплатная доставка, простой возврат 30 дней, рассрочка через Affirm / Klarna. В Европе (особенно Германия) — более длинный путь исследования: форумы, Facebook-группы, частичный визит в зоомагазин. По данным `[verified-by-MCP: C-XSV-09 corrected]`: точная цифра «50% Europe offline» не подтверждена; Германия pet beds — Fressnapf (offline specialist) 50-55% sales share, Zooplus + Amazon DE 30-35%, e-commerce penetration прогнозируется до 40-45% к 2030. UK pet care — e-commerce 35% sales share (Euromonitor), specialty stores и superstores лидируют offline. В Китае customer journey преимущественно цифровой через смартфон: соц-видео в Xiaohongshu → ссылка → Tmall / JD. В Японии historically начинается с физического магазина (Pet Tokyo Expo и островные форматы), хотя онлайн растёт.

### Корректировка для канала US — Amazon + Chewy

`[verified-by-MCP: Re-1]` Реальная доля Amazon + Chewy в продажах cat furniture в США:

- Online channel в категории cat scratching post / cat furniture = ~48.3% всего рынка (DataIntelo 2025; $1.55 млрд от total $3.21 млрд).
- Amazon = ~48% e-commerce share в pet category (Verified Market Research 2026).
- Chewy = ~33% click share в pet category (VMR).
- Совместно Amazon + Chewy = ~81% online pet retail.
- **Итоговая доля Amazon + Chewy ≈ 39% от total US cat furniture sales** (48.3% online × 81% within-online ≈ 39%).

Legacy формулировка «до 60-70% продаж приходится на Amazon + Chewy» **опровергнута**: это относилось к pet e-commerce в целом, не к мебели для кошек. Скорректированная формула: ≈39% от total US cat furniture sales.

### Сводная таблица каналов

| Канал | Регион | Доля | Тип / специфика | Примеры |
|---|---|---|---|---|
| Amazon | US, EU, JP, AU | ~48% online pet | Алгоритмическое продвижение, отзывы | All masс-tier + некоторые D2C |
| Chewy | US (главный), Canada | ~33% online pet, ~75% subscription | Autoship программа (84% от net sales Chewy), telehealth интеграция, выше customer loyalty | Frisco private label, Mid-tier |
| Zooplus | EU (Germany, NL, FR, IT) | ~25-35% e-commerce DE pet | Прямой ассортимент | Trixie, Kerbl, MiaCara, Catit |
| Собственный сайт D2C | Premium global | Premium core canal | Customisation, brand stories, AR в редких случаях (Clawz US) | Tuft+Paw, MiaCara, RHRPets, Refined Feline |
| Wayfair | US | Premium mid | Furniture-positioning, 852 reviews 4.7/5 для Refined Feline Lotus | Refined Feline |
| Design stores (MoMA, DWR, Apartment Therapy shop) | US | Niche premium | Curated assortment | Modernist Cat, Karimoku Cat |
| Pets at Home | UK | Retailer chain | Own brand + premium-tier select | UK игроки |
| Fressnapf | DE / EU | ~50-55% pet beds DE | Premium specialty chain (1,500+ stores) | DE и cross-EU premium |
| Tmall / JD / Xiaohongshu | China | Online dominance | Соцкоммерция, 5-минутная ценовая конкуренция | Vetreska, HOOPEET, MIDOLY |
| Coupang / Gmarket | Korea | Online dominance | Соцсети + e-commerce | Milliong, LuxyCat |
| Amazon JP / Rakuten | Japan | Growing online | Mix с offline retail | Iris Ohyama, Karimoku |
| Etsy / Local artisans | Global niche | Marginal | Кастом, ручная работа | Региональные мастерские |
| LG online + retail | Korea, SG, HK, MY | Brand chain | Smart pet-tech | LG AeroCat |

### CX-кейсы (10+ из разных стран и ярусов)

| Кейс | Игрок | Регион | Описание | Verification |
|---|---|---|---|---|
| Перчатки для сборки в комплекте | Tuft + Paw | США | Wow-эффект premium-распаковки | `[legacy-unverified]` |
| Эко-упаковка без пластика, бумажный скотч | MiaCara | DE | Часть бренд-кода sustainability | `[legacy-unverified]` |
| Запасные части в комплекте (коврик / sisal) | Refined Feline | США | Снижает trouble после месяцев использования | `[legacy-unverified]` |
| 30-day satisfaction guarantee | Tuft + Paw, многие US D2C | США | Снижает purchase risk | `[legacy-unverified]` |
| Рассрочка Affirm / Klarna | US/EU премиум-D2C | США, EU | Снижает финансовый барьер для premium-цены | `[legacy-unverified]` |
| Контент-сообщество с фелинологами + блог | Tuft + Paw | США | Содержательный маркетинг вместо лояльности | `[legacy-unverified]` |
| Bespoke под-потолок-заказ через консультацию | Hicat | UK | Премиум-канал с длинным циклом | `[legacy-unverified]` |
| AR-примерка модели в интерьере | Clawz | США | Единичный случай в категории, слабый сигнал | `[legacy-unverified]` |
| Программа лояльности Chewy (Autoship 84%) | Chewy | США | Работает для расходников, не для мебели напрямую | `[verified-by-MCP: VMR]` |
| Аренда мебели Kitty Rental | Kitty Rental | США | Подписочная модель, слабый сигнал | `[legacy-unverified]` |
| Smart-tracking через ThinQ app | LG AeroCat | Korea/SG/HK | Pet care tracking как часть продукта | `[verified-by-MCP]` |
| Limited Edition сотрудничество | LucyBalu × Choupette | DE | PR-кампания через известную кошку (2020) | `[mcp-corrected: C-XSV-06]` |

---

## R5. Офферы и обещания

### Связный текст

В международной премиум-категории доминируют 5 типов обещаний: (1) furniture-first — «мебель, которая не выглядит как зоотовары»; (2) натуральные материалы (FSC, sustainable, recycled); (3) прочность для крупных кошек / lifetime warranty / специализация; (4) ручная работа / авторский подход; (5) кастом / made-to-order. В масс-сегменте офферы упрощаются до функциональных аргументов: цена, ассортимент, доступность через Amazon.

Региональная специфика. США: эмоциональный, часто с юмором, «for life with cats», «not your grandma's». Германия / Скандинавия: техничный, «надёжность», «Vet-approved», sustainability claims. Италия / Франция: эстетика, «élégance pour votre chat», «art de vivre». Япония: kawaii + zen, «комфорт питомца и уважение к пространству дома», miniature scale. Корея: «smart design for smart pet parents», технологичность. Китай: акции и виральность («первые 100 заказавших — игрушка в подарок»), photogenic-driven.

### Таблица — 10+ офферных формулировок с verification

| Игрок | Страна | Ярус | Цитата | Мотив | Verification |
|---|---|---|---|---|---|
| Tuft + Paw | США | Премиум | «Not your grandma's cat furniture» | Эстетика, отстройка от зоомагазина | `[verified-by-MCP: R7-errors related, Tuft+Paw site]` |
| Tuft + Paw | США | Премиум | «For life with cats» | Эмоциональная связь | `[legacy-unverified · no-url-in-legacy → URL reconstruct в HTML-BRIEF]` |
| Tuft + Paw | США | Премиум | «Your home deserves better» | Эстетика интерьера | `[legacy-unverified · no-url-in-legacy → URL reconstruct в HTML-BRIEF]` |
| IKEA Lurvig | Швеция | Эконом-средний | «Designed by pet lovers, tested by pets. Because their home is your home too» | Демократичный premium, гармония | `[legacy-unverified · no-url-in-legacy → URL reconstruct в HTML-BRIEF]` |
| Catit (Vesper) | Канада | Средний | «Luxury cat furniture that won't be an eyesore» | Эстетика, оппозиция к outdated | `[legacy-unverified · no-url-in-legacy → URL reconstruct в HTML-BRIEF]` |
| Vetreska | Китай | Mid-премиум | «Позвольте вашему пушистому другу отправиться в пустынное приключение с нашим кактусовым деревом» | Эмоция, фантазия, vibrancy | `[legacy-unverified · no-url-in-legacy → URL reconstruct в HTML-BRIEF]` |
| Nipa | США | Mid-eco | «Our tree was a tree» | Эко, материал | `[legacy-unverified · no-url-in-legacy → URL reconstruct в HTML-BRIEF]` |
| MiaCara | Германия | Премиум | «Möbel, die Katze und Mensch gefallen» | Гармония, дизайн | `[legacy-unverified · no-url-in-legacy → URL reconstruct в HTML-BRIEF]` |
| Meyou Paris | Франция | Премиум | «L'élégance pour votre chat» | Элегантность | `[legacy-unverified · no-url-in-legacy → URL reconstruct в HTML-BRIEF]` |
| RHRQuality | Нидерланды | Премиум-нишевый | «Cat furniture for big cats» (англ.) | Прочность, специализация на крупных | `[mcp-corrected: C-XSV-08]` (warranty 1 yr) |
| LucyBalu | Германия | Премиум | «Sinnvolle und zeitlos schöne Katzenmöbel» (осмысленная и вневременная красивая мебель для кошек) | Sustainability, timeless | `[verified-by-MCP: C-XSV-06]` сайт LucyBalu |
| Twisting Cat | Бельгия | Премиум-eco | «Sustainable design and feline well-being go hand in hand» | Eco + welfare | `[verified-by-MCP: R1-extend]` |
| Susy | Италия | Mid-eco | «Beautiful, practical, and 100% recyclable. Purr-fect for stylish cats» | FSC + design | `[verified-by-MCP: R1-extend]` |
| Mikaste | Нидерланды | Премиум | «Award-winning Cat furniture that lasts a lifetime both in human and cat years» | Durability + design | `[verified-by-MCP: R1-extend]` |
| LG AeroCat | Korea | Премиум smart | «Purify your air, pamper your cat» | Smart + wellness | `[verified-by-MCP]` |

---

## R6. Тренды, слабые сигналы, угрозы

### Макротренды (6 подтверждённых)

1. **Pet humanization** — фундаментальный driver. Питомец как член семьи, готовность тратиться на интерьерный уровень. Подтверждено множеством источников: APPA 2025 Dog & Cat Report; Mordor Intelligence; Euromonitor Western Europe; FMI; IMARC; Mintel. `[verified-by-MCP: multi-source]`

2. **Sustainability** — реальная ось дифференциации, не декларация. FSC-сертифицированное дерево (MiaCara, Goldtatze), recycled materials (Susy cardboard, Twisting Cat, Nipa cork, Ware Pet, ModKitty, Shichic). Регулятивное давление в ЕС (REACH-сертификаты, Prop 65 California). `[verified-by-MCP: R9 verdict #5]`

3. **Tech-integration / Smart cat furniture** — категория начала переход из концептов в серийное производство в 2024-2025. LG PuriCare AeroCat Tower кросс-страновой запуск (Korea → SG/HK/MY). Xiaomi Youpin. PETKIT pet-tech (смежная категория). `[verified-by-MCP: R9 verdict #4]`

4. **Wellness & comfort** — ортопедические лежанки для старых кошек, антимикробные покрытия, monitoring weight/resting через ThinQ-like apps. Аналог human wellness. `[legacy-unverified]` + `[verified-by-MCP: LG]`

5. **Multi-cat households** — большие платформы, дублирование лежаков на разных уровнях. В США 30%+ владельцев имеют ≥2 кошек (Mintel). Платформы RHRQuality Royal Cat Palace до 12 кошек одновременно. `[legacy-unverified]` + `[verified-by-MCP: RHR site]`

6. **Furniture-first design / отказ от зоомагазинной эстетики** — доминирующий premium-код. Тренд multi-source: Apartment Therapy 2017, Dwell 2018, FMI Modern «76% adaptable, 72% NA / 68% EU prefer Scandinavian/minimalist designs». `[verified-by-MCP: multi-source]`

### Слабые сигналы (4+)

1. **AR-примерка для мебели для кошек** (Clawz US, единичный случай) — `[legacy-unverified]`.
2. **Кастомизация через онлайн-3D-конфигураторы** — для мебели для людей уже массово, для cat furniture пока единичные примеры. `[legacy-unverified]`
3. **Аренда / шеринг для питомцев** (Kitty Rental US, отдельные UK стартапы) — `[legacy-unverified]`.
4. **NFT и цифровая составляющая** — пик прошёл, реальная коммерческая категория не сложилась. `[legacy-unverified]`
5. **Cross-category design collaborations** — Karimoku Cat (мебельный бренд → cat extension), IKEA Lurvig/Utsådd, FancyPets × Nendo, Aelfie × Yarinsky (Brooklyn Cooler Gallery). `[verified-by-MCP: Dwell]`

### Угрозы рынку (3+)

1. **Насыщение premium-D2C-рынка post-COVID в США** — те, кто завёл питомца в 2020-2021, уже купили основное. Цикл 3-4 года → возможный спад в 2024-2026. `[legacy-unverified]`
2. **Регуляторные изменения в ЕС** — ASTM разрабатывает стандарты безопасности для зоотоваров, ужесточение требований к воспламеняемости обивки. Барьеры входа растут, выигрывают крупные. `[legacy-unverified]`
3. **Экономические факторы** — инфляция 2022-2023 ударила по discretionary spending; в США premium-сегмент проседал. CBI 2024: 60-66% European consumers «trade down». `[verified-by-MCP: CBI]`
4. **Появление субститутов** — мебель IKEA / West Elm с интегрированной зоной для кошки. Масс-сегмент может перейти из specialized к интерьерным брендам. `[legacy-unverified]` + `[verified-by-MCP: IKEA Lurvig/Utsådd]`
5. **Бифуркация рынка** — IndexBox 2026: «market bifurcating into commoditized high-volume segment vs premium benefit-led segment, hollowing out mid-tier». `[verified-by-MCP: IndexBox]`

---

## R7. Визуал и стиль коммуникации

### Связный текст

Премиум-сегмент построен на «quiet luxury»: студийная съёмка изделия в интерьерах с реальной кошкой; нейтральные палитры (бежевый, дерево, белый, тёплый чёрный); типографика serif или humanist sans-serif; фотостиль editorial. Доминирующий tone of voice — educational и тёплый, без зоомагазинной инфантильности. Региональная специфика: США — fun & emotional, юмор, сторителлинг (Tuft+Paw блог о кошачьем поведении). Германия — техничный, sustainability claims, цифры. Япония — zen, минимализм, kawaii (милые детали) + утончённость (RINN). Корея — модный, инстаграмный, smart-tech (LG AeroCat). Китай — yarкий, vibrant (Vetreska), либо «cute & fun», либо minimalist в стиле Muji (Pidan Studio).

### Примеры визуала / TOV (4+)

| Игрок | Страна | Визуальный стиль | TOV | Источник verification |
|---|---|---|---|---|
| Tuft + Paw | США | Скандинавское влияние, живые интерьеры, нейтральные палитры, реальные кошки в кадре, editorial photography | Дружелюбный, educational, «for life with cats», научный подход через фелинологов | `[verified-by-MCP: site + Modern Cat]` |
| MiaCara | Германия | Минимализм, FSC-эстетика, эко-упаковка как часть бренд-кода, дизайнерская коллаборация (Hans Thyge & Co для Alto) | Сдержанный, технический, sustainability-фокус | `[verified-by-MCP: C-XSV-12]` |
| Vetreska | Китай | Яркий vibrancy, fantasy storytelling (пустыня + кактус как декорация), photogenic-driven | Whimsical, фантазийный, viral-driven | `[legacy-unverified]` + `[verified-by-MCP: Urban Outfitters US carry]` |
| RINN | Япония | Zen-минимализм, art-piece эстетика, дерево + камень, archetypal modernist sculpture | Спокойный, эстетический, kawaii + utonchennost («cultural fusion East/West») | `[verified-by-MCP: C-XSV-07]` |
| LucyBalu | Германия | Editorial photography with Choupette as ambassador, modern minimalism | Sinnvolle und zeitlos schöne (осмысленная и timeless) | `[verified-by-MCP: C-XSV-06]` |
| Cat Flat 24Storage | Швеция | Walnut veneer, vertical/horizontal slats hiding interior, design-furniture aesthetic | Hidden away, design-first, «sleek when closed» | `[verified-by-MCP: R1-extend, Apartment Therapy]` |

### Типичные ошибки визуала и TOV (новый блок, R7-errors)

Структурированный блок «типичные ошибки» в legacy отсутствовал. На основе MCP add-on (R7-errors) идентифицировано две главные ошибки категории.

**Ошибка №1 — «Зоомагазинная эстетика» (carpet/plush «pet-store» look)**

Что именно: ковровое покрытие (carpet/plush), мутные неестественные цвета, отсутствие интеграции в интерьер, дешёвый текстиль, видимая пластиковая фурнитура. Категория устаревшая, ассоциируется с 1980-2000-ми.

Что транслирует ошибочно: «cheap», «outdated», «противоречит позиционированию». Даже если бренд позиционирует себя как премиум, carpet-covered design нивелирует premium-восприятие.

Live evidence:
- Apartment Therapy 2017: «If you've ever brought home a **carpet-covered cat tree** only to have your cat look at it in disdain».
- Apartment Therapy 2020 (Cat Flat designer Eleonor Moschevitz): «An ordinary piece of cat furniture usually is quite tasteless».
- Dwell 2018 (Aelfie Oudghiri + Michael Yarinsky): «Questioning why mainstream cat accessories were so ugly».
- Apartment Therapy / Dwell критика: «ugly living-room-castle», «mainstream cat accessories so ugly».
- Tuft + Paw кампания «Not your grandma's cat furniture» — позиционируется как явная оппозиция к этой ошибке.

`[verified-by-MCP: R7-errors]`

**Ошибка №2 — «Cheap construction cues» (видимые признаки дешёвого исполнения)**

Что именно: particleboard или laminate материалы, faux mock wood, flimsy конструкция, видимые винты и слабые крепления, шаткость при использовании, нечёткие инструкции, дешёвая фурнитура.

Что транслирует ошибочно: «низкое качество», «не выдержит крупного кота», «недолговечно». Даже если визуал-стиль выбран правильно, дешёвая конструкция перебивает позиционирование. Возможны негативные UGC-отзывы.

Live evidence:
- Apartment Therapy 2025 (Hilde & Phil Cat-e-Corner review): «Instead of **flimsy particleboard or laminate**, Hilde & Phil's design is crafted with sustainably sourced solid hardwood».
- IndexBox US Cat Tree Marketplace 2026: 763k отзывов, **avg rating 3.82** (на фоне 4.49-4.64 у топовых брендов) — «suggests widespread quality perception issues or mismatched expectations» — broad signal cheap-construction жалоб.
- Cat Flat designer Moschevitz: «An ordinary piece of cat furniture usually is quite tasteless» — комбинация design + construction.
- Apartment Therapy 2022 (DIY litter box makeover): описание «very bulky and ugly litter boxes that made me uneasy to look at».

`[verified-by-MCP: R7-errors]`

---

## R8. Источники (source log)

### Связный текст

В этом исследовании 55+ источников использовано суммарно: 27 URL извлечено напрямую из legacy `Dr мир.pdf` (footnotes p.27-28); ~28 URL добавлено через MCP add-on (2026-05-22) для verification, cross-checks и R1-extend. Сгруппированы по типам: industry analytics, design media, brand sites, statistical agencies, retail research, trade press.

### Таблица — ≥25 ключевых источников из MCP add-on

Источники сгруппированы по 5 типам:
- **Brand official** (8 источников) — официальные сайты брендов и пресс-релизы для verification конкретных claims по C-XSV-06..12 и R1-extend.
- **Industry analytics** (11 источников) — отчёты аналитических домов (Mordor, Stratistics MRC, IndexBox, DataIntelo, FMI, ResearchAndMarkets, VMR, Euromonitor, Coherent Market Insights, Moojing) для Cross-1 / Re-1 / R1.
- **Design media** (5 источников) — Designboom, Modern Cat, Dwell, Apartment Therapy, Yanko Design, Japan Design Net для C-XSV-07 / R7-errors.
- **Statistical / industry associations** (3 источника) — Statista, ZZF Germany Pet Market 2024, FEDIAF / CBI для Cross-2 / R1 / R4.
- **Trade press / industry portals** (3 источника) — Maison & Objet, This Is Money UK, TZ München, TGM Research для C-XSV-06 / R6.

| URL | Тип источника | Дата доступа | Что подтверждает |
|---|---|---|---|
| https://lucybalu.com/pages/lucybalu-x-choupette-story | Brand official | 2026-05-22 | LucyBalu × Choupette история (C-XSV-06 corrected) |
| https://www.thisismoney.co.uk/money/smallbusiness/article-8981335/LucyBalu-small-business-got-Karl-Lagerfelds-cat-side.html | UK media (This Is Money) | 2026-05-22 | LucyBalu Choupette UK launch 2020 (C-XSV-06) |
| https://www.maison-objet.com/en/paris/magazine/success-stories/lucybalu-always-be-sincere-and-transparent | Trade fair press | 2026-05-22 | LucyBalu 2024 Maison&Objet appearance (C-XSV-06) |
| https://rinn.co.jp/neko/en/ | Brand official | 2026-05-22 | RINN NEKO Cat Tree ¥1,000,000 (C-XSV-07) |
| https://www.designboom.com/design/sculptural-japanese-neko-cat-tree-costs-1-million-yen-12-27-2017/ | Design media (Designboom) | 2026-05-22 | RINN ¥1M / $7,500 cifra (C-XSV-07) |
| https://moderncat.com/articles/cat-tree-discerning-cat-owner-world/ | Pet design media (Modern Cat) | 2026-05-22 | RINN NEKO premium $8,800 (C-XSV-07) |
| https://www.yankodesign.com/2020/01/25/this-luxuriously-minimal-wooden-tree-is-designed-to-meet-your-cat-and-your-needs/ | Design media (Yanko Design) | 2026-05-22 | RINN design details (C-XSV-07) |
| https://rhrpets.com/en/pages/repair-guarantee | Brand official warranty | 2026-05-22 | RHRQuality 1-year warranty (C-XSV-08 corrected) |
| https://rhrpets.co.uk/pages/about-rhr-quality | Brand official about | 2026-05-22 | RHRQuality Maine Coon specialization, NL HQ |
| https://rhrpets.com/en-de/products/cat-tree-maine-coon-lounge-dark-grey/rhr-quality | Brand product page | 2026-05-22 | Maine Coon Lounge product specs |
| https://www.cbi.eu/market-information/home-decoration-home-textiles/pet-furniture-0/market-potential | EU industry portal (CBI/FEDIAF) | 2026-05-22 | EU pet furniture €24.5B 2022 (C-XSV-09) |
| https://www.euromonitor.com/pet-care-in-western-europe/report | Industry analytics (Euromonitor) | 2026-05-22 | UK e-commerce 35% pet care (C-XSV-09) |
| https://www.indexbox.io/store/germany-kw-pet-bed-840-market-analysis-forecast-size-trends-and-insights/ | Industry analytics (IndexBox) | 2026-05-22 | DE pet beds Fressnapf 50-55% (C-XSV-09) |
| https://tgmresearch.com/europe-pet-care-trends-2024.html | Survey research (TGM) | 2026-05-22 | EU 30% specialty stores preference |
| https://www.tuftandpaw.com/pages/modern-litter-box-short | Brand product page | 2026-05-22 | Tuft+Paw Cove $199 (C-XSV-10) |
| https://www.tuftandpaw.com/collections/litter-boxes | Brand collection | 2026-05-22 | Cove $199 USD confirmation |
| https://www.therefinedfeline.com/product/lotus-cat-tower/ | Brand product | 2026-05-22 | Refined Feline Lotus 1,505 reviews (C-XSV-11) |
| https://www.wayfair.com/pet/pdp/the-refined-feline-69-lotus-cat-tree-aosc1350.html | Retailer (Wayfair) | 2026-05-22 | Lotus 852 reviews 4.7/5 (C-XSV-11) |
| https://miacara.com/en/products/parete-scratchingpanel | Brand product | 2026-05-22 | MiaCara Parete €169 (C-XSV-12) |
| https://miacara.com/en/products/alto | Brand product | 2026-05-22 | MiaCara Alto Wall Climber range (C-XSV-12) |
| https://miacara.com/en/collections/cat-trees | Brand collection | 2026-05-22 | MiaCara overall range |
| https://www.giiresearch.com/report/smrc2037531-designer-pet-furniture-market-forecasts-global.html | Industry analytics (Stratistics MRC) | 2026-05-22 | Designer Pet Furniture $2.3→$4.0B CAGR 6.8% (Cross-1) |
| https://www.mordorintelligence.com/industry-reports/pet-furniture-market | Industry analytics (Mordor) | 2026-05-22 | Pet Furniture $4.27B CAGR 5.98% (Cross-1) |
| https://www.researchandmarkets.com/reports/6027625/cat-furniture-market-global-industry-size | Industry analytics (RM) | 2026-05-22 | Cat Furniture $25.47→$35.76B CAGR 5.82% (Cross-1) |
| https://www.futuremarketinsights.com/reports/modern-cat-furniture-market | Industry analytics (FMI) | 2026-05-22 | Modern Cat Furniture: 76% adaptable, 72%/68% Scandinavian preference (Cross-1 / Cross-3) |
| https://www.statista.com/chart/35896/per-capita-spending-on-pet-companion-animal-supplies/ | Statistical (Statista) | 2026-05-22 | Global pet supplies per-capita 2026 (Cross-2 context) |
| https://www.zzf.de/fileadmin/ZZF/Dokumente/Heimtiermarkt/The_German_Pet_Market_2024.pdf | Industry association (ZZF) | 2026-05-22 | DE pet market 2024 €7.03B |
| https://moojing-global.com/news-research/china-vs-us-per-pet-spend-runway | Industry analytics (Moojing) | 2026-05-22 | China per-pet $95 in 2025 |
| https://dataintelo.com/report/cat-scratching-post-market | Industry analytics (DataIntelo) | 2026-05-22 | Cat scratching post online 48.3% (Re-1) |
| https://www.verifiedmarketresearch.com/blog/top-online-pet-food-and-supplies-companies/ | Industry analytics (VMR) | 2026-05-22 | Amazon 48% / Chewy 33% pet e-commerce (Re-1) |
| https://www.indexbox.io/store/united-states-cat-tree-marketplace-brand-report/ | Industry analytics (IndexBox) | 2026-05-22 | US cat tree 817 offers 763k reviews avg 3.82 |
| https://www.indexbox.io/store/european-union-kw-cat-tree-840-market-analysis-forecast-size-trends-and-insights/ | Industry analytics (IndexBox) | 2026-05-22 | EU cat tree DE 20-25% IT 15-18% NL 7-10% (R1-extend) |
| https://www.mikaste.com/ | Brand official | 2026-05-22 | Mikaste NL sustainable Japandi (R1-extend) |
| https://www.twistingcat.com/product/twist-2-in-1-cat-tree-and-scratching-post/ | Brand official | 2026-05-22 | Twisting Cat Belgium sustainable (R1-extend) |
| https://susy.pet/en/products/cat-house-cube | Brand official | 2026-05-22 | Susy Italy FSC cardboard (R1-extend) |
| https://www.apartmenttherapy.com/cat-flat-cabinet-36716894 | Design media (Apartment Therapy) | 2026-05-22 | Cat Flat Sweden 24Storage (R1-extend, R7-errors) |
| https://www.lg.com/sg/about-lg/press-and-media/lgs-new-puricare-aerocat-tower-air-purifierredefines-pet-wellness-at-home/ | Brand press | 2026-05-22 | LG AeroCat SG launch S$799-899 (R1-extend, R6) |
| https://www.lg.com/hk_en/about-lg/press-and-media/lg-puricare-aerocattower-250801/ | Brand press | 2026-05-22 | LG AeroCat HK launch HK$5,990 (R1-extend) |
| https://www.apartmenttherapy.com/stylish-litter-boxes-cat-scratch-posts-amp-other-design-savvy-decor-for-cats-247626 | Design media (Apartment Therapy) | 2026-05-22 | «carpet-covered cat tree» as outdated (R7-errors) |
| https://www.dwell.com/article/modern-cat-furniture-trees-39680cf7 | Design media (Dwell) | 2026-05-22 | «mainstream cat accessories were so ugly» (R7-errors) |
| https://www.apartmenttherapy.com/hilde-and-phil-cat-e-corner-review-37474890 | Design media (Apartment Therapy) | 2026-05-22 | «flimsy particleboard or laminate» (R7-errors) |
| https://americanpetproducts.org/news/the-american-pet-products-association-appa-releases-2025-dog-cat-report | Trade association (APPA) | 2026-05-22 | 2025 Dog & Cat Report, pet humanization (R6) |
| https://meyou-paris.com/en/content/4-the-brand | Brand official | 2026-05-22 | Meyou Paris made in France premium |
| https://www.lg.com/sg/puricare/aerofurniture/af25catm/ | Brand product spec | 2026-05-22 | LG AeroCat technical specs |

**Legacy footnotes из `DR-SOURCES/legacy-gpt-2026-04-10.md`:** ~27 URLs (Grand View Research, Future Market Insights, Research & Markets, Fortune Business Insights, Business Research Insights и др.) — см. p.27-28 raw conversion.

**Итого:** ~55 URLs. v1.1 R8 gate (≥18) — покрытие x3.

---

## R9. Пробелы данных + verdict по гипотезам

### Часть 1 — Пробелы данных (≥6 gaps в каноническом формате)

#### Gap #1 — Per-capita траты на cat furniture для DE / UK / CN в не-FMI источниках

- **Что искал:** независимые от FutureMarketInsights цифры по среднегодовым тратам на cat furniture на душу населения в Germany ($21.8), UK ($20.7), China ($14.6).
- **Почему не нашёл:** не-FMI источники (Euromonitor, Mintel, Mordor, Statista, ZZF) сегментируют per-capita либо для total pet supplies (Statista: US $280, China $8.7, JP $58.2), либо для country-level pet market в целом (ZZF: DE €7.03B), без выделения cat furniture как отдельной категории. Methodology FMI не воспроизводится в других домах.
- **Как ограничивает выводы:** per-capita cifry для DE/UK/CN остаются `[single-source: FMI]`, не верифицированы независимо.
- **Чем закрывать:** платная подписка Euromonitor или Mintel с country-specific cat furniture report; запрос в национальные pet trade associations (BPSA UK, ZZF DE).

#### Gap #2 — Конкретные дизайнерские награды RINN NEKO Cat Tree

- **Что искал:** перечень премий (Good Design Award Japan, JCD, JID, Red Dot, iF), которыми наградили NEKO Cat Tree.
- **Почему не нашёл:** RINN official site упоминает «artistic philosophy», design-media (Designboom, Modern Cat, Yanko Design, Japan Design Net) активно покрывают продукт, но конкретные премии не перечисляются. Возможно, награды получал дизайнер Yoh Komiyama лично или премии существуют, но не индексируются в обычном поиске.
- **Как ограничивает выводы:** формулировка legacy «получает дизайнерские награды» сохраняется только как design-media coverage в 4+ publications, без конкретных премий.
- **Чем закрывать:** прямой запрос в RINN или yo-komiyama.com; каталоги Good Design Award + JCD + JID + Red Dot за 2017-2020.

#### Gap #3 — Direct measure доли Amazon + Chewy именно в cat furniture (не cat scratching post)

- **Что искал:** прямой % share Amazon + Chewy в общих продажах cat furniture в США.
- **Почему не нашёл:** доступные источники дают либо online share для cat scratching post (DataIntelo 48.3%), либо share Amazon+Chewy в pet e-commerce в целом (VMR ~81% online). Direct cross-tabulation именно cat furniture × Amazon+Chewy не публикуется в открытом доступе.
- **Как ограничивает выводы:** значение ~39% — composite estimate, не direct measure. Точность ограничена proxy.
- **Чем закрывать:** платная подписка 1010data / Packaged Facts / Numerator / Profitero для cat furniture категории US.

#### Gap #4 — Конкретная цифра % спроса на bespoke / modular cat furniture в не-FMI источниках

- **Что искал:** независимый от FMI опрос, подтверждающий «48% expecting bespoke».
- **Почему не нашёл:** другие источники (DataIntelo, ResearchAndMarkets, Mordor, Pmarketresearch) подтверждают тренд модульности / customization качественно, но без конкретной % цифры. FMI Modern Cat Furniture report даёт смежную цифру «76% adaptable», но это другой scope (adaptable ≠ bespoke).
- **Как ограничивает выводы:** конкретная цифра 48% сохраняется с двойным labels (`[verified-by-MCP: C-XSV-05]` + `[single-source: FMI]`). Тренд PASS, цифра — single-source.
- **Чем закрывать:** APPA National Pet Owners Survey (с разбивкой по furniture); Mintel modular furniture report; академические опросы pet consumer behavior.

#### Gap #5 — Cat furniture offline share для Западной Европы как агрегат

- **Что искал:** одна цифра доли offline-канала в cat furniture продажах Western Europe.
- **Почему не нашёл:** агрегат не публикуется. Данные fragmented per-country (Germany pet beds Fressnapf 50-55%; UK e-commerce 35% pet care).
- **Как ограничивает выводы:** legacy «50% Europe offline» удалено, заменено детализированной per-country формулировкой.
- **Чем закрывать:** FEDIAF country-specific data subscription; GfK Pet Care European Pet Care Report.

#### Gap #6 — Cat furniture рынки Норвегии / Финляндии / Австрии / Тайваня / ОАЭ

- **Что искал:** оценки объёма cat furniture категории в этих странах, локальные бренды, доминирующий канал.
- **Почему не нашёл:** Statista даёт per-capita pet supplies для Taiwan ($37.9), но без сегментации cat furniture. Прочие страны cat furniture как отдельная категория не выделена в открытых источниках. Локальные бренды не идентифицированы.
- **Как ограничивает выводы:** эти 5 стран не добавлены в R1 скрининг (NO DATA, не PASS).
- **Чем закрывать:** locally-sourced research для каждой страны (национальные pet associations, paid local market reports).

### Часть 2 — Verdict по 6 гипотезам из R0.10 нового `M2-02-DR-PROMPT.md`

#### Гипотеза №1 — Зарубежные авторские мастера с похожей материальной базой

**Сформулировано как:** международные мастера / бренды с одновременным использованием натурального дерева + качественного каната + натурального или искусственного меха высокого качества + кастома под клиента.

**Verdict:** **CORRECTED — прямых аналогов по полному набору не найдено**

**Что найдено:**
- Дерево + sisal + plush (искусственный мех 600 g/m²) + custom height — **RHRQuality** (Нидерланды). Ближайший аналог. Кастом: height 2-2.95 m, выбор цвета (cream, dark grey, light gray).
- Дерево + bespoke + кастом — **Goldtatze** (Германия, стеновые комплексы), **Hicat** (UK, потолочные столбы). Мех не используется.
- Дерево + felt (войлок) — **MiaCara**, **LucyBalu**. Sisal минимально / отсутствует. Мех не используется.
- Дерево + Kvadrat textile + hemp rope — **RINN**. Мрамор. Мех не используется.
- Дерево + recycled cardboard — **Twisting Cat**. Мех не используется.

**Конкретного бренда с одновременным набором (дерево + качественный канат + натуральный/искусственный мех высокого качества типа «под сибирскую норку» + полноценный кастом) на международном рынке не идентифицировано.** Ближайший — RHRQuality с plush 600 g/m² + sisal 20 cm + custom height, но мех plush — не премиум-уровень «под норку».

**Что требует дополнительной проверки:** Подкатегория «искусственный мех высокого качества» для cat furniture — отдельный поиск в R&D / textile suppliers (Sandler, Foss Performance). Возможно, у российского Alien Cat реально уникальный материал в категории.

#### Гипотеза №2 — Канал «дизайнеры интерьеров» как профессиональный партнёрский канал

**Verdict:** **PARTIAL PASS — канал существует, но не системно**

**Что найдено:**
- **Maison & Objet Paris** — premier design-trade fair, на котором LucyBalu выставлялась в 2024 (с Choupette в нарушение no-animals rule).
- **Karimoku Cat** — extension мебельного бренда Karimoku в категорию cat furniture, прямое позиционирование на дизайн-канал.
- **FancyPets × Nendo** — design-коллаборация (Франция × Япония).
- **Aelfie × Yarinsky** — Brooklyn Cooler Gallery, фурнитура как art-object.
- **MoMA Store, Design Within Reach, Apartment Therapy shop** — design retail с присутствием cat furniture брендов.
- **Apartment Therapy + Dwell** — design media covering cat furniture отдельной категорией с 2017.

**Что не подтверждено:** конкретный % share «дизайнерского канала» в total cat furniture sales не публикуется. Системные B2D (business-to-designer) программы (3D-библиотеки, professional discounts, trade programs) для cat furniture брендов — единичные / не системные.

**Verdict:** канал работает как один из premium-каналов, но не доминирует. Точная доля без cross-verification.

#### Гипотеза №3 — Архитектура «вход — ядро — флагман» в premium-сегменте

**Verdict:** **PARTIAL PASS — implicit pricing tiers есть, explicit роли не артикулированы**

**Что найдено:**
- **Tuft + Paw:** Cove $199 (entry / litter cabinet), cat trees средний tier $300-600, премиум флагман (например, Stella range ~$800-1200). Структура implicit, но просматривается.
- **MiaCara:** Parete €169 (entry, отдельный модуль) → Pannello → Alto Wall Climber CHF 285+ (mid-premium) → Alto full extended system $565+. Implicit tier структура.
- **The Refined Feline:** один flagship (Lotus $400). Линейка fragmented, не явная entry/core/flagship.
- **RHRQuality:** Maine Coon Lounge 1.2m (entry-mid) → Maine Coon Tower Plus 2-2.95m (mid) → Royal Cat Palace XXL до 12 кошек (flagship). Чёткая иерархия implicit.
- **Catit Vesper:** Vesper V-High $100 (entry), V-Tall $150 (mid), House (flagship). Структура есть.

**Что не подтверждено:** Explicit использование терминов entry / core / flagship на сайтах брендов не идентифицировано. Линейки строятся через product categories (litter / scratching / trees / wall) и price tiers, не через role-based architecture с явной артикуляцией.

**Verdict:** Implicit price tiers — общая практика. Explicit role artikulation как USP — отсутствует.

#### Гипотеза №4 — Smart cat furniture как растущая категория

**Verdict:** **CORRECTED — категория начала переход в серийное производство 2024-2025**

**Что найдено:**
- **LG PuriCare AeroCat Tower** — первый коммерческий smart cat furniture от мейджора. Запуск Korea → Singapore (July 2025, S$799-899) → Hong Kong (August 2025, HK$5,990 ≈ $760) → Malaysia. Integrates air purification + heated dome seat + pet care tracking через LG ThinQ app.
- **Xiaomi Youpin** smart кошачий домик с климат-контролем — китайский серийный продукт.
- **PETKIT Purobot Ultra** — auto litter box с AI camera + cat behavior monitoring (2024). Смежная категория к cat furniture.
- **Clawz** (US) — AR-примерка cat furniture в интерьере (единичный случай).

**Что не подтверждено:** Массовый рынок smart cat furniture пока small. Большинство «smart» продуктов — concept или single-market launch. Категория зарождается, но коммерческие игроки уже есть.

**Verdict:** Legacy формулировка «не зрелая, нет коммерческих» — CORRECTED. Категория начала переход в серийное производство 2024-2025; LG / Xiaomi / PETKIT — реальные коммерческие продукты. Scale пока small, но это уже не hype-only сегмент.

#### Гипотеза №5 — Sustainable cat furniture как новая ось дифференциации

**Verdict:** **PASS**

**Что найдено (≥7 брендов с реальным sustainability-позиционированием):**
- **MiaCara** (DE) — FSC-сертифицированное дерево, recycled PET felt, эко-упаковка без пластика и бумажный скотч (verified through brand site).
- **Susy** (IT) — 100% FSC-сертифицированный картон, 100% recyclable, made in Italy at zero km, plastic-free.
- **Twisting Cat / Twist** (BE) — recycled wood + recycled cardboard, без клея и химии, circular economy approach, made in Belgium.
- **Mikaste** (NL) — sustainable Japandi позиционирование как core бренд-кода.
- **Nipa** (US) — cork tree («Our tree was a tree», 100% biodegradable, no plastics).
- **Ware Pet Products** (US) — recycled cardboard когтеточки.
- **ModKitty** (US) — zero plastic / zero chemicals / renewable / biodegradable / recyclable.
- **Shichic** (US) — repurposed oak veneer, fully recyclable materials.
- **Goldtatze** (DE) — sustainable wood, made in Germany.
- **LucyBalu** (DE) — sinnvolle und zeitlos schöne (sustainable + timeless как core).

**Verdict:** Sustainable cat furniture **подтверждена как ось дифференциации**. Минимум 10 брендов с реальным позиционированием (не декларацией), большинство в DE/IT/NL/BE/US. Тренд multi-source: подтверждён DataIntelo Modular Cat Furniture Market, Mintel sustainability research, CBI EU pet furniture market.

#### Гипотеза №6 — Pet humanization в верхнем ценовом ярусе

**Verdict:** **PASS**

**Что подтверждается:**
- **APPA 2025 Dog & Cat Report:** «deepening of the human-animal bond relationship», «heightened focus on proactive pet wellness», «premium product adoption» как ключевые шифты.
- **Mordor Intelligence:** «pet humanization» как core driver. «Pet furniture is repositioning from basic utility to extension of home décor».
- **Euromonitor Western Europe:** «premiumisation and pet humanisation trends continuing to develop. Even with recent difficult economic climate, many owners were loathe to cut spending on their pets».
- **FMI / DataIntelo / IMARC:** millenials и Gen Z драйверы. В США cat ownership reached approximately 45.3 млн households (APPA 2024).
- **Per-capita cifry** Statista 2026: US $280, AU $226, NZ $196 на pet supplies — растут опережающими экономику.
- **Moojing Global China:** per-pet $95 в 2025, +14.5% YoY — humanization trajectory.

**Verdict:** Pet humanization **подтверждён как фундаментальный driver** премиум-сегмента cat furniture. Многосторонняя верификация. Это не моду, а структурный сдвиг потребления, particularly среди millennials и Gen Z.

### Часть 3 — Свод verdict по гипотезам

| # | Гипотеза | Verdict | Confidence |
|---|---|---|---|
| 1 | Зарубежные авторские мастера с похожей материальной базой | CORRECTED — прямых аналогов по полному набору (дерево + канат + натуральный мех высокого качества + кастом) не найдено | MEDIUM (negative finding) |
| 2 | Канал «дизайнеры интерьеров» как профессиональный партнёрский канал | PARTIAL PASS — канал существует, но не системно | MEDIUM |
| 3 | Архитектура «вход — ядро — флагман» в premium-сегменте | PARTIAL PASS — implicit tiers, explicit roles не артикулированы | MEDIUM |
| 4 | Smart cat furniture как растущая категория | CORRECTED — категория начала переход в серийное производство 2024-2025 | HIGH (LG / Xiaomi / PETKIT verified) |
| 5 | Sustainable cat furniture как ось дифференциации | PASS | HIGH (≥10 брендов verified) |
| 6 | Pet humanization в верхнем ценовом ярусе | PASS | HIGH (multi-source APPA / Mordor / Euromonitor) |

---

## Methodology note (no-leakage block)

Этот RESEARCH-документ исследует мировой рынок мебели для кошек по географии × ценовому ярусу как primary axes сегментации. Дополнительные оси — тип игрока (масс / D2C / маркетплейс-native / specialty retailer / artisan) и формат потребления (entry / mid / premium / luxury / bespoke).

**Methodological note for transparency:** некоторые legacy-формулировки содержали разбивку рынка по «B2C / B2B сегментам» (товары для частных владельцев vs оборудование для приютов / отелей для животных / ветклиник). В этом RESEARCH-документе эта разбивка не используется как primary axis сегментации — для модуля M2-02 Alien Cat согласована geography × price tier как основная ось (CLIENT-OVERLAY Overlay #3). Профессиональные площадки (cat cafes, кошачьи отели, ветклиники) допустимы как одна из dimensions «типа клиента / покупательского сценария» (R0.9), но не как первичная axis сегментации R1.

---

*M2-02-RESEARCH — Alien Cat | candidate canon v1.1 | compilation date 2026-05-22*
*Source-pack: single legacy DR thread + extended MCP add-on per CLIENT-OVERLAY Overlay #1*
*Next: ROUNDTABLE-CHECK (Step 6) с зонами Z-canon / Z-genre / Z-scope / Z-Picnic*
