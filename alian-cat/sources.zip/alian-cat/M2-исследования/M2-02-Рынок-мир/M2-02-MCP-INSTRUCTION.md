# M2-02-MCP-INSTRUCTION — Alien Cat M2-02 Рынок мир

> Инструкция для extended MCP add-on. **Ровно 13 проверок**, без расширения scope.
> Результаты выполнения записываются в `M2-02-MCP.md`, оценка — в `M2-02-MCP-EVALUATION.md` (separate per profile C).

---

## Source artefacts

| Артефакт | Путь |
|---|---|
| Pure RESEARCH extraction | `M2-исследования/M2-02-Рынок-мир/M2-02-DR-legacy-extracted.md` |
| Исходный список suspicious facts | `M2-исследования/_fact-check/M2-02-MIR-suspicious-facts.md` |
| Уже выполненный MCP fact-check (5 critical) | `M2-исследования/_fact-check/M2-02-MIR-MCP-RESULTS.md` |
| Client overlay (single legacy + extended MCP) | `M2-исследования/M2-02-Рынок-мир/_методика/CLIENT-OVERLAY.md` |

## Scope (boundary)

- **13 проверок** — фиксированный список, не расширяется в процессе.
- 42 игрока R2 с лейблом `[legacy-unverified]` **не превращаются** в отдельные MCP-задачи. Они остаются как контекст без верификации.
- R1-extend: цель — честно добавить 3-5 стран, где есть данные. Не «доказать 15 любой ценой». Если данных нет — фиксируется как NO DATA для каждой страны отдельно.
- R7-errors: live-примеры **только для ошибок** визуала/TOV. Не конкурентный аудит, не разбор сильных брендов.

## Confidence rule (применяется к каждой проверке)

| Verdict | Условие |
|---|---|
| **PASS** | Утверждение подтверждается ≥2 независимыми источниками с URL и датой, или ≥1 высокоавторитетным источником, либо прямым сайтом бренда |
| **CORRECTED** | Утверждение частично верно, требует переформулировки. В output даётся скорректированная версия с источником |
| **REFUTED** | Утверждение опровергается доступными источниками |
| **NO DATA** | Источников не найдено за разумное число поисковых попыток (≤6 запросов на проверку) |

Verdict в output обязан содержать минимум 1 URL (кроме NO DATA).

## Output format (общий для всех 13 проверок)

В `M2-02-MCP.md` каждая проверка записывается блоком:

```
### <ID> — <короткое описание>

**Claim/Gap:** <утверждение из legacy или пробел>
**Verdict:** PASS / CORRECTED / REFUTED / NO DATA
**Скорректированная формулировка (если CORRECTED):** <строка>
**Источники:** 
  1. <URL> | <тип> | <дата доступа> | <релевантная цитата или резюме>
  2. ...
**Search trace:** <какие запросы, какие tools, сколько попыток>
**Notes:** <ограничения, оговорки>
```

---

## Проверки

### 1. C-XSV-06 — LucyBalu / Шупетт / Лагерфельд

**Claim:** «LucyBalu (Мюнхен) стал известен после того, как Карл Лагерфельд купил их подвесной гамак для кошки Шупетт.»

**Зачем:** Утверждение о медийном событии. Может быть реальным фактом или брендовой легендой. Влияет на интерпретацию «один правильный амбассадор может построить премиум-бренд».

**Preferred tools:** Tavily (общий поиск), Firecrawl (сайт LucyBalu / интервью).

**Search queries:**
1. `LucyBalu Karl Lagerfeld Choupette hammock`
2. `LucyBalu Munich brand history Choupette`
3. `Choupette Lagerfeld cat hammock LucyBalu interview`
4. `LucyBalu Karl Lagerfeld Schupette Katze`

**Accepted evidence:**
- Публикация в немецких или французских деловых/lifestyle медиа 2018-2022 с упоминанием эпизода.
- Интервью LucyBalu в медиа, подтверждающее эпизод.
- Биография Шупетт (книги, документации) с упоминанием LucyBalu.

**Reject evidence:**
- Только пресс-релизы самого LucyBalu без независимых подтверждений.
- Wikipedia без primary-источника.

---

### 2. C-XSV-07 — RINN NEKO Cat Tree цена + дизайнерские награды

**Claim:** «RINN (Япония) — NEKO Cat Tree за ~¥1 млн (мрамор + дерево). Получает дизайнерские награды.»

**Зачем:** ¥1 млн (~$6 500-7 000) — экстремальная цена, надо подтвердить. «Дизайнерские награды» — без конкретики, надо найти конкретные.

**Preferred tools:** Firecrawl (сайт RINN), Tavily (японские design-медиа).

**Search queries:**
1. `RINN Japan NEKO Cat Tree price marble wood`
2. `RINN NEKO design award Good Design Japan`
3. `リン NEKO キャットツリー 価格`
4. `RINN cat tree luxury Japan design`

**Accepted evidence:**
- Сайт RINN с ценой модели (Wayback Machine допустим для исторических цен).
- Японские design-медиа (Designboom Japan, AXIS, Nikkei Design) с упоминанием награды.
- Каталоги Good Design Award, JID, JCD Design Awards.

**Reject evidence:**
- Маркетинговые материалы бренда без независимых подтверждений.
- Утверждения в туристических блогах без primary-источника.

---

### 3. C-XSV-08 — RHRQuality 2-year warranty + специализация на мейн-кунах

**Claim:** «RHRQuality (Нидерланды) — специализация на крупных кошках (мейн-куны), гарантия 2 года, сверхпрочные конструкции.»

**Зачем:** Конкретика гарантии и специализации — проверяемая. Может быть устаревшей.

**Preferred tools:** Firecrawl (сайт rhrquality.com), Tavily (отзывы).

**Search queries:**
1. `RHRQuality warranty cat tree Maine Coon`
2. `RHRQuality Netherlands big cat furniture guarantee`
3. `site:rhrquality.com warranty`
4. `RHRQuality reviews Maine Coon owners`

**Accepted evidence:**
- Сайт RHRQuality со страницей warranty / about.
- Reviews платформы (Trustpilot, Google Reviews) с упоминанием warranty.
- Mention в международных pet-медиа.

**Reject evidence:**
- Только Amazon-описания без подтверждения с сайта бренда.
- Утверждения «специализируется на мейн-кунах» без явного позиционирования бренда.

---

### 4. C-XSV-09 — «~50% Europe offline» для мебели для кошек

**Claim:** «В Европе ~50% покупателей всё ещё предпочитают офлайн потрогать руками.»

**Зачем:** Круглая цифра без источника. Смешивает all-Europe в одно число — поведение в DE/FR/UK/PL сильно различается.

**Preferred tools:** Tavily (отраслевые отчёты), Exa (полнотекстовый поиск).

**Search queries:**
1. `Europe pet furniture offline retail preference survey 2024`
2. `European cat furniture purchase channel offline vs online`
3. `pet supplies Europe in-store vs online survey`
4. `European pet retail report channel split 2023 2024`

**Accepted evidence:**
- Отраслевой отчёт (FEDIAF, GfK, Statista, Mintel) с конкретной долей offline.
- Аналитика consultancy (McKinsey, Bain, Boston Consulting) с European pet retail breakdown.
- Желательно — разбивка по странам (DE/FR/UK/IT/ES).

**Reject evidence:**
- Цифры для US или global без явной European разбивки.
- Цифры для pet supplies в целом без выделения мебели.

---

### 5. C-XSV-10 — Tuft+Paw Cove реальная цена

**Claim:** Внутреннее противоречие legacy: цена Cove указана $199 (PostAnalysis Гипотеза 4) и $599 (suspicious-facts).

**Зачем:** До разрешения противоречия — без цифры. После проверки — фиксация актуальной цены 2025-2026.

**Preferred tools:** Firecrawl (tuftandpaw.com), Wayback Machine (исторические цены).

**Search queries:**
1. `site:tuftandpaw.com Cove`
2. `Tuft Paw Cove litter box furniture price 2025`
3. `Tuft and Paw Cove review price` (для cross-check)
4. Wayback: `tuftandpaw.com/products/cove` за 2024-2025

**Accepted evidence:**
- Текущий сайт Tuft+Paw с страницей Cove и явной ценой.
- Snapshots Wayback Machine за 2024-2025 (для динамики).
- Independent reviews с упоминанием цены и датой.

**Reject evidence:**
- Цена «from $X» без явной базовой комплектации.
- Реселлер-цены (Amazon третьих лиц).

---

### 6. C-XSV-11 — Refined Feline Lotus 4.5⭐ 1491 отзыв

**Claim:** «Lotus Cat Tower (Refined Feline) ~$400, 1491 отзыв со средней 4.5⭐.»

**Зачем:** Число отзывов быстро устаревает. Рейтинг и цена проверяемы на Amazon / сайте.

**Preferred tools:** Firecrawl (Amazon страница Lotus), сайт refinedfeline.com.

**Search queries:**
1. `Refined Feline Lotus Cat Tower Amazon`
2. `site:therefinedfeline.com Lotus`
3. `Refined Feline Lotus Cat Tower review 2024 2025`

**Accepted evidence:**
- Текущая Amazon страница Lotus с цифрами reviews/rating.
- Сайт Refined Feline.
- Independent reviews с упоминанием рейтинга.

**Reject evidence:**
- Старые reviews без даты.

**Notes:** Конкретные числа (1491 отзыв) устаревают; в скорректированной формулировке писать «один из самых рейтинговых премиум-моделей в категории», без точного числа.

---

### 7. C-XSV-12 — MiaCara настенный комплекс реальный диапазон

**Claim:** «MiaCara (Германия) — Цена настенного комплекса €300+.»

**Зачем:** Нижняя граница «€300+» — общее утверждение. Реальный диапазон MiaCara может быть значительно выше.

**Preferred tools:** Firecrawl (miacara.com).

**Search queries:**
1. `site:miacara.com price cat furniture`
2. `MiaCara wall cat furniture price range`
3. `MiaCara cat tree wall complex Preis`

**Accepted evidence:**
- Сайт MiaCara с актуальными ценами по моделям (en/de версии).
- Каталоги retailer (Zooplus, отдельные дизайн-сторы).

**Reject evidence:**
- Цены из третьих рук без подтверждения с сайта.

---

### 8. Cross-1 — Sub-сегмент modern/designer cat furniture (не-FMI)

**Gap:** Цифры $1.5 млрд (2025) → $2.8 млрд (2035), CAGR 6.8% — `[single-source: FMI]`. Кросс-верификация недоступна.

**Зачем:** Подтвердить или опровергнуть через источники, отличные от FutureMarketInsights.

**Preferred tools:** Tavily (отчёты домов), Exa.

**Search queries:**
1. `designer cat furniture market size CAGR Euromonitor`
2. `premium cat furniture market segment Mintel`
3. `modern cat furniture market share Mordor Intelligence`
4. `Statista designer cat furniture market`
5. `IBISWorld premium pet furniture`

**Accepted evidence:**
- Любой отчёт от Euromonitor / Mintel / Mordor / Statista / IBISWorld / Grand View Research, который выделяет modern/designer как отдельный сегмент с цифрами объёма и CAGR.

**Reject evidence:**
- Подтверждение через FMI или цитирование FMI другими источниками (это не независимая верификация).

**Notes:** Если ≥2 не-FMI источников подтверждают порядок цифр — PASS. Если только тренд («modern растёт быстрее») — CORRECTED (без абсолютных $). Если только FMI — NO DATA по cross-verification.

---

### 9. Cross-2 — Per-capita траты DE / UK / CN (не-FMI)

**Gap:** Цифры $21.8 / $20.7 / $14.6 — `[single-source: FMI]`. Per-capita для US ($22.9) и JP ($19.4) уже PASS через MCP первого раунда.

**Зачем:** Подтвердить или зафиксировать как «один источник».

**Preferred tools:** Tavily, Exa.

**Search queries:**
1. `per capita pet furniture spending Germany Euromonitor`
2. `UK pet furniture spending per capita 2024`
3. `China cat furniture per capita consumption`
4. `Europe pet supplies spending per capita country breakdown`

**Accepted evidence:**
- Не-FMI отчёты с per-capita цифрами по любой из 3 стран.
- Государственные/отраслевые источники (Eurostat, GfK Pet Care, Chinese pet industry associations).

**Reject evidence:**
- Цитирование тех же FMI цифр другими медиа.
- Цифры для pet supplies в целом без выделения мебели.

**Notes:** Per-capita для всех 3 стран — отдельно. Может быть PASS для одной и NO DATA для других.

---

### 10. Cross-3 — 48% спрос на модульную мебель (не-FMI)

**Gap:** «48% потребителей ожидают модульную мебель» — `[verified-by-MCP: C-XSV-05]` через FMI в первом раунде, но `[single-source]`.

**Зачем:** Подтвердить из независимого опроса.

**Preferred tools:** Tavily, Exa.

**Search queries:**
1. `consumer demand modular cat furniture survey not FMI`
2. `pet owners customizable furniture preference survey 2024`
3. `bespoke pet furniture demand consumer research`
4. `cat furniture personalization survey APPA Mintel`

**Accepted evidence:**
- APPA, Mintel, GfK или другой опрос с цифрой 40-60% для модульной/кастом мебели.
- Академические исследования pet consumer behavior.

**Reject evidence:**
- Цитирование 48% другими медиа без primary-источника.
- Цифры для pet supplies в целом, не для мебели.

**Notes:** Если не-FMI источник подтверждает порядок цифр (40-60% range) — PASS. Если только FMI — CORRECTED («подтверждено единственным источником FMI, кросс-верификация не найдена»).

---

### 11. Re-1 — Реальная доля Amazon + Chewy в мебели для кошек

**Claim:** Legacy утверждает 60-70% от продаж мебели. MCP первого раунда показал, что это смешение метрик. `[mcp-corrected: C-XSV-04]` дал ~28% via online-share proxy. Re-verification нужна, чтобы заменить proxy на прямую цифру.

**Зачем:** Получить прямую оценку доли Amazon+Chewy именно в cat furniture sales (не pet e-commerce в целом, не cat food).

**Preferred tools:** Tavily, Exa.

**Search queries:**
1. `Amazon Chewy share cat furniture sales US 2024`
2. `cat furniture e-commerce channel share retailer breakdown`
3. `pet furniture online retail market share United States`
4. `cat scratching post tree retailer market share Amazon`

**Accepted evidence:**
- Прямая цифра доли Amazon и/или Chewy в категории мебели для кошек или категории pet furniture (с разбивкой по retailer).
- Аналитика 1010data, Packaged Facts, Numerator, Profitero для cat furniture категории.

**Reject evidence:**
- Цифры для pet supplies в целом.
- Цифры для pet food (другая категория).

**Notes:** Если прямой источник найден — заменяет proxy-оценку ~28%. Если не найден — proxy сохраняется с пометкой «по proxy через online-share».

---

### 12. R1-extend — Дополнительные страны к 10 базовым

**Gap:** Legacy скрининг = 10 стран (US/CA/DE/FR/UK/IT-косвенно/JP/KR/CN/AU). v1.1 R1 требует 12-15. Кандидаты для проверки: **Италия, Нидерланды, Бельгия, Швеция, Дания, Норвегия, Финляндия, Швейцария, Австрия, Сингапур, Гонконг, Тайвань, ОАЭ.**

**Зачем:** Честно добавить 3-5 стран, где есть данные. Не «доказать 15 любой ценой».

**Preferred tools:** Tavily (отраслевая аналитика), Exa, Firecrawl (бренд-сайты по стране).

**Search queries (общий шаблон для каждой страны):**
1. `cat furniture market <country> brands`
2. `pet supplies industry <country> overview`
3. `<country> pet furniture retail channel`
4. `<country> cat tree designer brands`

**Accepted evidence (на страну):**
- Минимум 1 отраслевой источник с упоминанием категории мебели для кошек в стране.
- Имена ≥2 локальных или известных брендов, активно работающих в стране.
- Доминирующий канал и доминирующий ценовой ярус.

**Reject evidence (на страну):**
- Только e-commerce статистика без выделения категории.
- Только pet food данные без зоотоваров и аксессуаров.
- Маркетинговые статьи без primary-источников.

**Output для R1-extend:**

| Страна | Verdict | Brands found | Channel | Tier | Source |
|---|---|---|---|---|---|
| Италия | PASS / NO DATA | ... | ... | ... | ... |
| Нидерланды | PASS / NO DATA | ... | ... | ... | ... |
| ... |

**Notes:** Цель — 3-5 PASS из 13 кандидатов. Остальные — честно NO DATA. Не натягивать.

---

### 13. R7-errors — Типичные ошибки визуала / TOV в категории

**Gap:** Legacy не содержит структурированного блока «типичные ошибки визуала и TOV». v1.1 R7 требует ≥2.

**Зачем:** Закрыть R7 gate. Live-примеры **только для ошибок**, не конкурентный аудит сильных брендов.

**Preferred tools:** Firecrawl (Amazon listings эконом-сегмента, китайские безымянные карточки на AliExpress / Tmall), Tavily (статьи о «cheap pet furniture» / «bad pet furniture aesthetics»).

**Search queries:**
1. `cheap cat furniture aesthetic problem Amazon ugly`
2. `pet store cat tree carpet outdated design criticism`
3. `cat furniture marketing inauthentic infantilizing tone`
4. `low quality cat tree visual presentation listing`
5. `worst cat furniture design`

**Accepted evidence:**
- Конкретные Amazon/AliExpress listings эконом-сегмента с явно низким визуальным стандартом (URL, скриншот описания).
- Статьи в design-медиа (Apartment Therapy, Dwell) с критикой типичных ошибок визуала в категории.
- Reddit/cat forums с обсуждением «cheap-looking» pet furniture.

**Reject evidence:**
- Разбор сильных брендов («у Tuft+Paw круто, потому что не так как у других»). Нужны конкретные ошибки на конкретных эконом-листингах.
- Общие рассуждения о premium vs masс без конкретных примеров.

**Output:**

Минимум 2 ошибки с описанием:
- **Ошибка 1:** <название> — что именно (визуал/TOV/обе категории).
  - Где встречается: <≥2 конкретных URL listings или статей>.
  - Что транслирует ошибочно: <инфантильность / cheap / outdated / inauthentic / противоречие позиционированию>.
- **Ошибка 2:** аналогично.

**Notes:** Не превращать в конкурентный аудит. Фокус — антипаттерны.

---

## QC (выполнено после сборки этой инструкции)

| Проверка | Результат |
|---|---|
| 13 / 13 checks present | ✅ (C-XSV-06..12 = 7, Cross-1/2/3 = 3, Re-1 = 1, R1-extend = 1, R7-errors = 1, итого 13) |
| Нет Gemini / delta prompt | ✅ слово «Gemini» / «delta» не встречается в заданиях |
| Нет full paired DR / новой research-нити | ✅ инструкция формулирует verification / dobor, не research |
| Нет новых проверок сверх списка | ✅ только 13 утверждённых |
| Нет MCP-задач на 42 legacy-unverified игроков | ✅ R2 базовый каталог не входит в проверки |
| B2B/B2C only in exclusion/context | ✅ в этой инструкции не упоминается |

---

*M2-02 MCP-INSTRUCTION | Alien Cat | candidate canon v1.1 | 2026-05-22*
*Next: execute add-on → write results to `M2-02-MCP.md` → assess in `M2-02-MCP-EVALUATION.md` (separate per profile C).*
