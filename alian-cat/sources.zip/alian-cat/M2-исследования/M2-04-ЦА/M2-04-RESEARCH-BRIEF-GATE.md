# M2-04 RESEARCH-BRIEF Gate — Целевая аудитория Alien Cat

Дата: 2026-05-27  
Проверяемый файл: `M2-04-RESEARCH-BRIEF.md`  
Основание: `M2-04-SOURCE-PACKET.md`, `M2-04-TARGETED-VERIFICATION.md`  
Статус: `BRIEF_VERIFICATION_PASS / READY_FOR_RESEARCH_DRAFT / NOT_RESEARCH_READY`

---

## 1. Verdict

`M2-04-RESEARCH-BRIEF.md` достаточен для запуска writer-режима `M2-04-RESEARCH.md`.

Что это **разрешает**:

- писать draft `M2-04-RESEARCH.md` по outline R0-R9;
- использовать source packet route без нового full DR на этом шаге;
- переносить targeted verification verdicts как ограничения.

Что это **не разрешает**:

- ставить `RESEARCH_READY`;
- ставить `CLIENT_READY`;
- писать `M2-04-SYNTHESIS.md`;
- собирать HTML;
- публиковать старый `AlianCat_Synthesis_CA.html`.

---

## 2. Gate checks

| Check | Result | Evidence |
|---|---|---|
| G1. Brief явно говорит, что это не Research | PASS | §0, status line |
| G2. Source hierarchy P0-P4 задана | PASS | §2 |
| G3. Legacy DR ограничен hypothesis layer | PASS | §0, §2, §4.6 |
| G4. Source-map contract есть и не свёрнут | PASS | §4.1-§4.7 |
| G5. A-TV-01..A-TV-07 перенесены без усиления | PASS | §5 |
| G6. Rejected / weakened legacy claims вынесены отдельно | PASS | §4.6, §7.2, §9 |
| G7. M4 boundaries сохранены | PASS | §1, §4.7, §6 R8 |
| G8. Каналы отделены от M7 strategy | PASS | §4.3, §6 R6 |
| G9. Trust barriers не превращены в обещания Alien Cat | PASS | §4.4, §8.2, §9 |
| G10. Fail criteria достаточно конкретны | PASS | §9 |

---

## 3. Что проверено по главным ошибкам старого подхода

| Риск | Статус |
|---|---|
| Написать Research напрямую из старого `DR ЦА/` | заблокировано |
| Принять старый HTML как готовый артефакт | заблокировано |
| Перенести synthetic personas | заблокировано |
| Перенести доходы, районы, точные проценты | заблокировано |
| Перенести старую цену 35-70 тыс. | заблокировано |
| Сделать дизайнеров B2B-сегментом | заблокировано |
| Сделать владельцев крупных кошек единственным ядром | заблокировано |
| Сделать BNPL доказанным growth lever | заблокировано |
| Использовать 59% домохозяйств как sizing Alien Cat | заблокировано |
| Закрыть M4 внутри M2-04 | заблокировано |

---

## 4. Minor correction made during gate

В `M2-04-SOURCE-PACKET.md` обновлена таблица Source Hierarchy:

- P2 теперь `M2-04-TARGETED-VERIFICATION.md`;
- fact-check layer сдвинут в P3;
- legacy DR сдвинут в P4.

Причина: после targeted verification packet должен отражать фактический порядок источников. Это не меняет содержательные выводы, но убирает риск расхождения между packet и brief.

---

## 5. Research writer constraints

При сборке `M2-04-RESEARCH.md` writer обязан:

1. Сохранить R0-R9 outline из brief.
2. Не сжимать 7 карт source-map contract.
3. Явно отделить рабочую карту аудитории от финальной M4-сегментации.
4. Писать русский клиентский язык без лишнего англоязычного слоя.
5. Все числа давать с источником, годом и caveat.
6. Не писать рекомендаций «Alien Cat должен...».
7. Не обещать от имени Alien Cat рассрочку, гарантию, возврат, replacement service.
8. Завершить документ M4 handoff.

---

## 6. Next status

| Step | Status |
|---|---|
| RESEARCH-BRIEF | `VERIFIED_FOR_RESEARCH_DRAFT` |
| Client-facing RESEARCH draft | `READY_TO_WRITE` |
| `RESEARCH_READY` | `FORBIDDEN_UNTIL_RESEARCH_QUALITY_GATE` |
| SYNTHESIS / HTML / publish | `BLOCKED` |

