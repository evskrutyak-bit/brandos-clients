# M2-04 SYNTHESIS (v2) — CLIENT_READY Gate (evidence)

**Verdict:** `CLIENT_READY` — **OWNER-ACCEPTED 2026-06-05**
**Date:** 2026-06-05
**Refreshed:** 2026-06-05 поверх финального MD (после синка hero-lede). Gate mtime > MD mtime.
**Source MD:** `M2-04-SYNTHESIS-v2.md`, provenance `e23dd6532f4fbfe5` (sha256[:16], совпадает с HTML provenance)
**Upstream:** `M2-04-RESEARCH.md` (OWNER-ACCEPTED, provenance `0cd14c9bd5e0747e`)

> **Stale-evidence fix (owner-caught):** прежний gate (17:32) был старше финального MD (17:41) → CLIENT_READY-gate был stale. Перевыставлен поверх текущего `e23dd6532f4fbfe5`. Все checks ниже валидны для финальной версии MD (hero-lede = M2-05-стандарт, содержание не менялось — только шапка self-description). HTML не пересобирался: provenance уже совпадает.
**Writer:** Pushkin Synthesis Mode — **real Agent run** (copywriter skill, opus, agentId `a82c3fd1b5c039253`, прочитал SKILL.md, 9 tool-uses, 116k токенов). Builder ≠ Verifier: писал агент, проверял Claude.

> Старые `M2-04-SYNTHESIS.md` + `M2-04-SYNTHESIS-BRIEF.md` = QUARANTINED, не использовались. Свежий путь: PREFLIGHT 5/5 → BRIEF-v2 → Pushkin → этот gate. Финал CLIENT/HTML — owner eye-check.

## Internal checks

| Check | Evidence | Результат |
|---|---|---|
| SOURCE_COVERAGE | Все 9 карт BRIEF-v2 отражены: 9 групп (§2), сегментация по мотивации (§1-2), 9 сценариев (§3), триггеры 7+8 (§3), доверие/барьеры 15+8 (§3), язык 3 слоя + формулы (§4), каналы Avito+гипотезы (§1.9/§6), refuted (§5), 8 пробелов (§5/§6). Карта сохранена, доказательства сжаты | PASS |
| LANGUAGE_TECH | grep: кухня (DR/MCP/пути/.md/поток)=0, ИИ-обороты=0, образная литературщина (портрет/палец над кнопкой/словно/будто)=0, AR/BNPL расшифрованы first-use | PASS |
| READER_SANITY | Чтение глазами целиком: сухой управленческий русский, связно, жаргон поясняется, читается без обращения к RESEARCH | PASS |
| EDITORIAL | Pushkin Synthesis Mode, жанр выдержан (сжатие, не второй research), **без образного хука** (главное требование owner после провала hero). Editor = чтение глазами, правок не потребовалось | PASS |
| CROSS-ARTIFACT TERMINOLOGY | развилк=0, гипотез=8 — рамка «гипотезы», консистентно с M2-02/03/05 | PASS |
| NO NEW FACTS | spot-check: 59% / 49,2 млн / 30,5 млн / 590 млрд / Avito 20-30/10 — совпадают с RESEARCH | PASS |

## Boundaries (сохранены)
M4 (доли сегментов, демография, реальные данные покупателей + 8 пробелов) / M6 (эстетика, двойной язык, речевые формулы) / M7 (каналы, дизайнеры B2B, BNPL) — §6.

> Provisional. HTML — отдельно (6-check). Финал — owner eye-check SYNTHESIS HTML. Deploy/hub НЕ делать. M2-06 KARTINA не стартует до accept.
