# M2-04 SYNTHESIS-BRIEF — Целевая аудитория Alien Cat

Дата: 2026-05-27
Модуль: M2-04 Целевая аудитория
Клиент: Alien Cat / AlianCat
Жанр документа: **decision brief / контракт для сборки SYNTHESIS.md**, не сам SYNTHESIS
Status: `DRAFT / NOT_VERIFIED / NOT_SYNTHESIS_READY`
Track: 2 (Client Track), переход требует отдельного L2 obligatory accept после verification этого brief

---

## 0. О документе

Этот файл — **brief для Pushkin Synthesis Mode**, не сам synthesis. Он задаёт scope, source-map contract и acceptance criteria для следующего шага — `M2-04-SYNTHESIS.md`.

Главное правило: **SYNTHESIS сжимает evidence, но НЕ сжимает source-map.** Все 7 карт из M2-04-RESEARCH-BRIEF §4.1-4.7 должны быть представлены в synthesis в сжатой форме — не вырезаны.

Brief создан параллельно с патчем M2-04-RESEARCH после получения L2_ACCEPT_CONDITIONAL_ON_PATCH_02 + TRANSITION_ACCEPT_CONDITIONAL от Studio-методштаба 2026-05-27.

---

## 1. Цель будущего `M2-04-SYNTHESIS.md`

Дать клиенту (Светлане) и команде M2-06 KARTINA короткую читаемую картину аудитории Alien Cat: какие группы видны, какие мотивы и барьеры подтверждены, какие каналы есть как universe, что уходит в M4 и в M3/M7/M8.

`M2-04-SYNTHESIS.md` должен ответить на 8 вопросов:

1. Какие группы аудитории видны как ядро / proof-сегмент / гипотеза.
2. Какие мотивы покупки подтверждены доказательно.
3. Какие барьеры доверия валидны для дорогой дистанционной покупки.
4. Какой текущий канал подтверждён, какие — гипотезы.
5. Что остаётся вопросом для M4 (без закрытия M4).
6. Что уходит в M3 (продукт / линейка / сервис).
7. Что уходит в M7/M8 (стратегия каналов / контент).
8. Какие вопросы вынести в KARTINA (M2-06) для подтверждения / уточнения со Светланой.

`M2-04-SYNTHESIS.md` **не должен**:

- быть вторым research (research — `M2-04-RESEARCH.md`, уже ACCEPTED);
- строить финальную сегментацию или закрывать M4;
- писать аватары / JTBD / VPC / decision journey;
- давать рекомендации по линейке, ценам, рассрочке, гарантиям, сервису;
- делать M7-канальную стратегию или медиаплан;
- ставить CLIENT_READY без отдельного L2 obligatory gate.

---

## 2. Source Hierarchy

| Приоритет | Источник | Как использовать |
|---|---|---|
| P0 | `M2-исследования/M2-04-ЦА/M2-04-RESEARCH.md` (ACCEPTED R3 v1.1, 2026-05-27) | Основной слой evidence. Все смыслы synthesis должны быть выводимы из RESEARCH; нельзя вводить новые факты или формулировки, которых нет в RESEARCH. |
| P0 | `brand/profile.md`, `brand/audience.md`, `brand/offer-core.md` | Клиентский слой правды: цены S/M/L, Avito P0, рабочие группы. Может цитироваться напрямую при сжатии. |
| P1 | `M2-исследования/M2-03-Продукт/M2-03-SYNTHESIS.md` (live, b0fd1bc) | Продуктовый контекст: материалы, прочность, сменные элементы, ценовые ярусы. Использовать только для cross-references, не как новый материал. |
| P2 | `M2-04-RESEARCH-BRIEF.md` + `M2-04-RESEARCH-BRIEF-GATE.md` | Source-map contract из 7 карт. Контрольный документ для preservation check. |
| P3 | `M2-04-TARGETED-VERIFICATION.md` | A-TV verdicts (7 шт.) — переносить с теми же caveats, без усиления. |
| REJECT | Старый `DR ЦА/AlianCat_Synthesis_CA.md/.html`, синтетические проценты/доходы/имена/районы, legacy 35-70 / 80% / 15-25 / +30-50 / дизайнер гарант | Не использовать. R7 RESEARCH явно блокирует. |

---

## 3. Evidence Labels (наследуются из RESEARCH-BRIEF)

Каждый сильный тезис synthesis внутренне отнесён к одному из:

- `CONFIRMED_CLIENT_FACT` — подтверждено P0 brand или прямым решением.
- `SUPPORTED_BY_M2` — поддержано M2-01/M2-02/M2-03 RESEARCH.
- `TARGETED_SUPPORTED` — подтверждено A-TV verdicts.
- `GLOBAL_CONTEXT_ONLY` — глобальный фон, не RU sizing.
- `LEGACY_HYPOTHESIS` — из старого DR, только как гипотеза для M4.
- `M4_HANDOFF` — требует интервью / language mining.
- `REJECTED` — не использовать.

В synthesis labels не пишутся открыто — они работают как внутренний контроль перед каждой формулировкой.

---

## 4. Source-map contract (7 карт — preservation required)

SYNTHESIS обязан представить все 7 карт source-map из M2-04-RESEARCH-BRIEF §4.1-4.7 в сжатой форме. Если writer пропускает карту — это явный coverage-loss и FAIL.

### 4.1. Карта рабочих групп аудитории

В synthesis: короткая таблица или абзацы с 7 группами + ролью каждой + статусом (ядро / proof / hypothesis / handoff). Без подробного описания каждой группы — это в RESEARCH.

Обязательные группы:

| Группа | Минимальная роль в synthesis |
|---|---|
| Эстетический владелец дома и кошки | Вероятное коммерческое ядро |
| Владельцы крупных кошек | Доказательный сегмент через прочность |
| Владельцы нескольких кошек | Сценарий проверки, гипотеза |
| Семьи с интерьерным запросом | Сценарий принятия решения, гипотеза |
| Дизайнеры интерьеров | Канал влияния, не B2B-сегмент |
| Заводчики / породные сообщества | Слой доверия, гипотеза |
| Pet-инфлюенсеры | UGC и охват, не ядро |

### 4.2. Карта мотивов и барьеров

В synthesis: сжатая карта мотивов и барьеров из RESEARCH R3+R4 с сохранением всех исходных осей §4.2 RESEARCH-BRIEF (6 мотивов + 7 барьеров). Близкие пункты можно объединять, но **нельзя терять смысловые оси.**

**Мотивы — исходные 6 осей (RESEARCH-BRIEF §4.2):**

- дом не должен выглядеть как зоомагазин;
- кошке нужно собственное место в доме;
- владелец хочет совместить заботу о кошке и эстетику интерьера;
- покупатель ищет прочность, устойчивость и безопасную конструкцию;
- кастом и материал важны как объяснение высокого чека;
- изделие должно быть видно в интерьере, а не спрятано.

**Барьеры — исходные 7 осей (RESEARCH-BRIEF §4.2):**

- высокая цена;
- страх, что кошка не примет предмет;
- доставка и риск повреждения;
- сборка и крепление;
- гарантия, возврат, дефекты;
- замена изношенных элементов;
- недоверие к дистанционной покупке дорогого изделия.

В synthesis допускается объединять близкие пункты в сжатые формулировки (например, «купить спокойно» объединяет доставку + связь + упаковку как trust-cluster), но не допускается терять следующие оси:

- кастом / материалы;
- видимость изделия в интерьере;
- сборка / крепление;
- гарантия / возврат / дефекты;
- заменяемые элементы;
- риск дистанционной покупки.

Coverage-check на §4.2 (R4.1 правило): все 6 + 7 = 13 осей должны быть выводимы из текста synthesis даже после объединений.

### 4.3. Карта каналов и discovery

В synthesis: 3 уровня (Avito подтверждённый текущий / market context / 13 каналов-гипотез) в сжатой форме. Не воспроизводить полную таблицу 15 каналов — это в RESEARCH R6. Достаточно: 3 уровня, перечисление каналов-гипотез одной строкой, явный caveat «universe, не стратегия».

### 4.4. Карта trust architecture

В synthesis: короткий блок про что снижает риск дорогой покупки (фото в интерьере, фото с кошкой, отзывы, материалы, упаковка, связь, заменяемые элементы) — без обещаний Alien Cat.

### 4.5. Карта внешнего market context

В synthesis: 1-2 абзаца. Россия с высокой долей домохозяйств с кошками, глобальный фон мебели для питомцев — оба с caveat «не RU sizing для Alien Cat».

### 4.6. Карта rejected / weakened legacy claims

В synthesis: короткий блок «что нельзя считать доказанным». Не повторять полную таблицу R7 RESEARCH — достаточно сжатой формулировки 3-4 главных рамок.

### 4.7. Карта передачи в M4

В synthesis: что собрать у Светланы + 5-7 главных вопросов для M4. Без полного 15-пунктового списка из RESEARCH R8 — достаточно top-priority выборки.

---

## 5. Genre rules / stop-list (наследуются + усилены для synthesis)

### 5.1. Genre — synthesis ≠ research ≠ M4

- Synthesis сжимает evidence, не сжимает source-map.
- Не вводить новых фактов / источников / цифр, которых нет в RESEARCH.
- Не закрывать сегменты — только давать рабочую карту с пометками статуса.
- Не делать таблицы длиннее, чем в RESEARCH (сжатие).
- Не углубляться в каждую группу больше, чем в RESEARCH.

### 5.2. Stop-list — abs hard

В synthesis не должно быть hits по grep:

- `35-70` (legacy price)
- `80%` (legacy share)
- `15-25` (legacy loss)
- `+30-50` (legacy LTV)
- `дизайнер гарант` (legacy claim)
- `JTBD` / `VPC` / `decision journey` / `аватар` (M4 territory)
- `KPI` / `медиаплан` / `бюджет на канал` / `прогноз конверсии` / `контент-план` как assertions (M7/M8 territory)
- `гарантия` / `возврат` / `рассрочка` как обещания Alien Cat без caveat
- `VIP` / `люкс` / `эксклюзив` / `премиум` как самооценка
- `Alien Cat должен` (директивный язык)

Все упоминания этих тем разрешены только как **anti-claim в R7-эквивалентном блоке** synthesis (rejected/weakened) или в **handoff-метках** (M4/M7/M8).

### 5.3. Language constraints

- Русский по умолчанию.
- Не использовать «catification», «pet humanization», «design-led» без перевода или пояснения при первом упоминании.
- Не использовать «proof», «hypothesis», «coverage», «handoff», «discovery», «universe» в клиентском тексте без замены на русский.
- Допустимы технические имена файлов / статусов / модулей (M2, M3, M4) с минимальным пояснением при первом упоминании.

---

## 6. Outline будущего `M2-04-SYNTHESIS.md`

Структура S0-S7 (контракт от owner Димы, 2026-05-27):

### S0. Что показывает M2-04 в одной картине

1-2 абзаца. Главная мысль модуля — для Светланы и для M2-06 KARTINA. В S0 или в отдельном мини-блоке после S0 обязательно закрепить **внешний market context (§4.5)** с caveat: Россия — рынок с высокой распространённостью кошек + глобальный фон мебели для питомцев + явное ограничение «не RU sizing для Alien Cat». Без этого блока §4.5 не покрывается в outline.

### S1. Видимые аудитории

Короткая карта 7 групп (см. §4.1). Таблица или абзацы.

### S2. Подтверждённые мотивы покупки

Сжатая карта мотивов с сохранением всех исходных осей §4.2 (6 мотивов RESEARCH-BRIEF). Допускается объединять близкие пункты, но нельзя потерять кастом/материалы и видимость изделия в интерьере. Сжатая форма R3 RESEARCH.

### S3. Подтверждённые барьеры доверия и зоны риска

Сжатая карта барьеров с сохранением всех исходных осей §4.2 (7 барьеров RESEARCH-BRIEF) + §4.4 trust architecture. Допускается объединять близкие пункты, но нельзя потерять сборку/крепление, гарантию/возврат/дефекты, заменяемые элементы и риск дистанционной покупки. Сжатая форма R4 RESEARCH.

### S4. Что остаётся гипотезой и уходит в M4

Короткий список открытых вопросов + что собрать у Светланы. Сжатая форма R8 RESEARCH (top-priority).

### S5. Channel universe — не стратегия

3 уровня (Avito подтверждённый / market context / 13 каналов-гипотез). Сжатая форма R6 RESEARCH.

### S6. Что уходит в M3, что в M7/M8

Короткие блоки handoff по модулям:

- **M3 (продукт / линейка / сервис):** S/M/L позиции, гарантия, возврат, замена деталей, рассрочка.
- **M7 (GTM / каналы):** какие каналы тестировать, в какой последовательности.
- **M8 (контент):** какие форматы под каналы.

### S7. Вопросы для KARTINA (M2-06)

5-8 вопросов для Светланы, на которые нужен её отклик в KARTINA. Формат вопросов — по правилу M2-06 (не спрашивать, что команда должна решить сама; спрашивать про отклик на гипотезы, факты, которые клиент знает лучше команды).

---

## 7. Acceptance criteria для `M2-04-SYNTHESIS.md`

### 7.1. Структурные

1. S0-S7 присутствуют полностью.
2. Все 7 карт source-map contract представлены (preservation check).
3. Объём — 3-5k слов / 15-30k знаков (короче RESEARCH, не второй research).
4. Есть отдельный блок rejected/weakened legacy claims (§4.6).
5. Есть отдельный M4 handoff (§4.7).
6. Есть отдельный M3/M7/M8 handoff (§6 S6).

### 7.2. Содержательные

7. Эстетический владелец = вероятное ядро (не финальное).
8. Крупные кошки = proof, не ядро.
9. Дизайнеры = канал влияния (не B2B).
10. Pet-инфлюенсеры = UGC/охват (не ядро).
11. Avito отделён от market discovery.
12. BNPL/рассрочка = future option (не обещание).
13. Глобальные отчёты не превращены в RU sizing.
14. A-TV verdicts перенесены без усиления.

### 7.3. Языковые / методологические

15. Stop-list grep по §5.2 — 0 hits как assertions (anti-claim/handoff контексты разрешены).
16. Русский язык без англицизмов в клиентском тексте.
17. Никаких новых фактов, которых нет в RESEARCH.
18. Никаких новых источников.
19. Никаких новых цифр.
20. Источники не воспроизводятся полным списком — достаточно ссылки на RESEARCH R9.

### 7.4. Source-map preservation (R4.1 правила)

21. §4.1 (группы) → S1.
22. §4.2 (мотивы+барьеры) → S2 + S3.
23. §4.3 (каналы) → S5.
24. §4.4 (trust) → S3.
25. §4.5 (market context) → S0 или отдельный мини-блок.
26. §4.6 (rejected) → отдельный блок.
27. §4.7 (M4 handoff) → S4.

---

## 8. Fail criteria

Synthesis считается проваленным, если:

- Любая из 7 карт source-map отсутствует в synthesis.
- Объём превышает 5k слов (это второй research, не synthesis).
- Появились факты/источники/цифры, которых нет в RESEARCH.
- Stop-list grep даёт hits как assertions (не anti-claim).
- M4 закрыт (аватары / JTBD / VPC / decision journey).
- Дизайнеры/заводчики/инфлюенсеры названы доказанными каналами.
- Гарантия / возврат / рассрочка поданы как обещания Alien Cat.
- A-TV verdicts усилены (стали сильнее, чем в TARGETED-VERIFICATION).
- 59% домохозяйств с кошками используется как размер аудитории Alien Cat.
- CLIENT_READY выставлен без отдельного L2 obligatory gate.

---

## 9. Roles (Builder ≠ Verifier)

| Роль | Кто | Когда |
|---|---|---|
| Brief Builder | Claude (этот файл) | 2026-05-27 |
| Brief Verifier | TBD (Codex как «второй голос» в команде AC) | следующий шаг |
| Brief Gate (L1) | Codex (Builder этого brief ≠ Verifier) | после brief verification |
| Brief Gate (L2) | Studio-методштаб | после L1 PASS |
| Synthesis Builder | Pushkin Synthesis Mode (через Claude или Codex) | только после L2 SYNTHESIS_AUTHORIZED |
| Synthesis Verifier | Второй агент команды AC + Studio-методштаб L2 obligatory | после synthesis draft |

---

## 10. Status / next gate

Текущий статус: `DRAFT / NOT_VERIFIED / NOT_SYNTHESIS_READY`.

| Step | Status | Evidence |
|---|---|---|
| Step 6.1 SYNTHESIS-BRIEF DRAFT | `READY_FOR_VERIFICATION` | этот файл |
| Brief verification (L1) | `REQUIRED` | проверить source-map preservation, evidence labels, stop-list, fail criteria, outline coverage |
| `SYNTHESIS_AUTHORIZED` (L2) | `BLOCKED_UNTIL_L1_PASS` + `BLOCKED_UNTIL_L2_OBLIGATORY` | требует Studio-методштаб verdict |
| `M2-04-SYNTHESIS.md` (Pushkin Synthesis Mode) | `BLOCKED_UNTIL_SYNTHESIS_AUTHORIZED` | не писать до L2 |
| `CLIENT_READY` | `HARD_BLOCKED` | отдельный L2 obligatory gate (LANGUAGE_TECH + READER_SANITY + EDITORIAL + COPYWRITER) |
| HTML / hub / publish | `HARD_BLOCKED` | Track 2 stages, отдельные gates |

---

## 11. Cross-refs

- `M2-исследования/M2-04-ЦА/M2-04-RESEARCH.md` (ACCEPTED R3 v1.1, 2026-05-27) — P0 источник.
- `M2-исследования/M2-04-ЦА/M2-04-RESEARCH-BRIEF.md` — модель этого brief.
- `M2-исследования/M2-04-ЦА/M2-04-RESEARCH-POST-PATCH-VERIFIER-GATE.md` — gate-evidence для P0.
- `_правила/changelog/2026-05-27-research-pipeline-candidate.md` — Track 1/Track 2 разделение + L1/L2/L3 эскалация.
- `_правила/rules/m2-structure.md` candidate v1.3 — operational stages Client Track.
- `feedback_synthesis_brief_required.md` (Studio memory) — base правило: SYNTHESIS-BRIEF + RESEARCH-BRIEF с source-map contract.

---

*Brief Builder: Claude (2026-05-27). Brief Verifier: Codex (2026-05-28, L1 BRIEF_PASS). Roles separated per R1 candidate canon v1.1.*

---

## File layer stamp

```text
Status:   ACCEPTED (R3 v1.1)
Layer:    M2-04 SYNTHESIS-BRIEF (Track 1 → Track 2 transition contract)
Version:  draft + patch 01 (source-map preservation §4.2) + micro-wording patch (2026-05-28)
Builder:  Claude (original draft 2026-05-27 + patch 01 + micro-wording 2026-05-28)
Verifier: Codex (L1 review cycle 2026-05-28 → BRIEF_PASS after patch + micro-wording)
Gates:    L1 PATCH_REQUIRED (Codex) → patch 01 applied → L1 BRIEF_PASS (Codex) → micro-wording (operational exception) → L2 SYNTHESIS_AUTHORIZED = VARIANT_A (Дима owner accept 2026-05-28)
R4 Coverage Integrity Check (brief-level): 4.1 PASS (7/7 карт RESEARCH-BRIEF §4.1-4.7 в outline) / 4.2 N/A / 4.3 N/A / 4.4 PASS (0 hits legacy grep)
R9 active-context: updated 2026-05-28 (section «M2-04 SYNTHESIS-BRIEF L1 BRIEF_PASS» + L2 SYNTHESIS_AUTHORIZED VARIANT_A)
Carry-forward rails (mandatory, not recommendations): mandatory limitations / gaps / client facts / boundary preservation. Не сглаживать DR_HYPOTHESIS / WEAK_SIGNAL / CLIENT_FACT_REQUIRED в утверждения.
Phase 2 trigger: Pushkin Writer Mode на M2-04-SYNTHESIS.md разрешён. R1 per-gate / per-artefact (coordinator clarification 2026-05-28 supersedes первоначальную формулировку «другой агент»): Claude может быть Builder обоих BRIEF и SYNTHESIS; R1 запрет включается на verifier уровне — Verifier SYNTHESIS ≠ Builder SYNTHESIS. Reference: gate-frequency-cheatsheet.md lines 88-105.
Downstream: SYNTHESIS_READY (после L1 verifier + L2 method gate). CLIENT_READY / HTML_READY / DEPLOYED / M2-06 / другие модули AC — не разрешены этим L2.
```

---

## QUARANTINE STAMP — 2026-05-28

```text
Status:    QUARANTINED / DO_NOT_USE_AS_SOURCE
Date:      2026-05-28
Reason:    Per 2026-05-28 P0 incident — premature downstream from invalid RESEARCH_READY (укороченный pipeline candidate v1.0/v1.1)
Reference: _правила/changelog/2026-05-28-incident-revoke-research-pipeline-candidate.md
           _правила/changelog/2026-05-28-stop-invariant-canon-defense.md
Previous stamps: file layer ACCEPTED (R3 v1.1) от 2026-05-28 — SUPERSEDED by QUARANTINED.
Action:    Файл не удалять. Не использовать как input / source / контракт для downstream работ.
           История правок и L1 BRIEF_PASS verdict от Codex остаются как historical traces (не отзываются как factual events).
           Любой будущий SYNTHESIS-BRIEF создаётся после RESEARCH_OWNER_ACCEPTED + SYNTHESIS-PREFLIGHT 5/5, не из этого файла.
```
