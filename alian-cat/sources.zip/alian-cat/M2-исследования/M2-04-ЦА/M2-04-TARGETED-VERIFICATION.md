# M2-04 Targeted Verification — Целевая аудитория Alien Cat

Дата: 2026-05-27  
Статус: `TARGETED_VERIFICATION_DONE / NOT_RESEARCH_READY`  
Основание: `M2-04-SOURCE-PACKET.md`, раздел 7  
Метод: targeted Firecrawl search + scrape по backlog A-TV-01..A-TV-07. Это не полный Deep Research и не клиентский текст.

## 1. Итоговое решение

Verdict: `GO_TO_RESEARCH_BRIEF_WITH_LIMITATIONS`.

Новый full DR пока не обязателен. Достаточно идти в `M2-04-RESEARCH-BRIEF.md`, если brief сохранит ограничения ниже:

- M2-04 описывает группы, мотивы, барьеры и каналы как исследовательскую карту, а не финальную сегментацию.
- Все точные проценты legacy-слоя не переносятся без источника и года.
- Дизайнеры интерьеров остаются каналом влияния / гипотезой, а не подтверждённым B2B-контуром.
- Рассрочка / BNPL — возможный способ снизить барьер высокого чека, но эффект для Alien Cat не измерен.
- Avito подтверждён как текущий канал Alien Cat по P0, но не как единственный рынок.

`RESEARCH_READY` ещё нельзя ставить: сначала нужен `M2-04-RESEARCH-BRIEF.md` с source-map contract и fail criteria.

## 2. Короткая матрица решений

| ID | Проверка | Verdict | Что можно использовать дальше | Что нельзя утверждать |
|---|---|---|---|---|
| A-TV-01 | Доля домохозяйств РФ с кошками | `SUPPORTED_WITH_CAVEAT` | Россия — сильный cat-market; можно использовать несколько точек с годом и источником. | Нельзя брать 59% как единственную точную базу для sizing аудитории Alien Cat. |
| A-TV-02 | Pet humanization / premium pet furniture | `SUPPORTED_GLOBAL / RUSSIA_GAP` | Глобально подтверждён спрос на красивую, качественную и интерьерно совместимую мебель для питомцев. | Нельзя напрямую выводить объём российского сегмента Alien Cat из глобальных отчётов. |
| A-TV-03 | Владельцы крупных кошек: прочность / устойчивость | `SUPPORTED_AS_PROOF_SEGMENT` | Прочность, устойчивость, крупные лежанки, heavy base, replacement parts — реальные buyer concerns. | Нельзя утверждать, что это главное ядро рынка или что все владельцы крупных кошек готовы платить premium. |
| A-TV-04 | Дизайнеры интерьеров как канал | `WEAK_SIGNAL / NOT_VERIFIED` | Оставить как канал-гипотезу для M4/M7 и owner validation. | Нельзя писать «дизайнер гарантирует сделку», «нужны 3D-модели» или «это подтверждённый B2B-канал». |
| A-TV-05 | Каналы inspiration/search | `SUPPORTED_DIGITAL_DISCOVERY / CONVERSION_UNKNOWN` | Avito подтверждён P0 как канал Alien Cat; внешние источники поддерживают online/social discovery. | Нельзя распределять сегменты по каналам и нельзя считать Pinterest/Instagram доказанными продажными каналами Alien Cat. |
| A-TV-06 | Барьеры дорогой дистанционной покупки | `SUPPORTED_PURCHASE_RISK` | Доставка, возврат, гарантия, сборка, замена частей и риск «кошке не зайдёт» — валидные зоны доверия. | Нельзя обещать гарантию/возврат/обслуживание Alien Cat без решения клиента и M3. |
| A-TV-07 | BNPL / рассрочка | `SUPPORTED_BNPL_GENERAL / CATEGORY_EFFECT_UNKNOWN` | Можно оставить как возможный future option для высокого чека. | Нельзя переносить legacy-тезис «15-25% потери без рассрочки» как факт Alien Cat. |

## 3. A-TV-01 — кошки в российских домохозяйствах

### Что найдено

Есть несколько не полностью совпадающих, но совместимых уровней данных:

- Vet&Life (03.02.2026) пересказывает международную агрегацию Seasia Stats и пишет, что Россия лидирует по доле домохозяйств с кошками; для России указана оценка 59% на базе набора источников 2024-2026.
- TAdviser по данным всероссийской переписи домашних животных 2023 даёт локальную базу: 74,8 млн домашних животных, 49,2 млн кошек, 30,5 млн семей с кошками; 30% домохозяйств держат только кошек, ещё 16% — кошек и собак.
- TAdviser также фиксирует рыночный контекст 2025: рынок зоотоваров РФ около 590 млрд ₽ и около 50 млн кошек в российских домохозяйствах.

### Решение

Можно писать, что Россия — рынок с очень высокой распространённостью кошек и что кошка является массовым домашним питомцем. В числах использовать осторожно:

- для общего market context: 49-50 млн кошек и 30,5 млн семей с кошками как локальная российская база 2023/2025;
- оценку 59% использовать только как международную ranking-точку с явным источником и caveat.

Нельзя из этих данных выводить размер premium/interior сегмента Alien Cat.

## 4. A-TV-02 — pet humanization и premium pet furniture

### Что найдено

Глобальные отчёты устойчиво описывают тот же контекст, в котором работает Alien Cat:

- Persistence Market Research (May 2026): global pet furniture market, pet humanization, эстетически согласованная мебель, premium tier как быстрорастущий слой, online channels и social discovery.
- Fortune Business Insights (May 2026): рост global pet furniture market, eco-friendly / multifunctional products, customized design and sizes, high product cost как restraining factor.
- Verified Market Research (Jan 2026): pet furniture как категория beds / cat trees / scratching posts / feeding stations; спрос смещается от чистой функции к comfort + design appeal.

### Решение

Можно использовать как внешний контекст: покупатели всё чаще хотят не просто «зоотовар», а предмет, совместимый с домом, кошкой и эстетикой интерьера.

Обязательный caveat: это глобальные category reports, не российский sizing и не доказательство спроса именно на Alien Cat.

## 5. A-TV-03 — крупные кошки, устойчивость и прочность

### Что найдено

Cats.com в обзоре cat trees 2026 отдельно выделяет варианты для large cats, multi-cat homes, sturdy base, wide base, wall strap и weight capacity. В тексте и комментариях повторяются запросы на большие top platforms, стабильные wall steps и безопасную фиксацию.

Cat Tree King позиционирует часть линейки как ideal for larger and multi-cat households. В отзывах и продуктовых описаниях повторяются мотивы: heavy/stable base, large platforms, thick sisal posts, replaceable parts, опыт владельцев Maine Coon / Ragdoll / нескольких крупных кошек. Есть и обратный сигнал: дорогой предмет может не сразу использоваться кошкой.

### Решение

Владельцев крупных кошек можно оставлять как proof-сегмент: они хорошо раскрывают прочность, устойчивость, размеры лежанок, заменяемость и доверие к конструкции.

Нельзя делать их единственным ядром Alien Cat. По P0 ядро шире: эстетический покупатель дома и кошки.

## 6. A-TV-04 — дизайнеры интерьеров

### Что найдено

По targeted search не найдено сильного подтверждения, что интерьерные дизайнеры системно продвигают pet/interior products через 3D-модели, sample kit или проектные рекомендации. В найденных источниках есть adjacent signals: design-led cat furniture, social/design communities, wholesale / affiliate programs у отдельных брендов. Но это не доказывает канал «дизайнер интерьера приводит сделку».

### Решение

Дизайнеров интерьеров оставить в source packet как канал влияния и гипотезу:

- проверить в M4/M7;
- спросить у клиента, были ли реальные рекомендации через дизайнеров;
- не оформлять как B2B-сегмент до owner decision.

Legacy-тезис «дизайнер гарантирует сделку» отклонён.

## 7. A-TV-05 — каналы inspiration/search

### Что найдено

P0 Alien Cat фиксирует Avito как текущий основной источник клиентов: 20-30 обращений в месяц и около 10 заказов.

Внешний слой добавляет контекст:

- публикация Gazeta.SPb по данным Авито Рекламы и Авито Товаров: в опросе 10 тыс. россиян; для Санкт-Петербурга 29% владельцев питомцев покупают зоотовары онлайн, 33% узнают о товарах через рекламу на сайтах объявлений и маркетплейсах, 13% — через соцсети; мебель для питомцев упомянута как статья расходов у 12%.
- Persistence Market Research указывает online channels и Instagram / Pinterest / TikTok как discovery-среду для pet furniture.
- The Refined Feline как industry/blog source описывает social media и customer photos как источник вдохновения по modern cat furniture.

### Решение

Можно разделить каналы на три слоя:

1. `CONFIRMED_CLIENT_FACT`: Avito как текущий канал Alien Cat.
2. `SUPPORTED_MARKET_CONTEXT`: online platforms / marketplaces / social discovery.
3. `HYPOTHESIS_FOR_M4_M7`: Instagram, Pinterest, породные сообщества, дизайнеры, pet-инфлюенсеры как возможные каналы, но без конверсии.

## 8. A-TV-06 — барьеры дорогой дистанционной покупки

### Что найдено

Премиальные и средне-высокие pet furniture бренды явно работают с барьерами:

- Mau Pets даёт 45-day free returns для США/Канады, формулирует возврат как случай, если владелец или кошка недовольны покупкой, и даёт 1-year warranty на functional defects.
- Armarkat FAQ описывает shipping, warranty, return policy, replacement parts и требование фото при дефектах.
- Cat Tree King и The Refined Feline показывают replacement parts как часть ценности и доверия.

### Решение

Для будущего M2-04 можно использовать барьеры как валидные:

- доставка и упаковка;
- сборка;
- гарантия / дефекты;
- заменяемые элементы;
- риск «кошке не зайдёт»;
- доверие через фото, видео и отзывы.

Нельзя переносить это в публичное обещание Alien Cat до M3: warranty, returns, replacement service и рассрочка требуют решения клиента.

## 9. A-TV-07 — рассрочка / BNPL

### Что найдено

BNPL подтверждается как общий retail-инструмент, но не как измеренный эффект для Alien Cat:

- Т-Банк (08.05.2026) сообщает о BNPL-брокере Долями: пилот в 4 000+ магазинах, несколько сервисов оплаты частями в одном интерфейсе, заявлен рост дополнительного одобрения на 16% и выдач на 30% за счёт внешних провайдеров. Это данные продукта Т-Банка, не category benchmark.
- Plusworld / LIFE PAY advertorial (27.03.2026) пишет о влиянии BNPL на средний чек и конверсию при правильной интеграции, а также о релевантности для товаров от 5 000 ₽. Источник рекламный, поэтому годится только как слабое подтверждение механики, не как independent market evidence.
- The Refined Feline как premium cat furniture store предлагает payment plans через Sezzle / Afterpay / Affirm, что показывает применимость installment-механики в категории modern cat furniture за рубежом.

Проверка T-Банк Secrets была заблокирована 401. Страница Dolyame blog вернула только metadata без основного markdown, поэтому не используется как content evidence.

### Решение

Можно писать: рассрочка / BNPL может снижать психологический барьер высокого чека и стоит рассмотреть как M3/M7-гипотезу.

Нельзя писать: «без рассрочки Alien Cat теряет 15-25% сделок». Это legacy-тезис без клиентского измерения.

## 10. Источники

### Российский market / pet ownership

- Vet&Life — Россия возглавила мировой рейтинг стран с самым высоким числом кошек в домах: https://vetandlife.ru/pet-business/rossiya-vozglavila-mirovoj-rejting-stran-s-samym-vysokim-chislom-koshek-v-domah/
- TAdviser — Домашние животные в России: https://www.tadviser.ru/index.php/Статья:Домашние_животные_в_России
- Gazeta.SPb — Авито: треть петербуржцев покупает зоотовары онлайн: https://gazeta.spb.ru/2651847-avito-tret-peterburzhczev-pokupaet-zootovary-onlajn/

### Pet furniture / humanization / design-led category

- Persistence Market Research — Pet Furniture Market: https://www.persistencemarketresearch.com/market-research/pet-furniture-market.asp
- Fortune Business Insights — Pet Furniture Market: https://www.fortunebusinessinsights.com/pet-furniture-market-106261
- Verified Market Research — Pet Furniture Market: https://www.verifiedmarketresearch.com/product/pet-furniture-market/
- The Refined Feline — 2026 Modern Cat Furniture Trends: https://www.therefinedfeline.com/modern-cat-furniture-trends/

### Large cats / sturdiness / purchase risks

- Cats.com — The 13 Best Cat Trees: https://cats.com/reviews/best-cat-trees
- Cat Tree King: https://cattreeking.com/
- Mau Pets — Shipping, Returns, & Warranty: https://www.maupets.com/pages/shipping-returns-warranty
- Armarkat FAQ: https://www.armarkat.com/faq/

### BNPL / рассрочка

- Т-Банк — Первый в России BNPL-брокер: https://www.tbank.ru/about/news/08052026-russias-first-bnpl-broker-dolyami-now-offers-several-payment-services-in-installments/
- Plusworld / LIFE PAY — Рассрочка и BNPL: когда они реально увеличивают продажи: https://plusworld.ru/lr/71018/

## 11. Передача в Research Brief

В `M2-04-RESEARCH-BRIEF.md` обязательно перенести:

1. Source hierarchy: P0 brand facts выше внешних источников.
2. Evidence labels из `M2-04-SOURCE-PACKET.md`.
3. Таблицу A-TV verdicts как ограничения для Pushkin Research Mode.
4. Отдельный блок `Rejected / weakened legacy claims`.
5. M4 handoff: что нужно спросить у клиента и какие сегменты нельзя закрывать в M2-04.

Рекомендуемый следующий статус progress ledger: `READY_FOR_RESEARCH_BRIEF / NOT_RESEARCH_READY`.
