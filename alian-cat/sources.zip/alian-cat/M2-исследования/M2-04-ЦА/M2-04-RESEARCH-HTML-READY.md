# M2-04 RESEARCH HTML — Gate Stamp (6-check, evidence)

**Verdict:** `HTML_READY` — **OWNER-ACCEPTED 2026-06-05** (Дима вычитал глазами, принял RESEARCH HTML после hero-патча + §1 metric-cards). Deploy — Codex отдельной командой.
**Date:** 2026-06-05
**HTML:** `html/M2-04-RESEARCH.html` (1819 строк)
**Source MD:** `M2-04-RESEARCH.md` (CLIENT_READY, owner-accepted 2026-06-05)
**Provenance:** `built_from_client_md_hash: 0cd14c9bd5e0747e` (= sha256[:16] от MD, совпадает)

> HTML синхронизирован с вычищенным MD (пути/DR/MCP убраны и в HTML). Свежий канон применён: provenance, hub-link «К хабу клиента →» + пилюля «К хабу», hero-lede full-width (max-width 790px → none). **Deploy/hub НЕ делались.** Финал — owner eye-check.

## 6 internal checks

| # | Check | Метод / evidence | Результат |
|---|---|---|---|
| 1 | TECH | doctype + provenance (стр.1-2); charset=1; section 14/14, div 160/160 сбалансированы | ✅ PASS |
| 2 | CONTENT_SYNC | provenance `0cd14c9bd5e0747e` == MD hash; таблица «Исходные файлы» синхронизирована с MD; объёмы/цитаты совпадают | ✅ PASS |
| 3 | CLIENT_LANGUAGE | grep rendered HTML: `/Users/`=0, `DR Gemini`=0, `DR GPT`=0, `MCP`=0, `.md<`=0, ИИ-обороты=0 | ✅ PASS |
| 4 | POST_RENDER | Playwright chromium desktop 1440 + mobile 375, `networkidle` — без ошибок | ✅ PASS |
| 5 | VISUAL_SMOKE | desktop + mobile PNG + hero-crop (fade-up override); hero-lede full-width подтверждён, без разъезда со stat-grid | ✅ PASS |
| 6 | DESIGN_REVIEW | Чтение глазами hero: toplink hub-link, 4 stat-card (9 мотив. групп / 9 сценариев / 66 цитат / 15+8 доверие-барьеры), CTA, meta. Зеркалит принятый M2-04 shell + свежий канон. Single-reviewer (Claude) | ⚠️ CLAIMED_PASS |

## Addendum — Hero PATCH (PATCH_REQUIRED перед owner eye-check, 2026-06-05)
Owner поймал: hero дублировал §1 «Краткое резюме» (hero-lede выдавал первый аналитический вывод вместо self-description).
- **hero-lede** → self-description. История версий: (1) первая версия (Claude inline) — забракована owner за канцелярит «кто рассматривает мебель»; (2) **Пушкин real Agent run** (copywriter skill, opus, agentId `a3f5d654e3960419e`, прочитал SKILL.md, 1 tool-use, 56.8k токенов) дал «портрет человека… палец над кнопкой» — **тоже забраковано owner** за литературщину (промпт ошибочно просил «образный хук»); (3) **ФИНАЛ — простой owner-directed текст (Claude inline, по прямому указанию Димы):** «Глубокое исследование целевой аудитории… кто покупатель, какие мотивы и страхи… Документ нужен для стратегической сессии…». Это owner-directed формулировка, НЕ авторский текст Пушкина. Добавлен в MD (blockquote после H1) — провенанс `0cd14c9bd5e0747e`.
- **stat-grid** теперь только про аудиторию: 9 мотивационных групп / 9 поведенческих сценариев / 66 живых цитат / **15 + 8 (доверие и барьеры)**. 4-я карточка «Рынок зоотоваров 590 млрд ₽» убрана.
- **market-size из hero убран** (590 млрд + Avito не в первом экране; в теле §1 «Краткое резюме» контекст рынка остаётся — это не hero).
- §1 не дублируется в hero.

## Свежий канон (применён)
- Provenance `0cd14c9bd5e0747e`.
- Hub-link «К хабу клиента →» (toplink) + «К хабу» (nav-пилюля) — уже были, сохранены.
- hero-lede full-width (патч 04).
- Клиентский слой = язык вычищен (патч-логика как в M2-05).

## Что НЕ сделано
- Deploy / hub — нет.
- SYNTHESIS — не стартован (по owner-directive: до accept RESEARCH HTML).

> RESEARCH HTML owner-accepted 2026-06-05 (verdict сверху). Финальный статус выставлен.

## Addendum 2 — §1 «Краткое резюме» metric-cards (owner-directed, 2026-06-05)
Owner: карточки §1 были про market-size (49,2 млн кошек / 590 млрд ₽ / Avito 20-30/10) — не про наше исследование. Заменены на 3 находки исследования (hook): «как делить аудиторию — по мотиву», «главный барьер — не цена», «что запускает покупку — событие». Все verifiable в MD §1 (мотивация/барьер/триггер). Market-числа остаются в теле §8/§9/§11. HTML-only, MD/provenance не менялись (`0cd14c9bd5e0747e`).
