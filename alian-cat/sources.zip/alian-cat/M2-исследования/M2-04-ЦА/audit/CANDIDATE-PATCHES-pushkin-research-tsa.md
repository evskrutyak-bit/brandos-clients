# CANDIDATE PATCHES — `pushkin-research-tsa.md`

**Цель файла:** предложить методштабу список из 5 patches шаблона `dev/nu-research-pipeline/templates/pushkin-research-tsa.md`.

**Подготовил:** Claude (Coordinator).

**Дата:** 2026-06-03.

**Статус:** **candidate, awaiting methodstab approval.** Шаблон НЕ изменён. Этот файл — proposal.

**Источник patches:** короткий список owner от 2026-06-03 («READ_LEDGER, rejected claims/replacements, runtime-neutral Agent wording, приоритет рабочей аудитории, prompt-enhancer score»). P1 уточнён по запросу owner: «без цитат/хешей/размеров, только read-status и что использовано».

**Что НЕ в этом patch:** прочие 2 R-проблемы из `TEMPLATE-GATE.md` (R-03 prompt hash, R-04 NOT TECHNICALLY PROVEN отдельно) отброшены как переусложнение.

---

## P1 — READ_LEDGER в отчёте Pushkin (упрощённый)

**Проблема:** Шаблон не требует от Pushkin перечислить, какие файлы он прочитал и где использовал. Coordinator и методштаб не получают независимого подтверждения чтения SKILL.md и source-файлов из самого output.

**Куда:** Раздел 10 «Финальный формат выдачи» шаблона (стр. 145-153).

**Что добавить (после строки «Что не удалось установить: одной строкой»):**

```
READ_LEDGER (Pushkin перечисляет):
- ~/.claude/plugins/content-dept-v5/skills/copywriter/SKILL.md — READ
- {OUTPUT_PATH-промпт}.md — READ
- {DR_FILE_1} — READ, USED for sections N, M
- {DR_FILE_2} — READ, USED for sections N, M
- {MCP_FILE_1} — READ, USED for sections N
- {MCP_FILE_2} — READ, USED for sections N
- [иные файлы, прочитанные субагентом без указания в промпте] — READ, причина
```

**Правила:**
- Только read-status (READ / NOT_READ) и что использовано (USED for sections N).
- Без цитат, без хешей, без размеров файлов.
- Если файл прочитан, но не использован — пометить «READ, NOT_USED, причина».
- Если файл указан в промпте, но не прочитан — пометить «NOT_READ, причина» и это блокер.

**Эффект:** Coordinator получает self-declaration Pushkin о фактическом чтении. Это не tool-log, но даёт явное заявление subagent, проверяемое цитатными следами в output.

---

## P2 — Явные rejected claims / replacements

**Проблема:** Шаблон требует «не выбрасывать факты из сырья», но не описывает, как Pushkin должен поступать с legacy-claims, помеченными в brief или owner-решении как REJECTED → NEW. В первом transfer-test это привело к попаданию старой ценовой рамки «35-70 тысяч» из DR в первую фразу Pushkin output, хотя в `M2-04-RESEARCH-BRIEF.md` §4.6 эта рамка помечена как REJECTED («Премиальная мебель 35-70 тыс. → заменить на рабочие S 20-30, M 30-50, L 75-100; точная матрица в M3»).

**Куда:** Раздел 6 «Чего нельзя» шаблона (стр. 88-95). Добавить новый bullet в конец списка запретов.

**Что добавить:**

```
- **Legacy claims с REJECTED-статусом.** Если filled prompt содержит блок
  REJECTED → NEW (формулировки, которые ранее были в DR/legacy-источниках,
  но отвергнуты brief / owner-decision и заменены на новые) — обязательно
  использовать новые формулировки, не воспроизводить старые из сырья.
  Пример: «премиальная мебель 35-70 тыс.» → заменено на «рабочие диапазоны
  S 20-30, M 30-50, L 75-100 тыс. ₽; точная матрица — в продуктовом слое».
```

**Куда (вторая правка):** Шапка-инструкция шаблона (стр. 1-26). Добавить опциональную переменную:

```
{REJECTED_CLAIMS} — опц., список REJECTED → NEW замен, актуальных для
                   данного артефакта (берётся из brief §«rejected claims»
                   или owner-decisions; если пусто — блок убрать).
```

И в раздел 1 шаблона добавить строку (рядом с {WORKING_AUDIENCE}):

```
**REJECTED → NEW замены (актуальны для этого артефакта):** `{REJECTED_CLAIMS}`
```

**Эффект:** Pushkin получает явный список legacy-claims, которые нельзя воспроизводить из DR, и заменителей на client-language.

---

## P3 — Runtime-neutral Agent wording

**Проблема:** В шапке-инструкции и Real-run evidence block шаблона указано `subagent_type="claude"`. В runtime Coordinator-а этот subagent type не зарегистрирован (доступны: `claude-code-guide`, `Explore`, `general-purpose`, `Plan`, `statusline-setup`). В первом transfer-test Builder вынужден был использовать `general-purpose` + `model="opus"` как эквивалент.

**Куда #1:** Шапка-инструкция, шаг 5 (стр. 23-24).

**Было:**
```
5. Запуск (A4) — ТОЛЬКО real-run: Agent(subagent_type="claude", model=opus,
   "Прочитай ~/.claude/plugins/content-dept-v5/skills/copywriter/SKILL.md + этот промпт + источники").
```

**Стало:**
```
5. Запуск (A4) — ТОЛЬКО real-run: Agent(subagent_type="general-purpose", model="opus",
   "Прочитай ~/.claude/plugins/content-dept-v5/skills/copywriter/SKILL.md + этот промпт + источники").
   Примечание: используется общий subagent-канал runtime'а с явным model=opus.
   Если в runtime появится регистрированный `claude` subagent type — заменить.
```

**Куда #2:** Real-run evidence block раздела 10 (стр. 156-163).

**Было:**
```
- Agent role:             copywriter (Research Mode)
```

**Стало (добавить поле выше):**
```
- Agent type / model:     general-purpose / opus
- Agent role:             copywriter (Research Mode)
```

**Эффект:** Шаблон и runtime согласованы. Builder не импровизирует.

---

## P4 — Приоритет рабочей аудитории и гипотез

**Проблема:** В разделе 6 шаблона (стр. 89) приведён пример перевода калек: «Эстетический владелец» → «владелец, для которого важна эстетика». Если в filled prompt `{WORKING_AUDIENCE}` или `{CLIENT_HYPOTHESES}` содержат другую согласованную формулировку (например, owner-decision 2026-05-29: «покупатель с интерьерным запросом»), Pushkin может буквально следовать примеру шаблона. В первом transfer-test так и произошло.

**Куда:** Раздел 6 шаблона (стр. 88-95). Добавить bullet в начало списка (до «Кальки с английского»).

**Что добавить:**

```
- **Приоритет `{WORKING_AUDIENCE}` и `{CLIENT_HYPOTHESES}` над примерами этого раздела.**
  Формулировки и названия групп аудитории из `{WORKING_AUDIENCE}` (раздел 1) и
  `{CLIENT_HYPOTHESES}` (раздел 7) — это owner-согласованные термины. Они
  имеют приоритет над любыми примерами в этом разделе («эстетический владелец»
  → «владелец, для которого важна эстетика»). Если `{WORKING_AUDIENCE}` даёт
  «покупатель с интерьерным запросом» — используй именно это, не пример шаблона.
```

**Эффект:** Owner-decisions не теряются между brief, filled prompt и output.

---

## P5 — Prompt-enhancer score обязателен

**Проблема:** Канон `~/studio/neyroupakovka/_правила/rules/prompts.md` требует прогона любого промпта через `/prompt-enhancer` до 9+/10 перед запуском. Шаблон этого требования не упоминает, в первом transfer-test Builder не выполнил шаг.

**Куда:** Шапка-инструкция шаблона, шаги A2-A3 (стр. 11-22).

**Что добавить (новый шаг между текущим шагом 3 и шагом 4):**

```
3.5. После заполнения и перед отправкой методштабу на сверку — прогнать
     промпт через `/prompt-enhancer`. Целевая оценка ≥ 9/10. Если ниже —
     доработать до 9+. Канон: `_правила/rules/prompts.md` §«Обязательный
     инструмент: prompt-enhancer».
```

**Эффект:** Канон `prompts.md` соблюдается на каждом запуске. Слабые формулировки промпта ловятся до Agent run.

---

## Сводка patches

| # | Patch | Severity | Локация в шаблоне |
|---|---|---|---|
| P1 | READ_LEDGER (упрощённый) | HIGH | раздел 10 |
| P2 | Rejected claims/replacements | HIGH | раздел 6 + шапка-инструкция + раздел 1 |
| P3 | Runtime-neutral Agent wording | HIGH | шапка-инструкция стр. 23-24 + раздел 10 evidence block |
| P4 | Приоритет working audience и hypotheses | MEDIUM | раздел 6 (начало) |
| P5 | Prompt-enhancer score 9+/10 | MEDIUM | шапка-инструкция шаг 3.5 |

---

## Что после approval методштабом

1. Методштаб применяет 5 patches к `dev/nu-research-pipeline/templates/pushkin-research-tsa.md` (или возвращает с правками / отказом).
2. Coordinator пересобирает `M2-04-PUSHKIN-PROMPT.md` v2 на обновлённом шаблоне (с заполнением новых полей `{REJECTED_CLAIMS}`).
3. Coordinator прогоняет filled prompt v2 через `/prompt-enhancer` до 9+/10.
4. Один handoff методштабу «5 пунктов» (по Picnic-схеме).
5. После «ок» — реальный Agent() Pushkin + Real-run evidence (один файл с READ_LEDGER).
6. Независимая верификация (Claude ≠ сборщик).
7. Методштаб review текста.
8. Дальше — Picnic-цепочка до OWNER_ACCEPTED LIVE.

---

*Подготовил Claude. Файл — proposal методштабу. Применение patches — за методштабом.*
