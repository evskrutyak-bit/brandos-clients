# M2-04 Progress Ledger — Целевая аудитория

Дата старта: 2026-05-27  
Канон: M2 v1.3 + salvage-first directive 2026-05-24  
Направление: M2-04 Целевая аудитория  
Клиент: Alien Cat / AlianCat

## Current State

M2-04 открыт как новый рабочий трек. Новая каноническая папка создана: `M2-исследования/M2-04-ЦА/`.

Targeted verification backlog закрыт 2026-05-27 в `M2-04-TARGETED-VERIFICATION.md`. Текущий рабочий verdict: `GO_TO_RESEARCH_BRIEF_WITH_LIMITATIONS`. `M2-04-RESEARCH-BRIEF.md` создан и проверен в `M2-04-RESEARCH-BRIEF-GATE.md`. Draft `M2-04-RESEARCH.md` собран и прошёл `M2-04-RESEARCH-QUALITY-GATE.md` как внутренний research draft. `RESEARCH_READY` ещё не выставляется: нужен language/editorial pass и, возможно, таблица доказательности источников в R9.

Старые материалы найдены в:

- `M2-исследования/DR ЦА/`
- `M2-исследования/_fact-check/M2-04-CA-*`
- `M2-исследования/_archive/html-before-m2-cleanup-2026-05-19/`

Они не считаются готовым RESEARCH/SYNTHESIS по новому M2. Использование возможно только после salvage-аудита и source-status matrix.

## Direction-Level Workflow

| Step | Name | Status | Evidence |
|---|---|---|---|
| Step 0 | Salvage setup | DONE | `README.md`, `M2-04-SALVAGE-AUDIT.md` |
| Step 0.5 | Source packet | RESEARCH_DRAFT_SOURCE_COVERAGE_PASS | `M2-04-SOURCE-PACKET.md` обновлён после targeted verification, brief, Research draft и quality gate; `RESEARCH_READY` ещё нельзя |
| Step 1 | DR-PROMPT | NOT_REQUIRED_YET | full DR не запускается до решения после `M2-04-RESEARCH-BRIEF.md`; текущий route — source packet + targeted verification |
| Step 2 | DR / DR-SOURCES intake | NOT_REQUIRED_YET | new DR пока не обязателен; если brief выявит core gaps, вернуться к DR-PROMPT |
| Step 3 | Calibration | NOT_STARTED | — |
| Step 4 | Targeted MCP + evaluation | DONE_WITH_LIMITATIONS | `M2-04-TARGETED-VERIFICATION.md` — 7/7 backlog items закрыты, verdict `GO_TO_RESEARCH_BRIEF_WITH_LIMITATIONS` |
| Step 5.1 | RESEARCH-BRIEF | VERIFIED_FOR_RESEARCH_DRAFT | `M2-04-RESEARCH-BRIEF.md` — source-map contract, outline, acceptance criteria, fail criteria |
| Step 5.1b | RESEARCH-BRIEF verification | PASS | `M2-04-RESEARCH-BRIEF-GATE.md` |
| Step 5.1c | SYNTHESIS-BRIEF | NOT_STARTED | только после client-facing RESEARCH |
| Step 5.2a | RESEARCH draft | SOURCE_COVERAGE_PASS / NOT_RESEARCH_READY | `M2-04-RESEARCH.md`, `M2-04-RESEARCH-QUALITY-GATE.md` |
| Step 5.2b | Client-facing SYNTHESIS | NOT_STARTED | — |
| Stage 4 / 4.8 / 4.9 | Language, reader sanity, editorial | NOT_STARTED | — |
| Stage 5 | HTML_READY package | NOT_STARTED | — |
| Stage 6 | DEPLOY_QC / publish | NOT_STARTED | — |

## Stop Rules

- `RESEARCH_READY` не ставить до language/editorial pass по `M2-04-RESEARCH.md` и финального решения по R9-таблице доказательности источников.
- `CLIENT_READY` не ставить на старый `AlianCat_Synthesis_CA.md`.
- `HTML_READY` не ставить на старый `AlianCat_Synthesis_CA.html`.
- Любой `PASS` должен иметь evidence: файл проверки, критерии, результат, verifier.

## Следующий шаг

Провести language/editorial pass для `M2-04-RESEARCH.md`.

Стоп-условия остаются:

- `RESEARCH_READY` не ставить до language/editorial pass;
- не переходить к SYNTHESIS и HTML;
- не использовать старый `AlianCat_Synthesis_CA.html`.
