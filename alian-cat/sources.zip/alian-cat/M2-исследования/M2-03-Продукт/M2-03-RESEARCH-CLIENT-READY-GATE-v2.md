# M2-03 RESEARCH — CLIENT_READY Gate (v2, evidence) — закрытие долга E16

**Verdict:** `CLIENT_READY` — **OWNER_ACCEPTED (owner eye-check PASS 2026-06-06). Final.**
**Date:** 2026-06-05 (verified) · 2026-06-06 (owner accept)
**Production source:** `M2-03-RESEARCH-client.md` (= verified+patched `M2-03-RESEARCH-v2.md`)

> **CURRENT source hash (единственный действительный): `3b3b2b1a8b770237`.**
> Superseded (НЕ current): `ca9c48be17e53c5c` → `cb19b9cc1590fc17` → **`3b3b2b1a8b770237`**. Любая ссылка на ca9c48be / cb19b9cc ниже — историческая (см. HISTORY).

**Контекст:** закрытие долга E16 (инцидент 2026-05-25). Старый `M2-03-RESEARCH-client.md` (structural cleanup, INVALID) → `_archive-research-incident-2026-05-25/`.

## Цепочка (Builder ≠ Verifier)
- **Writer:** Pushkin Research Mode rewrite → `M2-03-RESEARCH-v2.md` (284 KB, post-incident). Builder-claimed source-coverage 13/13 + language-guard.
- **Independent verifier:** Agent `ac6d28c505d6cd69b` (≠ writer, прочитал client-language-guard SKILL, 44 tool-use). **НЕ доверял builder-claimed гейтам — перепроверил по тексту.**
- **Editor-патч:** 9 точечных правок (Claude), не рестарт Pushkin (8 утечек ≤ 15).

## Internal checks (по отчёту независимого verifier)
| Check | Результат | Evidence |
|---|---|---|
| SOURCE_COVERAGE | **13/13 PASS** | R0-R9 + CORRECTED применены (Catsby 12 000+, рынок 590/433, Cove $199, RHRQuality «крупнейший» без «единственный»); REFUTED только в disavow; 8 продуктовых категорий, 37 игроков, 67 SKU, 41 оффер, 38 источников |
| LANGUAGE / CLIENT GUARD (глазами) | **PASS после патча** | Verifier нашёл 8 English-утечек → 9 editor-правок применены: e-commerce, parts-accessories→«запасные части и аксессуары», smart furniture, AR preview→расшифровка, suede/micro suede→микрозамша, Natural Coir→«натуральное кокосовое волокно», Tatami→«татами». Остаток «(micro suede)» — легитимные перевод-скобки |
| ТЕРМИНОЛОГИЯ | PASS | развилк=0 (гипотезы-рамка); «трон»/«кошкин дом» только disavow |
| КУХНЯ | PASS | pipeline/MCP/DR/пути/gate-лексика = 0 |
| ИИ-обороты | PASS | 0 (verifier подтвердил) |
| СЛОВАРЬ | присутствует (>30 KB doc) | + добавлены материалы по утечкам |

## Что разблокировано
HTML-сборка RESEARCH из этого CLIENT_READY source. **НЕ из старого `build_research_html.py`** (INVALID, сломанный fade-up). Свежий shell M2-05/M2-06 (рабочий fade-up + provenance + hub-link + hero full-width).

> Provisional до owner eye-check HTML. Deploy/hub — после accept, через Codex.

---

# HISTORY / NOT CURRENT (superseded — аудит-след)

> Патч-лог ниже описывает прежние состояния. Hash-ссылки `ca9c48be` / `cb19b9cc` — исторические; current = `3b3b2b1a8b770237` (см. шапку).

## Language patch 2 (owner-caught 2026-06-05) — русская процессная кухня
Owner нашёл внутренний рабочий язык в КЛИЕНТСКОМ source (прежний CLIENT_LANGUAGE ловил английский/MCP, но не русскую кухню процесса). Убрано из MD: «исследовательский прогон/прогоны», «системы искусственного интеллекта», «лог сверки», «прямой/статический заход», «в этом заходе», «предыдущего захода», «исходные/старые материалы», «что не извлеклось», «выгрузка Avito недоступна». 3 методологических абзаца переписаны по тексту owner. Греп кухни в MD = 0 (легит «искусственный мех» / «точечно» сохранены). Прежний VERIFIED_PASS (по hash ca9c48be17e53c5c) СНЯТ → новый source hash **cb19b9cc1590fc17**.
**CLIENT_LANGUAGE расширен:** проверяет не только английский/MCP, но и русскую кухню процесса (прогон|заход|извлек|лог сверки|искусственн интеллект|предыдущ|исходн).

## Language patch 3 (Independent Verifier-pass 2026-06-06, owner-decided)
Реверификация штампа Claude≠Builder вскрыла два остатка, которые прежний CLIENT_LANGUAGE_PASS пропустил (CLAIMED ≠ VERIFIED):
1. **HTML-десинк §02 «О документе»:** section-sub обещал удалённые Patch 3 подразделы «методология сбора, исправленные формулировки» → выровнен по фактическим подразделам MD (Контекст / Что уже закрыто / Главные вопросы). HTML-only.
2. **«выгрузка Avito недоступна в этом исследовании» + термин «выгрузка»** (8 мест MD + 4 HTML) → owner-решение «переформулировать»: «детальный разбор предложений на Avito», процессные формулировки смягчены. Источник остаётся MD; HTML синхронизирован поле-в-поле.
Греп `выгрузк` = 0 в MD и HTML; сильная кухня = 0. Новый source hash **`3b3b2b1a8b770237`** (прежний `cb19b9cc1590fc17` СНЯТ). Provisional до owner eye-check; deploy/hub НЕ делались.
