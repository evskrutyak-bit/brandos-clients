# TASK-BRIEF — M2-03 Product Salvage Audit

Дата: 2026-05-24  
Проект: Alien Cat / M2-03 Product  
Исполнитель: Claude / методологический клон  
Роль Codex: task brief, файловый контроль, scope checks, не писать salvage audit вместо исполнителя  

---

## Цель

Провести **Salvage Audit** существующих материалов Alien Cat M2-03 Product до любого нового Deep Research.

Новая методология для M2-03/M2-04/M2-05: **salvage-first, not new-DR-first**.

Новый Deep Research не запускать автоматически.

Текущий MCP-контур для новых проверок: **Firecrawl + Exa**.

Важно: старые `_fact-check/*MCP*` файлы были сделаны в Tavily-контуре и считаются historical baseline. Новые recheck / targeted MCP делать через Firecrawl + Exa. Apify, Wordstat и Tavily не считать доступными по умолчанию; если без них вопрос не закрывается, фиксировать это как gap/tool-wishlist.

---

## Главный принцип

Старый материал может быть evidence layer.  
Старый материал **не может напрямую стать новым client-facing MD/HTML**.

Правильная цепочка:

```text
старые DR / synthesis / fact-check
  -> salvage audit
  -> accepted source packet
  -> новый client-facing слой по runbook
```

Запрещённая цепочка:

```text
старый HTML / старый synthesis
  -> чуть поправили
  -> опубликовали
```

---

## Контекст

По Alien Cat уже есть старые research-слои:

- продукт;
- ЦА;
- конкуренты;
- синтезы;
- HTML;
- fact-check / MCP материалы.

Новая методология не требует всё выбросить. Она требует сначала понять, что из старого можно использовать как evidence-base, а что нужно перепроверить.

---

## Можно менять

Создать новый audit-файл:

`M2-исследования/M2-03-Продукт/M2-03-SALVAGE-AUDIT.md`

Можно читать legacy-файлы:

- `M2-исследования/продукт/`
- `M2-исследования/_fact-check/M2-03-PRODUCT-*`
- `M2-исследования/_fact-check/evaluations/M2-03-PRODUCT-evaluator.md`
- `M2-исследования/_fact-check/html/M2-03-PRODUCT-fact-check.html`
- `site/M2/M2-03-PRODUKT*.html`
- archive copies if needed.

---

## Нельзя менять

- Не запускать новый DR.
- Не создавать `SYNTHESIS.md`.
- Не создавать client-md.
- Не создавать HTML-BRIEF.
- Не создавать HTML.
- Не публиковать hub.
- Не переписывать архивы.
- Не править старый HTML.
- Не считать старый synthesis клиентским документом.

---

## Что сделать

### Step 1 — Inventory

Собрать список всех старых файлов M2-03:

- DR;
- synthesis;
- HTML;
- fact-check;
- MCP results;
- suspicious facts;
- evaluator;
- archive notes;
- old hub/site files.

Для каждого файла указать:

- путь;
- тип;
- размер/строки;
- примерную дату/поколение;
- роль в старом pipeline;
- заметки по риску.

### Step 2 — Source Status Matrix

Каждому файлу дать один из статусов:

| Status | Meaning |
|---|---|
| `ACCEPTED_SOURCE` | можно использовать как основу |
| `LEGACY_SOURCE` | можно читать, но нельзя брать без проверки |
| `REFERENCE_ONLY` | только контекст |
| `REJECTED_ARCHIVE` | не использовать |
| `NEEDS_TARGETED_MCP` | использовать только после проверки |

Матрица должна объяснять, почему статус выбран.

### Step 3 — Gap Matrix

Проверить по новой методологии:

- правильный ли scope;
- есть ли source hierarchy;
- есть ли rejected materials;
- есть ли evidence labels;
- есть ли непроверенные claims;
- где нужны URL / MCP / fact-check;
- что устарело;
- что нельзя тащить в client-facing.

Gap matrix должна иметь формат:

| Requirement | Old material coverage | Gap | Risk | Needed action |
|---|---|---|---|---|

### Step 4 — Decision

После аудита выбрать один из трёх путей:

1. **Salvage**  
   80% материала годится. Новый DR не нужен. Пересобираем по новой методологии.

2. **Targeted MCP / mini-DR**  
   Материал в целом годится, но есть дыры. Делаем точечную проверку, не полный новый DR.

3. **New DR**  
   Только если:
   - старый scope неверный;
   - sources непроверяемы;
   - критические вопросы не покрыты;
   - fact-check показывает ненадёжность;
   - задача клиента изменилась.

Default decision: **salvage-first**.

---

## После Salvage Audit

Дальше всё равно идём по новому runbook:

`/Users/admin/studio/methodology/m2-deep-research/01-working/m2-text-then-visual-runbook.md`

Цепочка:

```text
accepted source packet
  -> brief / terminal brief
  -> client-facing MD
  -> editorial pass
  -> CLIENT_READY
  -> HTML-BRIEF
  -> HTML build
  -> visual review
  -> HTML_READY 4-pass
  -> DEPLOY_QC
  -> publish
```

Но это **после** salvage audit и отдельного решения. Не начинать client-facing слой сейчас.

---

## Acceptance Criteria

`M2-03-SALVAGE-AUDIT.md` принят, если:

- есть полный inventory старых M2-03 файлов;
- есть Source Status Matrix со статусом каждого файла;
- есть Gap Matrix по новой методологии;
- есть явное решение: salvage / targeted MCP / new DR;
- решение new DR, если выбрано, обосновано одним из разрешённых критериев;
- client-facing layers не созданы;
- старые HTML / synthesis не правились;
- next safe step указан.

---

## Короткое сообщение исполнителю

Клод, твоя задача — не писать новый M2-03 и не запускать Deep Research. Сначала сделай Salvage Audit старой evidence-базы M2-03. Старые материалы могут стать evidence layer, но не client-facing документом. Итоговый файл: `M2-исследования/M2-03-Продукт/M2-03-SALVAGE-AUDIT.md`. После аудита дай решение: salvage / targeted MCP / new DR. Default — salvage-first. Любой client-facing слой сейчас заблокирован.
