# M2-03 CALIBRATION LOG — Claude × Gemini paired DR

Дата: 2026-05-24
Модуль: M2-03 Продукт
Статус: Step 3 calibration, transfer-test candidate v1.2
Контур MCP: Firecrawl + Exa (Apify / Wordstat / Tavily live — недоступны)

---

## 0. Источники

| ID | Файл | Провайдер | Жанр | Объём |
|---|---|---|---|---|
| C | `DR-SOURCES/raw-claude-deepresearch-product-2026-05-24.md` | Claude Deep Research (Compass) | structured tables, R1-R9 явно | 90 KB, 815 строк |
| G | `DR-SOURCES/raw-gemini-product-2026-05-24.docx` + `raw-gemini-product-extracted-2026-05-24.txt` | Gemini Deep Research | narrative + таблицы, секции 1-10 (маппится в R0-R9) | 68 KB / 106 KB extracted |

### 0.1. Transfer-test finding (canon deviation)

- Canon candidate v1.2 предписывал GPT + Gemini как обязательную paired-пару.
- Фактически получена пара **Claude + Gemini**.
- Решение: продолжаем без GPT-прогона. Кросс-валидация работает, потому что Claude и Gemini — две независимые модели с разными корпусами обучения и разным стилем (Claude — структурированные таблицы, Gemini — narrative + явная проверка suspicious claims).
- GPT-прогон запускается, **только если ниже в §3 найдутся неразводимые расхождения**.
- Finding для будущего canon-update: расширить определение paired DR до «любые 2 из {GPT, Claude, Gemini}» с явной фиксацией провайдеров в ledger.

---

## 1. Покрытие требований Profile E

| Раздел | Минимум v1.2 | Claude (C) | Gemini (G) | Объединение | Статус |
|---|---|---|---|---|---|
| R1: категории | 6+ | 8 категорий | 7 категорий | 8 уникальных | ✅ |
| R2: игроков | 20+ | 23 | ~20-25 | 30+ уникальных | ✅ |
| R3: SKU | 40+ | 35 (24 РФ + 11 зарубеж) | ~45 (включая зарубеж) | **50+ уникальных** | ✅ при объединении; по C отдельно — gap-edge |
| R4: кейсы архитектуры | 15+ | 15 нумерованных кейсов | прозой ~10 кейсов | 15+ | ✅ (через C) |
| R5: офферов | 25+ | 31 | ~25 | 40+ уникальных | ✅ |
| R6: новинок 12 мес | 10+ | 18 явных + 7 слабых | ~10 + 3 слабых | 20+ | ✅ |
| R7: упаковка/TOV | 15+ | 15+ примеров + 3 ошибки | 15 примеров + 3 ошибки | 15+ | ✅ |
| R8: источников | 25+ | 28 (с URL, без даты публикации) | ~24 видимых в extracted (URL потерян в DOCX→TXT) | 30+ | ⚠️ форма не идеальна |
| R9: пробелов + 8 гипотез | 5+ / 8 | 5 пробелов + 8 вердиктов | 5 пробелов + 8 вердиктов | объединить вердикты | ✅ |
| R0.12: suspicious watchlist | проверить 15 claims | проверены 6 КРИТИЧНО + новые | **явный блок «Проверка Suspicious Claims»** | покрыто | ✅ |

**Главный gap по форме:** ни Claude, ни Gemini не дают «дата публикации источника» + «дата доступа» в виде двух отдельных полей. У Claude в SKU-таблицах есть колонка «Дата» (24.05.26), но это дата доступа, не публикации источника. У Gemini в R8 даты публикации местами есть (`2025-12-29`, `2026-02-05`, `2014-02-06`), но URL потерян при DOCX→TXT-конвертации.

**Решение:** при сборке internal RESEARCH MD добавить колонку «Дата доступа» = 24.05.2026 во все строки SKU/офферов, а «Дата публикации» восстанавливать через Firecrawl-pass где это критично (отраслевые отчёты, статистика).

---

## 2. Совпадения (high confidence — переносим в RESEARCH без дополнительной проверки)

### 2.1. Структура категории и логика покупки
- Обе DR — 7-8 категорий с одинаковыми ролями: напольные комплексы (флагман), настенные системы (вход/модуль), когтеточки (вход/повтор), тумбы под лоток (новая категория), лежанки/домики (сезон), зоны кормления (cross-sell), сменные элементы (повтор), сервис/ремонт.
- Обе DR — деление игроков на типы: модульно-сменные, флагман-строители, ремонтно-сменные, гибридные, вход-строители, кастомные.
- Обе DR — массовый сегмент насыщен по цене, премиум растёт через материалы и multi-functionality, ultra-premium — через дизайн и философию.

### 2.2. Подтверждение 8 гипотез R0.11
| Гипотеза | C | G | Сводный вердикт |
|---|---|---|---|
| 1. S/M/L как роли линейки | ✅ | ⚠️ частично (модульность ломает строгую размерную привязку) | подтверждается с оговоркой: размер — не sole определитель роли, нужна явная артикуляция |
| 2. Сменные элементы как повтор | ✅ (20-30% рынка) | ✅ (РФ слабее мира) | подтверждается; **главная продуктовая пустота в РФ** |
| 3. Усиление для крупных пород как отдельная рамка | ✅ | ✅ | подтверждается, выделенные SKU и линейки |
| 4. Furniture-first как стандарт | ✅ в премиум | ✅ в премиум, эконом всё ещё pet-product | подтверждается в верхнем ярусе |
| 5. Натуральные материалы как доказательность цены | ✅ | ✅ | подтверждается, материалы — главный price-proof |
| 6. Тумба под лоток / настенные / компактные — отдельные направления | ✅ | ✅ | подтверждается, западные mainstream опережают РФ |
| 7. Упаковка/сервис как часть продукта | ✅ | ✅ | подтверждается, премиум дифференцируется именно через сервис |
| 8. Avito vs собственный сайт — разная карточная логика | ⚠️ данных недостаточно | не покрыта | **gap для MCP/наблюдения**, не закрыто DR |

### 2.3. Закрытые suspicious claims из F2 baseline (2026-04-27 Tavily)
| Claim | F2 vердикт | C | G | Финал 2026-05-24 |
|---|---|---|---|---|
| Tuft+Paw Cove $199 (не $599) | ❌ опровергнут $599 | $199 ✓ | $199 ✓ | $199 закреплено |
| Catsby Vine рассрочка 10 мес | ⚠️ скорректирован | ✓ 2 074₽×10 | ✓ беспроцентная на 10 мес | закреплено |
| RHRQuality 1 год гарантии, «единственный в Европе» опровергнут | ❌ | «Europe's largest producer», 1 год | «не является технически доказуемым фактом», 1 год | закреплено: 1 год + крупнейший в Европе (без «единственный») |
| Refined Feline Lotus 175см / 4 платформы / $400 | ⚠️ скорректирован | $440, 175см | 69" (=175см), ~44 000₽ ($440) | закреплено $440 / 175см; число отзывов не использовать |
| 48% потребителей хотят modular furniture | ✅ FMI | ✓ через Catastrophic Creations со ссылкой на FMI | ✓ цитируется как «около 48%» | закреплено со ссылкой на FMI 2024-2025 |
| Рынок зоотоваров РФ 433 млрд + 31% | ⚠️ цифра 433 млрд ✓ за 2023, +31% не подтверждён | не упоминается в основном тексте | **обновлено: 590 млрд за 2025, Tadviser 2026-02-05** | **новая база: 590 млрд за 2025 (Tadviser)**; 433 млрд (2023, Зооинформ) как историческая точка |
| Сезонность +59% весной | F2 не проверял (СРЕДНЕ) | упомянуто «осенне-зимний пик 60-90%» | **обновлено: +92% за 2 года, +61.7% за 6 мес, пик ноябрь (Salehoo)** | **новая база: пик в ноябре, не весной**; F2 +59% весной — не подтверждён |
| LucyBalu × Choupette | СРЕДНЕ | ✓ €159 коллаб подтверждена | ✓ коллаб подтверждена | закреплено |
| IKEA Lurvig | НИЗКО | — | **снят с производства, заменён на Utsaedd** | закреплено: discontinued |
| Murr and Woof Tube/Lotto евро-цены | СРЕДНЕ | не упоминается | не упоминается | gap — Firecrawl Murr and Woof |
| Hicat UK потолочные столбы | СРЕДНЕ | ✓ £600-1 200 Polecat, bespoke 2-4 нед | ✓ кастомный пошив под высоту потолка | закреплено |
| Kattens No.1 Дания модульная | СРЕДНЕ | ✓ Classic/No Limit, с 1991 | ✓ патентованная система без упора в потолок | закреплено |
| Catit Vesper модульная настенная | СРЕДНЕ | ✓ Vesper Base $120-150, MDF башня | ✓ Vesper Lite $80, Vesper Cottage | закреплено: Vesper — не настенная модульная (как было в L4), а MDF-башня; F1 был прав в подозрении |
| Catastrophic Creations только настенные | СРЕДНЕ | ✓ The Juggernaut $645 wall playground | ✓ trail/condo, модульная стена | закреплено |
| Cat Brand Алтай экспорт 10+ стран | НИЗКО | не упоминается | не упоминается | gap — Firecrawl/Exa, оставить как unverified |

---

## 3. Конфликты и расхождения

### 3.1. Разводимые (без нового DR)

| # | Расхождение | C | G | Разрешение |
|---|---|---|---|---|
| 3.1.1 | Catsby TREE цены/высоты | TREE 4 уровня 280-295см = 32 270₽; «флагман 35 910₽» | TREE 240-250см = 37 220₽; TREE 260-270см = 29 746₽ | Разные конфигурации одной модели (WW/NW, разная высота). В RESEARCH-MD дать полную матрицу через Firecrawl catsby-family.ru |
| 3.1.2 | Catsby «1000 комбинаций» | ✓ как факт | ✓ как факт | **новый suspicious claim** — оба DR могут опираться на маркетинговое утверждение бренда. Firecrawl-pass для подтверждения формулировки на сайте |
| 3.1.3 | КотаМ «1000 комбинаций» | ✓ как факт | не упоминается | **новый suspicious claim** — либо реальная фигура, либо копирующая Catsby. Firecrawl domik-koshki.ru |
| 3.1.4 | Размер игроков | 23 (детально) | ~20-25 (детально) | объединение → 30+ уникальных. Игроки только у Claude: KotoMoto, KBSPETS, Bon Cat, Mau, Pet БМФ, Котосчастье, Murr and Woof, Котомастер, ЛапаМоя, CatioCat. Игроки только у Gemini: PurrNook, Pryde Pets, Armarkat, TOWALKER, Miza/Peelorange, Dhanus Decor, miioo.pet |
| 3.1.5 | Беговые колёса как тренд | ✓ Hunnkatt Ekorn MAX 27 660₽, Мы Бобры «Забава» 25 000₽ | не упоминается | **gap у Gemini**. Firecrawl-pass mybobr.ru + hunnkatt.com для верификации |
| 3.1.6 | Сезонность | «осенне-зимний пик 60-90%» (без источника) | +92% за 2 года + +61.7% за 6 мес, пик ноябрь (Salehoo) | Gemini-цифра идёт со ссылкой на Salehoo — приоритет. Закрепляем «пик в ноябре», числа верифицируем через Firecrawl salehoo.com/trends/cat-beds |
| 3.1.7 | PurrNook smart furniture | не упоминается | Jellyfish Cat Tree $289, LED + датчики движения | **gap у Claude**. Реальный продукт по Gemini, smart category. Firecrawl-pass purrnook.com |
| 3.1.8 | Kattens No.1 «No Limit Mount patent» | упомянуто как «patent pending» | «патентованная система без упора в потолок» | Совпадает в сути. Firecrawl kattensno1.dk для конкретики патента |
| 3.1.9 | Рынок 590 vs 433 млрд | не упоминается | 590 млрд за 2025 (Tadviser 2026-02-05) | Firecrawl tadviser.ru для подтверждения. Закрепляем 590 млрд как актуальную точку 2025, 433 млрд как историческую 2023 |

### 3.2. Неразводимые (требующие GPT-прогона или внешнего арбитража)

**Нет.** Все расхождения относятся к категории «один источник имеет, другой нет» или «разные конфигурации одного товара». Системных противоречий по фактам, ценам, ролям или гипотезам между Claude и Gemini не обнаружено.

**Вывод:** третий GPT-прогон не нужен.

---

## 4. Новые suspicious claims (за пределами F1 watchlist 2026-04-29)

Все эти claims нужно проверить через Firecrawl + Exa до MD_ACCEPTED. F1 watchlist расширяется.

| ID | Claim | Источник | Приоритет | Где проверять |
|---|---|---|---|---|
| E-XSV-16 | Catsby Family «до 1000 комбинаций» | C + G | СРЕДНЕ | Firecrawl catsby-family.ru |
| E-XSV-17 | КотаМ «до 1000 различных комбинаций» | C | СРЕДНЕ | Firecrawl domik-koshki.ru |
| E-XSV-18 | «Мы Бобры» гарантия 5 лет на элементы | C | КРИТИЧНО | Firecrawl mybobr.ru — это уникальный маркер, если ложь — пересмотр кейса R4 |
| E-XSV-19 | Беговое колесо «Забава» 25 000₽ — реальный продукт | C | СРЕДНЕ | Firecrawl mybobr.ru/products |
| E-XSV-20 | Hunnkatt Ekorn MAX беговое колесо 27 660₽ | C | СРЕДНЕ | Firecrawl hunnkatt.com |
| E-XSV-21 | CatioCat авторские деревья 50 000-120 000₽ (40-60кг, листва RealTouch, эпоксидная смола) | C | СРЕДНЕ | Firecrawl catiocat.ru + Avito-карточки |
| E-XSV-22 | PurrNook Jellyfish Cat Tree $289, LED + motion sensors | G | СРЕДНЕ | Firecrawl purrnook.com |
| E-XSV-23 | Pryde Pets полки из recycled bottles, нагрузка 26 lbs (11.8 кг) | G | НИЗКО | Firecrawl prydepets.com |
| E-XSV-24 | Pet БМФ столбы для замены «от 199₽» | C | СРЕДНЕ | Firecrawl petbmf.ru или аналог |
| E-XSV-25 | Catastrophic Creations «tested to 120 lbs (54кг)», Patented hidden bracket, Jackson Galaxy endorsement | C | НИЗКО | Firecrawl catastrophicreations.com |
| E-XSV-26 | Refined Feline Metropolitan Cat Condo «extra-large platforms 13"×18.5"» | C | НИЗКО | Firecrawl therefinedfeline.com |
| E-XSV-27 | RINN NEKO €7 700, 22 шт/год лимит | C | НИЗКО | Firecrawl rinn.co.jp/neko |
| E-XSV-28 | Рынок зоотоваров РФ 590 млрд за 2025 (Tadviser 2026-02-05) | G | КРИТИЧНО | Firecrawl tadviser.ru — это новая base-цифра, нужна точная атрибуция |
| E-XSV-29 | Сезонность +92% за 2 года, +61.7% за 6 мес, пик в ноябре (Salehoo) | G | КРИТИЧНО | Firecrawl salehoo.com/trends/cat-beds |
| E-XSV-30 | FMI report 2024-2025: 48% modular, 73% sustainable (Asia), 76% adaptable to home interior, 62% multi-functionality, 72% Scandinavian (NA), 68% (EU) | C | КРИТИЧНО | Firecrawl futuremarketinsights.com — все статистики идут из одного отчёта, нужна корректная атрибуция |
| E-XSV-31 | IKEA Lurvig снят с производства, заменён на Utsaedd | G | НИЗКО | подтверждение есть в Reddit thread, Firecrawl IKEA Russia опционально |
| E-XSV-32 | LucyBalu отзывы о «тонких просвечивающих наклейках на винтах» | G | НИЗКО | Exa search UGC LucyBalu reviews — это качественный сигнал для R7 ошибок |

---

## 5. Что закрыто DR-парой, что осталось

### 5.1. Закрыто (можно строить RESEARCH-MD без блокеров)

- R1: карта 8 категорий с ролями, ценами, частотой, зрелостью
- R2: 30+ уникальных игроков с типологией продуктовой логики (после объединения C и G)
- R3: 50+ уникальных SKU (после объединения C и G и дедупликации)
- R4: 15 структурированных кейсов архитектуры ассортимента (Claude)
- R5: 40+ уникальных офферов с цитатами и URL (объединение)
- R6: 20+ новинок и слабых сигналов (объединение)
- R7: упаковка/нейминг/визуальный код/TOV с 4 паттернами + 3 ошибки
- R8: 30+ уникальных источников
- R9: 5+ пробелов + 8 проверенных гипотез
- R0.12: F2 baseline закрыт, gap-сдвиги 2 значимых (рынок 590 млрд, сезонность ноябрь) учтены

### 5.2. Не закрыто (требует Targeted MCP до MD_ACCEPTED)

**Критичный блок (без него не MD_ACCEPTED):**

- E-XSV-18 «Мы Бобры» 5-летняя гарантия — это load-bearing аргумент для R4 кейса №2 и R5 оффера. Если неверно — кейс пересобирается.
- E-XSV-28 Tadviser 590 млрд за 2025 — это baseline для рыночной рамки, переходит в M4/M5/M6.
- E-XSV-29 Salehoo сезонность — это load-bearing аргумент для R6 и planning для Alien Cat.
- E-XSV-30 FMI 4-5 статистик — это load-bearing для R6/R7 (тренды).

**Средний блок (можно вынести в R9 как «подтверждено DR без независимой проверки», но желательно проверить):**

- E-XSV-16, E-XSV-17 — «1000 комбинаций» Catsby и КотаМ.
- E-XSV-19, E-XSV-20 — беговые колёса.
- E-XSV-21 — CatioCat авторские деревья.
- E-XSV-22 — PurrNook.
- E-XSV-24 — Pet БМФ цены.

**Низкий блок (можно оставить как DR-confirmed, перепроверять только если используются как load-bearing в SYNTHESIS):**

- E-XSV-23, E-XSV-25, E-XSV-26, E-XSV-27, E-XSV-31, E-XSV-32.

### 5.3. Структурно не закрывается DR (gap-wishlist для не-доступных MCP)

- Apify mass scraping Ozon/WB/Я.Маркет — полный массив SKU и UGC-отзывы.
- Wordstat частотность продуктовых запросов («тумба под лоток», «мебель для мейн-куна», «настенный комплекс кошки»).
- Avito-выгрузка по продуктовым запросам для оценки конкуренции в канале Alien Cat.
- Долгосрочный мониторинг цен/скидок (Firecrawl покрывает разовый snapshot, не динамику).

Эти пункты идут в R9 internal RESEARCH как **explicit data gaps + tool-wishlist**, не как executable MCP-команды.

---

## 6. Targeted MCP Instruction (Firecrawl + Exa only)

### 6.1. Executable checks (Firecrawl)

Каждая команда возвращает evidence для одного-двух suspicious claims. Источник правды — открытая страница на дату 24.05.2026.

| # | Target URL | Что искать | Закрывает |
|---|---|---|---|
| F-01 | https://catsby-family.ru/ | формулировка «до 1000 комбинаций»; полная матрица TREE/VINE/STAND/WALL с ценами и высотами; рассрочка 10 мес — точные условия | E-XSV-16, 3.1.1, продуктовая матрица расширение |
| F-02 | https://domik-koshki.ru/ | формулировка «до 1000 различных комбинаций»; цены модулей; «замена изношенных когтеточек или деталей» | E-XSV-17 |
| F-03 | https://mybobr.ru/ | «гарантия 5 лет» на странице товара / FAQ; беговое колесо «Забава» 25 000₽ — реальный SKU; «Карта мира» 23 600₽ | E-XSV-18 (КРИТИЧНО), E-XSV-19 |
| F-04 | https://hunnkatt.com/ | Ekorn MAX беговое колесо 27 660₽; Svart 23 380₽; «скрытое крепление» | E-XSV-20 |
| F-05 | https://catiocat.ru/ + Avito | цены 50 000-120 000₽; материалы (стволы, RealTouch, эпоксидная смола); вес 40-60кг | E-XSV-21 |
| F-06 | https://www.tadviser.ru/index.php/Статья:Домашние_животные_в_России | цифра 590 млрд за 2025, год публикации, методология (Зооинформ или другая) | E-XSV-28 (КРИТИЧНО) |
| F-07 | https://www.salehoo.com/trends/cat-beds | цифры +92%, +61.7%, пик в ноябре; источник данных Salehoo (Google Trends, internal data, или 3rd party) | E-XSV-29 (КРИТИЧНО) |
| F-08 | https://www.futuremarketinsights.com/reports/modern-cat-furniture-market | список статистик отчёта: 48% modular, 73% sustainable Asia, 76% adaptable, 62% multi-functionality, 72% Scandi NA, 68% EU; год отчёта; страна выборки | E-XSV-30 (КРИТИЧНО) |
| F-09 | https://www.therefinedfeline.com/parts-accessories/ | реальная страница «sменных частей»; список + цены | подкрепление R5/R6 для сменных элементов |
| F-10 | https://en.murrandwoof.com/ | Tube / Lotto — реальные продукты; ценовая логика B2B; евро-цены | E-XSV-15 из F1, gap C+G не покрыли |

### 6.2. Discovery (Exa)

Каждый Exa-поиск — для расширения R2/R3 за счёт игроков, которые не появились в обоих DR.

| # | Запрос | Цель |
|---|---|---|
| E-01 | `PurrNook Jellyfish Cat Tree smart furniture LED motion sensor` | подтверждение PurrNook (E-XSV-22) + аналоги в smart furniture |
| E-02 | `Pryde Pets recycled bottles cat wall climber 26 lbs` | подтверждение Pryde Pets (E-XSV-23) + eco-recycled players |
| E-03 | `Kattens No.1 patent No Limit Mount wall attachment` | детали патента (3.1.8) |
| E-04 | `российский производитель когтеточек беговое колесо 2025 2026` | поиск других РФ-игроков с беговыми колёсами помимо «Мы Бобры» и Hunnkatt |
| E-05 | `российский премиум мебель для кошек авторская Avito` | поиск других CatioCat-аналогов в РФ-сегменте 50k+ |
| E-06 | `cat furniture trends 2025 2026 design report Russia` | свежие отраслевые обзоры за май 2026 (Claude DR имеет cutoff на этом дате) |

### 6.3. Wishlist (не executable, фиксируется как gap)

- **Apify** — полный массив SKU Ozon/WB/Я.Маркет, UGC-отзывы, цены конкурентов на маркетплейсах, Avito-выгрузка.
- **Wordstat** — частотность продуктовых запросов в Яндексе.
- **Live Tavily** — повторный prompt-based fact-check для отдельных claims (доступен только F2 historical snapshot).
- **WebFetch с авторизацией** — динамические корзины / pop-up рассрочка / закрытые B2B-страницы.

Эти инструменты в текущем контуре не доступны. Записывать их в R9 internal RESEARCH как «gaps that require tools currently not in the stack», не как next executable step.

---

## 7. Decision

### 7.1. Решение для перехода к Step 5 (RESEARCH-BRIEF)

**CONDITIONAL GO.**

Условия:

1. ✅ Paired DR валидирован (Claude × Gemini), системных противоречий нет → GPT-прогон НЕ запускать.
2. ⚠️ Targeted MCP (Firecrawl + Exa) обязателен до RESEARCH MD_ACCEPTED, но **не блокирует** сборку RESEARCH-BRIEF и internal RESEARCH MD. MCP закрывает: 4 КРИТИЧНО suspicious (E-XSV-18, E-XSV-28, E-XSV-29, E-XSV-30) + 5 СРЕДНЕ (E-XSV-16, 17, 19, 20, 21, 22, 24) + 1 carry-over из F1 (E-XSV-15 Cat Brand экспорт).
3. ✅ R8 рестракт: при сборке internal RESEARCH MD добавить «Дата доступа» = 24.05.2026 ко всем строкам SKU/офферов; «Дата публикации источника» — куда возможно (Firecrawl должен дать для F-06/F-07/F-08).
4. ✅ Stop-gate (SYNTHESIS, client-md, HTML-BRIEF, HTML, hub publish) остаётся в силе.

### 7.2. NO GO для Step 4 (MCP execution) на этой итерации

Дима явно отделил MCP-execution от calibration: «Step 4 пока НЕ выполнять. В calibration только сформировать Targeted MCP Instruction под Firecrawl + Exa». §6 выше — это спецификация без запуска.

Запуск §6 — отдельной командой Димы, после ревью этой калибровки.

### 7.3. Sequence до MD_ACCEPTED

1. **Сейчас** — этот calibration log на ревью.
2. **Следующий шаг по команде** — Firecrawl + Exa-pass по §6.1 + §6.2.
3. **После MCP** — сборка RESEARCH-BRIEF (decision brief, не механическая выжимка; 25-50 KB).
4. **После RESEARCH-BRIEF** — internal RESEARCH MD на базе Claude + Gemini + MCP, по структуре R1-R9 candidate v1.2.
5. **Stage 4 LANGUAGE_TECH_PASS** — проверка на запрещённые рамки v1.2 («премиум как self-claim», «Кошкин Дом», «трон», «рассрочка как обещание Alien Cat»).
6. **Stage 4.8 READER_SANITY_PASS** — критическая читаемость для смысла, не для языка.
7. **MD_ACCEPTED** — финальная отметка перед переходом на text-to-visual runbook.

### 7.4. Что закрывает этот calibration log в ledger

- Step 1 (DR-PROMPT): ✓ (закрыт 2026-05-23)
- Step 2 (paired DR intake + normalization): ✓ (закрыт 2026-05-24 Codex-ом; finding по канону Claude вместо GPT записан)
- **Step 3 (calibration log): ✓ — этот документ**
- Step 4 (MCP execution): blocked до команды Димы
- Step 5.1 (RESEARCH-BRIEF): blocked до Step 4
- Step 5.2 (internal RESEARCH MD): blocked до Step 5.1
- Stage 4 / 4.8 / MD_ACCEPTED: blocked
- SYNTHESIS / client-md / HTML-BRIEF / HTML / publish: hard-blocked client-facing stop-gate

---

## 8. Notes для Димы

- Расхождений между Claude и Gemini, требующих GPT, **нет**. Пара валидна.
- Главный методологический выигрыш Gemini над Claude: **обновлённые baseline-цифры** (590 млрд рынка, +92%/+61.7% сезонность, IKEA Lurvig discontinued) и **явный блок R0.12 проверки**. Эти данные нужно перепроверить через Firecrawl до того, как они уйдут в SYNTHESIS как load-bearing аргументы.
- Главный методологический выигрыш Claude над Gemini: **полная R3-матрица 35 SKU с колонкой «Дата»** и **15 структурированных R4-кейсов архитектуры**. Это рабочая основа для internal RESEARCH MD.
- 4 КРИТИЧНО suspicious claims нужно закрыть через Firecrawl до MD_ACCEPTED. 7 СРЕДНЕ — желательно. 6 НИЗКО — можно оставить как DR-confirmed.
- Apify / Wordstat / Tavily-live / WebFetch-auth недоступны → они gap, не план.

---

*Calibration by Claude · 2026-05-24 · transfer-test candidate v1.2 · paired DR: Claude × Gemini*
