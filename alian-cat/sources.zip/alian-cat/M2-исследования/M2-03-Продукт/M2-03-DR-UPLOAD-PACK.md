# M2-03 DR Upload Pack — GPT / Gemini / Claude Deep Research

Дата: 2026-05-23  
Назначение: папка для запуска Deep Research по M2-03 Product.

## Как использовать

Одинаковый пакет используется для:

- ChatGPT Deep Research;
- Gemini Deep Research;
- Claude Deep Research, если нужен третий независимый прогон.

Обязательная paired-пара для канона: **GPT + Gemini**. Claude Deep Research — опциональный third opinion, он не заменяет GPT/Gemini.

## Что делать в каждом чате

1. Открыть новый Deep Research чат.
2. Загрузить все файлы из папки `02-upload-files/`.
3. Вставить текст из `01-M2-03-DR-PROMPT-RUNTIME.md`.
4. Запустить исследование без дополнительных подсказок.
5. Сохранить результат в Markdown.

## Как назвать результаты

После завершения положить результаты в:

`M2-исследования/M2-03-Продукт/DR-SOURCES/`

Имена файлов:

- GPT: `raw-gpt-2026-05-23.md`
- Gemini: `raw-gemini-2026-05-23.md`
- Claude, если запускался: `raw-claude-2026-05-23.md`

## Что не загружать

Не загружать старый legacy product-layer:

- `M2-исследования/продукт/AlianCat_Product_Synthesis.md`
- `M2-исследования/продукт/AlianCat_Product_Synthesis.html`
- `M2-исследования/продукт/DR продукn AlianCat.md`
- `M2-исследования/продукт/DR_продукт AlianCat.html`
- `site/M2/M2-03-PRODUKT*.html`

Они могут увести модель в старый pipeline: «продуктовая стратегия» вместо нового Profile E research.

## Файлы upload pack

| Файл в pack | Источник |
|---|---|
| `01-brand-profile.md` | `brand/profile.md` |
| `02-brand-offer-core.md` | `brand/offer-core.md` |
| `03-brand-audience.md` | `brand/audience.md` |
| `04-brand-selling-map.md` | `brand/selling-map.md` |
| `05-brand-voice-style.md` | `brand/voice-style.md` |
| `06-brand-personal-dna.md` | `brand/personal-dna.md` |
| `07-brand-style-guide.md` | `brand/style-guide.md` |
| `08-learning-corrections.md` | `learning/corrections.md` |
| `09-M2-01-RF-FINAL-internal.md` | `M2-исследования/DR рынки/Рынок рф/M2-01-FINAL.md` |
| `10-M2-01-RF-FINAL-client.md` | `M2-исследования/DR рынки/Рынок рф/M2-01-FINAL-client.md` |
| `11-M2-02-WORLD-RESEARCH.md` | `M2-исследования/M2-02-Рынок-мир/M2-02-RESEARCH.md` |
| `12-M2-02-WORLD-SYNTHESIS.md` | `M2-исследования/M2-02-Рынок-мир/M2-02-SYNTHESIS.md` |
| `13-M2-03-PRODUCT-suspicious-facts.md` | `M2-исследования/_fact-check/M2-03-PRODUCT-suspicious-facts.md` |

