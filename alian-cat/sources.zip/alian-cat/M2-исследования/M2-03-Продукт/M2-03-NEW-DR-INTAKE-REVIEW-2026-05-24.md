# M2-03 Product — new DR intake review

Дата: 2026-05-24  
Роль документа: internal intake для Claude/clone перед salvage audit. Не client-facing.

## Входы

Новые файлы с Desktop upload pack нормализованы в `DR-SOURCES/`:

- `DR-SOURCES/raw-claude-deepresearch-product-2026-05-24.md` — Claude Deep Research, markdown.
- `DR-SOURCES/raw-gemini-product-2026-05-24.docx` — Gemini research, исходный DOCX.
- `DR-SOURCES/raw-gemini-product-extracted-2026-05-24.txt` — Gemini research, извлечённый текст DOCX.

Старые материалы для сравнения:

- `../продукт/DR продукn AlianCat.md`
- `../продукт/AlianCat_Product_Synthesis.md`
- `../_fact-check/M2-03-PRODUCT-suspicious-facts.md`
- `../_fact-check/M2-03-PRODUCT-MCP-RESULTS.md`
- `../_fact-check/evaluations/M2-03-PRODUCT-evaluator.md`

## Короткий вердикт

Полный новый Deep Research сейчас не нужен.

Решение: `targeted MCP / mini fact-check` поверх salvage-first.

Причина: два новых файла хорошо закрывают продуктовый scope, особенно markdown-исследование: карта категорий, каталог игроков, 35 SKU, 31 оффер, новинки, слабые сигналы, gap list и проверка гипотез. Но часть чисел и источников конфликтует со старым MCP/fact-check или требует прямой проверки.

## Current MCP stack

Старый файл `M2-03-PRODUCT-MCP-RESULTS.md` — historical Tavily baseline от апреля 2026. Его можно использовать как guardrail по уже проверенным claims, но не как текущий инструментальный контур.

Текущий MCP-контур для новых проверок:

- Firecrawl — scrape/map/crawl известных страниц, карточек, каталогов, документации брендов, доступных публичных URL.
- Exa — web search/source discovery, поиск первоисточников, альтернативных подтверждений, рыночных отчетов и брендовых страниц.

Apify, Wordstat и Tavily в текущем контуре не считать доступными по умолчанию. Если raw DR предлагает Apify/Wordstat, это фиксируется как gap/tool-wishlist, а не как разрешённый следующий шаг.

## Source-status matrix

| Источник | Предварительный статус | Что можно брать | Ограничение |
|---|---|---|---|
| `raw-claude-deepresearch-product-2026-05-24.md` | `NEEDS_TARGETED_MCP` | Основной кандидат на evidence packet: R1-R9, SKU matrix, offer library, gaps, hypotheses | Не принимать exact prices, market stats, warranty/load claims без spot-check |
| `raw-gemini-product-extracted-2026-05-24.txt` | `LEGACY_SOURCE` / `REFERENCE_ONLY` до проверки | Нарративная рамка, category logic, ассортиментная архитектура, визуальный/TOV блок | Меньше явных URL, больше обобщений; дублирует Claude DR и местами конфликтует по ценам |
| `DR продукn AlianCat.md` | `LEGACY_SOURCE` | Старый широкий продуктовый research, полезен для inventory и сравнения coverage | Есть устаревшие цены/игроки, часть claims уже флагнута |
| `AlianCat_Product_Synthesis.md` | `REFERENCE_ONLY` | Старые гипотезы, вопросы клиенту, логика передачи в следующие блоки | Не client-facing; evaluator нашёл H1/SKU drift, H7 issue, финданные без атрибуции |
| `M2-03-PRODUCT-MCP-RESULTS.md` | `ACCEPTED_SOURCE` для 6 проверенных claims | Guardrail для Catsby, Tuft+Paw, RHRQuality, FMI 48%, РФ market 2023 | Покрывает только 6 critical facts, medium/low claims не закрыты |
| `M2-03-PRODUCT-suspicious-facts.md` | `ACCEPTED_SOURCE` как risk register | Список claims, которые нельзя тащить без проверки | Не является доказательством сам по себе |

## Что в новых файлах полезно

1. Product architecture: S/M/L как роли линейки, а не просто размеры. Это лучше раскрыто в markdown, чем в старом synthesis.
2. Сменные элементы: Catsby, КотаМ, RHRQuality, Catastrophic, Mau/Tuft+Paw как логика LTV и повторной покупки.
3. Furniture-first: натуральные материалы, скрытая фурнитура, интерьерная интеграция, отсутствие дешёвого TOV.
4. Large cats / Maine Coon: отдельная продуктовая рамка, не просто сценарий использования.
5. Новые категории: hidden litter furniture, wall systems, compact SKU, running wheels, smart/weak signals.
6. Offer library: конкретные формулировки по материалам, нагрузке, гарантии, сборке, замене деталей.
7. Gap list: Wordstat, Ozon/WB/Avito scraping, UGC-отзывы, pricing monitoring.

## Конфликты и красные флаги

1. SKU count: markdown заявляет 35 SKU; DOCX местами говорит “более 40 SKU”. Не писать 40+ без пересчёта.
2. Catsby prices conflict: старый MCP скорректировал Vine до примерно 29-32 тыс. ₽ по уровням; новые файлы дают несколько других цен. Нужен прямой spot-check сайта/маркетплейсов.
3. Tuft+Paw: старый MCP уже опроверг `$599` для Cove и подтвердил `$199`. Новые файлы в целом исправляют цену, но URL местами написан как `tufandpaw.com`; нужно использовать `tuftandpaw.com`.
4. RHRQuality: старый MCP опроверг “2 года” и “единственный в Европе”; допустимо только аккуратное “специализация на крупных породах / spare parts”, warranty проверять.
5. FMI 48%: можно использовать только с точной оговоркой “bespoke/evolving cat furniture” и пометкой, что источник платный. Нельзя превращать в “48% владельцев предпочитают вертикальную модульную мебель”.
6. РФ рынок: старый MCP подтвердил 433 млрд ₽ за 2023 и 510 млрд ₽ за 2024. Новый DOCX упоминает 590 млрд ₽ за 2025; это отдельная проверка.
7. Seasonality: старые `+59%` уже были suspicious; новые `+92% / +61.7%` не принимать без источника.
8. LucyBalu / Choupette: claim может быть рабочим, но формулировать осторожно через подтверждённую коллаборацию, не как “вирусность после Лагерфельда” без источника.
9. Catit Vesper: старый risk register флагнул “настенная модульная серия”; новый markdown пишет replacement parts / AR preview. Проверить, не смешаны ли разные продуктовые линии.
10. Kattens No.1, Hicat, PurrNook, Pryde Pets, Dhanus Decor, Miza, TOWALKER: использовать только после spot-check, если попадают в итоговый evidence packet.

## Targeted MCP list

Минимальный fact-check перед accepted source packet через Firecrawl + Exa:

1. Catsby Family: текущие цены WALL/VINE/TREE, сменные элементы, рассрочка.
2. Hunnkatt: текущие модели, prices, hidden mounts, wheel, replacement fabric.
3. КотаМ: “1000 комбинаций”, replacement/repair claims, материалы.
4. “Мы Бобры”: 5-летняя гарантия, running wheel, монтаж.
5. Tuft+Paw: Cove/Grove/Cloud Nine prices, behaviorist claim, 30-day guarantee.
6. RHRQuality: warranty, spare parts, 20 cm posts, load claims, “largest producer” claim.
7. Catastrophic Creations: current product scope, hidden bracket, replacement fabric/cork, Jackson Galaxy claim.
8. LucyBalu: Choupette collaboration and exact wording.
9. Catit Vesper: actual current line, replacement parts, any AR claim.
10. Kattens No.1: current existence, No Limit mount, modular add-ons.
11. Russian pet market: 2023/2024/2025 numbers with source hierarchy.
12. FMI stats: 48%, 62%, 73%, 76%, CAGR 6.2%, $5.2B->$10.3B claims.

Отдельно после source packet, если нужно для решений: Avito/Ozon/WB/UGC проверяются только в пределах того, что Firecrawl/Exa реально достают из публичного веба. Wordstat и Apify не закладывать как доступные инструменты; если без них вопрос не закрывается, фиксировать как gap.

## Task for Claude/clone

1. Сделать inventory всех old + new M2-03 источников.
2. Собрать source-status matrix по правилам salvage-first.
3. Сформировать accepted source packet: claims, которые можно использовать в internal RESEARCH.
4. Сформировать targeted MCP instruction по списку выше.
5. После MCP решить: `salvage` или `targeted MCP complete -> internal RESEARCH`.

Запреты остаются активны: не делать `SYNTHESIS.md`, client-md, HTML-BRIEF, HTML и hub publish до RESEARCH MD_ACCEPTED и перехода на новый text→visual runbook.
