# M2-03 Stop Gate

Дата: 2026-05-23  
Scope updated by user: salvage-first before any new DR / MCP / RESEARCH-BRIEF / internal RESEARCH.

Current MCP stack for new checks: Firecrawl + Exa. Historical Tavily fact-check files are baseline only; do not route new checks to Tavily by default.

## Allowed Now

- Salvage Audit of old M2-03 materials
- Inventory
- Source Status Matrix
- Gap Matrix
- Decision: salvage / targeted MCP / new DR

## Explicitly Blocked

Before Salvage Audit decision:

- new Deep Research
- DR launch / source intake
- calibration based on new raw DR
- MCP instruction based on new DR
- RESEARCH-BRIEF
- internal RESEARCH

Stop before any client-facing layer:

- `SYNTHESIS.md`
- client-md
- HTML-BRIEF
- HTML
- hub publish

## Required Switch After MD_ACCEPTED

Once RESEARCH is `MD_ACCEPTED`, use the new text-to-visual runbook:

`~/studio/methodology/m2-deep-research/01-working/m2-text-then-visual-runbook.md`

Do not produce client-facing SYNTHESIS or HTML with the old pipeline.
