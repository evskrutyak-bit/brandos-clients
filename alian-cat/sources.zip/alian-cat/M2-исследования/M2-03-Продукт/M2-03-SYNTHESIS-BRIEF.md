# M2-03 SYNTHESIS-BRIEF — Alien Cat Product

Дата: 2026-05-24
Модуль: M2-03 Продукт
Канон-статус: transfer-test candidate v1.2
Жанр документа: **decision brief / контракт для Writer Draft**, не сам SYNTHESIS и не client-facing
Stop-gate: SYNTHESIS / client-md / HTML-BRIEF / HTML / hub publish — заблокированы

---

## 0. О документе

Этот файл — контракт для будущего Writer Draft (Pushkin / writer-mode по runbook §4.1). Он не является SYNTHESIS и не пишет клиентского текста. Brief фиксирует:

- источник правды и иерархию источников;
- обязательную карту RESEARCH, которую Writer **не имеет права сжать**;
- что Writer может и не может сделать;
- gates после Writer Draft;
- acceptance criteria самого SYNTHESIS на будущее.

Brief нужен, потому что без него SYNTHESIS превращается либо в механическую выжимку RESEARCH (паттерн Picnic M2-05), либо в выборочный narrative по одной продуктовой оси (паттерн «писатель выбрал, что красиво, и обрезал остальное»). Новое обязательное правило: **SYNTHESIS сжимает доказательства, но не сжимает карту RESEARCH.**

---

## 1. Цель будущего SYNTHESIS

Собрать клиентский лонгрид-синтез M2-03 «дизайнерская интерьерная мебель и когтеточные изделия для кошек в РФ», который:

1. Сохраняет **полную продуктовую карту** из `M2-03-RESEARCH.md` (8 категорий, 37 игроков, продуктовая архитектура, материалы / proof, новинки, упаковка / TOV).
2. Сжимает **доказательную базу** (67 SKU → ключевые опорные SKU; 41 оффер → опорные офферы; 38 источников → ключевые источники + полная R8 в приложении).
3. Передаёт картину рынка **без рекомендаций по линейке Alien Cat** (M3-решения — за пределами SYNTHESIS).
4. Открывает 8 проверенных гипотез R0.11 + 1 gap как **вопросы для следующих модулей**, не как решения.

SYNTHESIS — это не рекомендация и не стратегия. Это организованная клиентская картина категории.

---

## 2. Адресат и регистр

**Основной адресат:** владелец Alien Cat (Светлана Северина) и команда проекта на стороне Alien Cat.

**Регистр:** профессионально-нейтральный, читается как research-лонгрид BrandOS v1.3, не как маркетинговая статья и не как методический отчёт.

**Что НЕ должен получиться SYNTHESIS:**

- не пост в Telegram / Threads;
- не продающий лендинг;
- не консалтинговая презентация;
- не academic paper;
- не sales-copy;
- не Telegram-пост с эмодзи и хуками;
- не deck с bullet-only слайдами;
- не client-facing «вам нужно сделать X»;
- не internal-отчёт с R10/R11 / методологическим self-check (это R-уровень, остаётся в RESEARCH).

---

## 3. Source hierarchy

Иерархия источников. При конфликте — побеждает верхняя строка.

| # | Источник | Роль |
|---|---|---|
| 1 | `M2-03-RESEARCH.md` (MD_ACCEPTED) | Главный source — содержит карту, которую нельзя сжимать |
| 2 | `M2-03-MD-ACCEPTANCE-GATE.md` | Gate proof (LANGUAGE_TECH_PASS + READER_SANITY_PASS); подтверждает применимость текстов из RESEARCH |
| 3 | `M2-03-RESEARCH-BRIEF.md` | Acceptance criteria и формальные ограничения RESEARCH |
| 4 | `M2-03-TARGETED-MCP-RESULTS.md` | Источник corrected claims; перебивает DR при конфликте |
| 5 | `M2-03-CALIBRATION-LOG.md` | Разрешение конфликтов Claude × Gemini DR; объединение игроков и SKU |
| 6 | `DR-SOURCES/raw-claude-deepresearch-product-2026-05-24.md` | Reference; контекст структурированных таблиц |
| 7 | `DR-SOURCES/raw-gemini-product-2026-05-24.docx` + extracted .txt | Reference; контекст narrative / R0.12 проверки |
| 8 | `brand/profile.md`, `brand/offer-core.md`, `brand/audience.md`, `brand/voice-style.md`, `brand/personal-dna.md`, `brand/selling-map.md` | Brand context для voice/регистра |
| 9 | `learning/corrections.md` | Клиентские коррекции на язык/смысл |
| 10 | M2-исследования/продукт/* (legacy L1-L5) | Anti-example only; не source |

**Запрещено как источник:**

- legacy `AlianCat_Product_Synthesis.md` (L4) — anti-example жанра / языка;
- legacy raw DR апреля 2026 (L1, L2) — не паrned, recheck-rate 100% по точечным числам;
- любые внешние источники, не упомянутые в R8 internal RESEARCH.

---

## 4. Source-map contract (обязательный)

Главное методологическое правило: **SYNTHESIS обязан сохранить полную карту RESEARCH; сжимать можно только доказательства внутри каждого блока карты.**

Ниже — шесть карт, которые SYNTHESIS **не имеет права сжать**. Каждая карта — это перечень того, что обязано появиться в SYNTHESIS (с указанием статуса: core / adjacent / weak signal / refuted / unresolved). Если Writer решает что-то опустить — это должно быть явно отмечено в Writer Draft как «исключено с причиной X», иначе SOURCE_COVERAGE_PASS не проходит.

### 4.1. Product category map

Восемь продуктовых категорий из R1 RESEARCH:

| Категория | Статус для SYNTHESIS | Обязательно показать |
|---|---|---|
| Напольные многоуровневые комплексы | **CORE** | центр тяжести категории, разброс 3 000-120 000 ₽, разные ярусы материалов, отдельные SKU для крупных пород |
| Когтеточки и скретч-элементы | **CORE** | категория входа и регулярного повтора, материал каната как differentiator (джут / сизаль / хлопок) |
| Настенные системы | **CORE** | растущий городской ярус, экономия места, барьер монтажа, диапазон 4 044-31 470 ₽ |
| Тумбы под лоток (скрытые лотки) | **CORE** | новая категория, западный mainstream опережает РФ, $105-350 на западе, 15 000-35 000 ₽ в РФ |
| Сменные элементы и ремонтные комплекты | **CORE (главная продуктовая пустота РФ)** | артикулируется только у 20-30% игроков; РФ-аналоги Catsby / КотаМ / «Мы Бобры» / Pet БМФ |
| Домики и лежанки | **ADJACENT** | сезонная категория; пик в ноябре (Salehoo, с caveat $19-30) |
| Зоны кормления | **ADJACENT** | cross-sell, не главное направление; пример miioo Om-Nom |
| Сервис и ремонт | **ADJACENT, развивающаяся** | у самых зрелых производителей; монтаж 5 000 ₽ Москва, 3D-макет от 2 500 ₽, AR-примерка |
| Беговые колёса | **WEAK SIGNAL → растущий** | новая под-категория, два РФ-игрока (Hunnkatt Ekorn MAX, «Мы Бобры» «Забава») |
| Smart-мебель с motion sensors | **WEAK SIGNAL** | один зарубежный игрок (PurrNook Jellyfish), в РФ отсутствует |

**Writer не имеет права:** опустить хоть одну CORE-категорию; превратить ADJACENT в «не важно»; стереть weak signals из картины; объединить «когтеточки» и «настенные системы» в одну категорию; убрать тумбы под лоток как «не относится к Alien Cat».

### 4.2. Player / market map

37 игроков из R2 RESEARCH, объединённые по типу продуктовой логики. Все 11 типов должны появиться в SYNTHESIS хотя бы одним игроком.

| Тип логики | Обязательные представители | Можно сжать (опционально) |
|---|---|---|
| Модульно-сменные | Catsby Family, КотаМ, «Мы Бобры», Catastrophic Creations | — (все четверо load-bearing) |
| Флагман-строители | Teddy Room, Pettel, RINN, MiaCara | можно одного выбрать как примарный |
| Ремонтно-сменные | RHRQuality, Pet БМФ, Catit Vesper, The Refined Feline | RHRQuality + Refined Feline load-bearing, остальные — sample |
| Кастомные | Hunnkatt, Hicat, Котомастер, CatioCat | Hunnkatt + CatioCat — load-bearing для РФ-кастома; Hicat — international reference |
| Гибридные | Tuft+Paw, miioo.pet, KBSPETS, Mau, Bon Cat | Tuft+Paw + miioo.pet load-bearing |
| Вход-строители (массовый сегмент) | Котосчастье, Зооник / Домоседы, ЛапаМоя, PetTails, PET PRIDE, IKEA (Lurvig→Utsaedd) | можно одного-двух как представителей |
| Smart / эксперимент | PurrNook | load-bearing для weak-signal |
| Эко-recycled | Pryde Pets | можно одной строкой как тренд |
| Сезонный | Dhanus Decor | можно одной строкой |
| Mass-furniture integration | TOWALKER, Miza / Peelorange | одной строкой как тренд интеграции |
| B2B-премиум | Murr and Woof | одной строкой как канал |
| Pet БМФ | (отдельно — единственный РФ-пример артикулированной S/M/L ролевой логики) | LOAD-BEARING обязательно |
| Catsby Family | (отдельно — главный РФ-пример модульной экосистемы с 12000+ комбинаций) | LOAD-BEARING обязательно |
| «Мы Бобры» | (отдельно — главный РФ-пример 5-летней гарантии) | LOAD-BEARING обязательно |
| Pushok (Пушок) | (отдельно — РФ-пример производственного опыта + AR-примерка) | LOAD-BEARING обязательно |

**Дополнительная classification оси:**

- **aesthetic / design references:** Catsby (скандинавский дуб), Hunnkatt (norweg names + скрытое крепление), miioo.pet (чёрно-белый графичный код), MiaCara (sculpture), RINN (1300 лет Hida), Karimoku Cat, LucyBalu (× Choupette);
- **marketplace presence:** Ozon, WB, Я.Маркет, Мегамаркет, VK Market (Teddy Room), Avito (CatioCat, Hunnkatt, Catsby);
- **custom-on-demand:** Hunnkatt, Hicat, Котомастер, CatioCat, Catsby (модульная сборка), КотаМ (изготовление по эскизам);
- **international product references:** Tuft+Paw, MiaCara, LucyBalu, RINN, Karimoku Cat, RHRQuality, Hicat, Catastrophic Creations, The Refined Feline, Mau, Bon Cat, KBSPETS, Catit Vesper, PurrNook, Pryde Pets, Armarkat, Kattens No.1, TOWALKER, Dhanus Decor, Miza/Peelorange.

**Writer не имеет права:** свести список к 5-7 «самым ярким» игрокам; убрать массовый сегмент как «не интересно»; убрать B2B-канал; убрать international references; объединить кастомных и гибридных в один тип.

### 4.3. Assortment architecture

Из R3, R4 RESEARCH.

**Ценовые ярусы (РФ):**

- 1 000-7 000 ₽ — массовый вход (когтеточки-столбики, простые домики).
- 7 000-15 000 ₽ — средний (комплексы 2-4 уровня, настенные элементы).
- 15 000-30 000 ₽ — верхний средний (премиум-настенные, напольно-настенные, тумбы Teddy Room, беговые колёса).
- 30 000-50 000 ₽ — верхний (TREE 4 уровня, Блуша, miioo Комплекс 4).
- 50 000-120 000 ₽ — авторский / ultra (CatioCat, UNRESOLVED диапазон).

**Ценовые ярусы (зарубеж):**

- 69-200 USD — массовый и средний премиум.
- 200-650 USD — премиум.
- 600-1 200 GBP — UK bespoke.
- 559 EUR — German luxury.
- 50 000+ ¥ — Japanese luxury.
- 7 700 EUR — ultra (RINN NEKO, 22 изделия в год).

**Ролевые шаблоны (вход → ядро → флагман → повтор):**

- Catsby Family: WALL вход / VINE ядро / TREE флагман / столбики и полки повтор (с MCP-corrected формулировкой 12000+ комбинаций, нагрузка 30 кг, 12 мин сборка, биоразлагаемая упаковка, гипоаллергенный фетр).
- «Мы Бобры»: элементы вход / Токио-130 ядро / Карта мира + Забава флагман / все элементы заменяемы повтор (с MCP-corrected формулировкой 5 лет гарантии, монтаж 5 000 ₽ Москва).
- КотаМ: лежанки вход / комплексы ядро / Ингрид флагман / швейные элементы на металлических кнопках повтор.
- Pet БМФ: S вход (котята / средние) / M ядро / L флагман (крупные) / столбы от 199 ₽ повтор.
- ЛапаМоя: столбики вход / домики с когтеточками ядро / комплексы флагман.
- Hunnkatt: настенные модули вход / Vakker ядро / Svart + Ekorn MAX флагман / сменный гамак повтор.
- Tuft+Paw: Cubby вход / Cloud Nine ядро / Cove флагман / Really Great Litter повтор-подписка.
- Catastrophic Creations: Floating Sisal Posts вход / Cat Shelves ядро / The Juggernaut флагман / replacement fabric повтор.
- RHRQuality: когтеточка-столб вход / Cat trees ядро / Maine Coon Lounge Retreat флагман / открытый каталог запчастей повтор.

**MCP-corrected формулировки, которые SYNTHESIS обязан использовать без искажения:**

- Catsby — **12000+ комбинаций** (не 1000), **30 кг нагрузка**, **12 минут сборка**, **биоразлагаемая упаковка**, **гипоаллергенный фетр**.
- Catsby ценовая матрица: **TREE 4 уровня (флагман) 34 810-35 910 ₽** (не путать с VINE 4 уровня 32 800-33 680 ₽); WALL 16 460 (2 ур) — 31 470 ₽ (4 ур); VINE 20 740 (2 ур) — 33 680 ₽ (4 ур); STAND 21 790-25 990 ₽.
- Hunnkatt Ekorn MAX — **три варианта 25 080 / 27 660 / 29 200 ₽** (не одна цена).
- «Мы Бобры» «Забава» — **настенное** (не напольное) беговое колесо; материалы: берёзовая фанера, хлопковый канат, акриловое стекло; **точная цена UNRESOLVED, использовать диапазон или ссылаться на UNRESOLVED**.
- «Мы Бобры» — **гарантия 5 лет на элементы** (исключая естественный износ), подтверждена отдельной страницей сайта.
- LucyBalu × Choupette — реальная коллаборация с кошкой Карла Лагерфельда **через caretaker Françoise Caçote**, не «по мотивам Лагерфельда».

**Запрещённые формулировки (REFUTED):**

- «RHRQuality — единственный игрок с такой гарантией в Европе» — REFUTED, использовать «крупнейший в Европе».
- «Tuft+Paw Cove $599» — REFUTED, использовать $199.
- «Catsby Vine 19 тыс. ₽ нижняя граница» — REFUTED, актуальный нижний 16 460 ₽ (WALL 2 ур).
- «Refined Feline 1 491 отзыв / 4,5★» — REFUTED как стабильный snapshot, не использовать точное число.
- «Сезонность +59% весной» — REFUTED, заменено Salehoo «пик в ноябре, +92% за 2 года, +61,7% за 6 мес» (с caveat $19-30 плюшевые лежанки).
- «Catsby 1000 комбинаций» — CORRECTED на 12000+.
- «Рынок зоотоваров РФ 433 млрд» без оговорки 2023 — CORRECTED, главная цифра — 590 млрд ₽ за 2025 (TAdviser 2026-02-05), 433 млрд за 2023 (Зооинформ) как историческая точка.

### 4.4. Trust / materials / proof map

**Материалы premium-сегмента:**

- Натуральное дерево: дуб (Catsby 20 мм, КотаМ цельные столбы), массив бука (CatioCat), массив сосны (Armarkat), берёзовая фанера (KotoMoto, «Мы Бобры»), Hida hardwood (RINN), Baltic Birch plywood (Bon Cat, made in USA с РФ-материалом).
- Канаты: натуральный сизаль (RHRQuality 8 inch, Ø 20 см), хлопок без пропиток (Catsby, КотаМ, Catastrophic), джут (массовый сегмент).
- Покрытия: натуральные масла + воск вместо лака (Catsby, КотаМ, RINN); micro suede вместо ковролина (Refined Feline, Karimoku); шерстяной фетр (LucyBalu).
- Фурнитура: магнитные крышки на неодимовых магнитах (Catsby), patented hidden bracket (Catastrophic), скрытое крепление (Hunnkatt Svart), массивный чёрный матовый металл (Teddy Room).
- Конструктив для крупных пород: основание 60-100 см, столбы Ø 8-20 см, ABS plastic fastening M8/M10, plush 600 г/м² (RHRQuality); 88 lbs / 40 кг нагрузка; «25+LBS» (KBSPETS).

**Производство / география:**

- Россия: Catsby (СПб), КотаМ (МСК/СПб), «Мы Бобры» (Москва), Hunnkatt, Пушок (СПб, 19 лет), ЛапаМоя (Красноярск), Котомастер (МСК), KotoMoto, Teddy Room (Нижний Новгород), CatioCat (Москва), Pet БМФ, miioo.pet, Murr and Woof (Москва, B2B).
- США: Tuft+Paw, Catastrophic Creations (Michigan), The Refined Feline, Mau, Bon Cat, KBSPETS, Armarkat, PurrNook, Pryde Pets, TOWALKER.
- Германия: MiaCara, LucyBalu (Мюнхен).
- Япония: RINN (Hida), Karimoku Cat.
- Нидерланды: RHRQuality.
- Великобритания: Hicat.
- Канада / Global: Catit Vesper.
- Дания: Kattens No.1.
- Австралия: Dhanus Decor.
- Индия: Miza (Peelorange).

**Долговечность как proof:**

- 5 лет гарантии («Мы Бобры», уникальный сигнал для РФ).
- 1 год гарантии (КотаМ, RHRQuality, Catsby 6 мес — стандарт).
- 30-day money-back guarantee (Tuft+Paw).
- 45-day risk-free trial + 1 year warranty (Mau).
- Возврат 7 дней без объяснения (Catsby).
- 30 кг динамическая нагрузка (Catsby), 88 lbs / 40 кг (RHRQuality), 25+LBS (KBSPETS), 13,5 кг (Refined Feline Lotus), 12 кг до 15 кг (Karimoku).

**Уход / сменность:**

- Все элементы заменяемы («Мы Бобры», RHRQuality, Mau, Catit Vesper).
- Сменные подушки на липучках, micro suede в стиральной машине (Refined Feline).
- Швейные элементы на металлических кнопках, легко снять / постирать / заменить (КотаМ).
- Сменный гамак (Hunnkatt 3 157 ₽).
- Replacement fabric, cork pads (Catastrophic).

**Подтверждения / сертификации:**

- REACH compliance (MiaCara).
- Infant-grade materials (Karimoku).
- FSC-сертифицированное дерево, recycled (Mau, Catastrophic, Pryde Pets, PetPals).
- Биоразлагаемая упаковка (Catsby).
- Patented hidden bracket system (Catastrophic).

**Ограничения / UNRESOLVED (см. §4.5):**

- Цены «Мы Бобры» Забавы, CatioCat диапазон, PurrNook Jellyfish, Catastrophic Juggernaut — UNRESOLVED, не цитировать как факт.

### 4.5. Refuted / unresolved / gaps

Этот блок особенно важен — SYNTHESIS не имеет права превратить эти позиции в выводы.

**REFUTED — нельзя использовать вовсе:**

- «RHRQuality — единственный игрок с такой гарантией в Европе».
- «Tuft+Paw Cove $599».
- «Catsby Vine 19 тыс. ₽ нижняя граница».
- «Refined Feline 1 491 отзыв / 4,5★».
- «Сезонность +59% весной».
- L4 legacy synthesis как продуктовая стратегия — не источник.
- «Cat Brand (Алтай) экспорт в 10+ стран» — без подтверждения.

**UNRESOLVED — можно упомянуть только как открытый вопрос / зона добора:**

- Точные цены «Мы Бобры» Забавы, CatioCat ценовой диапазон, PurrNook Jellyfish $289, Catastrophic Juggernaut $645 — продукты подтверждены, конкретные цены не верифицированы MCP.
- КотаМ точная цифра комбинаций модульной системы (Firecrawl scrape ERR_TUNNEL).
- Hicat «флагман категории UK» — снято как absolute claim; использовать «один из игроков UK bespoke-сегмента».
- Гипотеза 8 R0.11 (Avito vs собственный сайт — разная карточная логика) — данных недостаточно, gap для M2-04 / M3 / M7.

**Open data gaps (R9.1, tool-wishlist):**

1. Полный массив SKU маркетплейсов (требует Apify).
2. UGC-цитаты из отзывов с прямыми URL (требует Apify reviews).
3. Wordstat-частотность продуктовых запросов (требует Wordstat MCP).
4. Полные каталоги конкурентов с пагинацией (Firecrawl deep crawl).
5. Точные текущие условия рассрочки / доставки / скидок (динамические элементы).
6. Avito-выгрузка по продуктовым запросам (требует Apify Avito).
7. Точные цены не-приоритетных SKU.
8. Cat Brand (Алтай) экспорт.
9. КотаМ точная цифра комбинаций.

**Writer не имеет права:** превратить UNRESOLVED в утверждение; превратить gap в «недостаток рынка»; превратить REFUTED в скрытый намёк («говорят, что…»); убрать ограничения, чтобы SYNTHESIS выглядел увереннее.

### 4.6. Client hypotheses

Восемь гипотез R0.11 проверены в RESEARCH R9.2. Семь подтверждены, одна в gap.

| # | Гипотеза | Вердикт R9.2 | Что разрешено в SYNTHESIS | Что запрещено |
|---|---|---|---|---|
| 1 | S/M/L как роли линейки (вход / ядро / флагман) | Подтверждается с оговоркой | показать как продуктовый паттерн рынка (Pet БМФ, Catsby, ЛапаМоя) | принять как решение для Alien Cat линейки |
| 2 | Сменные элементы как повтор | Подтверждается; главная пустота РФ | показать как продуктовую пустоту 20-30% игроков | сделать вывод «Alien Cat должен запустить программу замены» |
| 3 | Усиление для крупных пород как отдельная рамка | Подтверждается | показать выделенные SKU и линейки конкурентов | сделать вывод «Alien Cat должен ввести L-серию для мейн-кунов» |
| 4 | Furniture-first как продуктовый стандарт | Подтверждается в премиум | показать как стандарт верхнего яруса | принять как решение по позиционированию Alien Cat (это M6) |
| 5 | Натуральные материалы / долговечность / ремонтопригодность как доказательность цены | Подтверждается | показать как ценовой proof | принять как продуктовое решение |
| 6 | Тумба под лоток / настенные / компактные — отдельные направления | Подтверждается, западные mainstream опережают РФ | показать как растущие категории и продуктовую пустоту РФ | сделать вывод «Alien Cat должна войти в тумбы под лоток» |
| 7 | Упаковка / инструкция / крепёж / сервис — часть продукта | Подтверждается | показать как стандарт премиум-сегмента | сделать вывод по составу сервиса Alien Cat |
| 8 | Avito vs собственный сайт — разная карточная логика | Данных недостаточно | показать как открытый вопрос | сделать вывод по каналам Alien Cat |

**Сборное правило:** гипотезы передаются в SYNTHESIS как **вопросы для следующих модулей** (M3 — линейка, M4 — ЦА / JTBD, M5 — конкуренты, M6 — позиционирование, M7 — GTM). SYNTHESIS открывает развилки, не закрывает их.

---

## 5. Writer Draft constraints

### 5.1. Writer (Pushkin / writer-mode) **может**:

- сжимать доказательную базу (67 SKU → ~15-20 опорных, 41 оффер → ~12-18 опорных, 38 источников → ключевые в тексте + полная R8 в приложении);
- писать клиентским языком (профессионально-нейтральный регистр BrandOS-лонгрида);
- выбирать порядок подачи внутри одной карты (например, начать с категории «сменные элементы» как главной пустоты, потом перейти к напольным комплексам);
- группировать игроков по продуктовой логике в более crisp нарратив;
- использовать voice / тон из `brand/voice-style.md`;
- добавлять связки между разделами, переходные фразы, lead-in блоки;
- использовать форматирование (заголовки, списки, цитаты, таблицы) в соответствии с BrandOS Artifacts v1.3.

### 5.2. Writer **не может**:

- выбрать одну продуктовую ось (например, только «сменные элементы») вместо всей карты;
- скрыть или существенно сократить CORE-категории из §4.1;
- убрать ADJACENT-категории как «не важные»;
- стереть weak signals (беговые колёса, smart-мебель) из картины;
- свести список игроков к 5-7 «самым ярким»;
- убрать массовый сегмент / B2B-канал / international references;
- превратить гипотезу в решение для Alien Cat;
- использовать конструкции «Alien Cat должен», «Alien Cat нужно», «мы предлагаем Alien Cat», «стратегия для Alien Cat», «решение по линейке», «рекомендуем»;
- убрать UNRESOLVED-метки, чтобы SYNTHESIS выглядел увереннее;
- превратить REFUTED в скрытый намёк;
- использовать формулировки, отнесённые к корректировкам §4.3 (Catsby 1000 комбинаций, Cove $599, RHRQuality «единственный», Refined Feline 1491 отзыв, +59% весной, рынок 433 млрд без оговорки 2023);
- добавлять факты вне source packet §3;
- писать как Telegram-пост или sales-copy;
- использовать методологический жаргон («контур», «развилка», «рамка», «слой», «оверлей», «pipeline», «runbook», «artifact», «gate», «pass»);
- использовать запрещённые рамки v1.2 («Кошкин Дом» как primary name, «зоотовар» как самохарактеристика, «премиум» как self-claim для Alien Cat, «VIP / люкс / эксклюзив», «трон» как универсальная категория, «рассрочка» как обещание Alien Cat, «единственный игрок» / «лидер рынка» без доказательства).

### 5.3. Объём целевого SYNTHESIS

Ориентир: **60-100 KB** клиентского MD. Это:

- меньше RESEARCH (~90 KB), за счёт сжатия доказательств;
- но не меньше, чем нужно для сохранения карты §4.1-§4.6;
- сопоставимо с Picnic M2-04 SYNTHESIS B2C (~60 KB) — но Alien Cat M2-03 шире по карте, поэтому верхний ориентир выше.

Если Writer Draft даёт < 50 KB — это сигнал, что карта свернулась, и Writer выбрал одну ось. SOURCE_COVERAGE_PASS такой draft не пройдёт.

Если Writer Draft даёт > 120 KB — это сигнал, что сжатия доказательств не произошло; нужна перезапись со схлопыванием SKU-таблиц.

---

## 6. Required gates после Writer Draft

Последовательность gate package для будущего SYNTHESIS:

```
Writer Draft
  → SOURCE_COVERAGE_PASS (новый обязательный gate)
  → LANGUAGE_TECH_PASS
  → READER_SANITY_PASS
  → EDITORIAL_PASS (humanizer + human-style-check, Stage 4.9 runbook)
  → CLIENT_READY
```

Stage 4 (HTML build), Stage 5 (Visual Review), Stage 6 (HTML_READY 4-pass), Stage 7 (DEPLOY_QC / publish) — далее по runbook §6-§9.

### 6.1. SOURCE_COVERAGE_PASS — criteria

Новый gate, который проверяет, что Writer Draft не свернул карту RESEARCH. Критерии:

| # | Check | Метод |
|---|---|---|
| C-1 | Все CORE-категории из §4.1 присутствуют в SYNTHESIS | grep по 5 CORE-категориям + visual review структуры |
| C-2 | ADJACENT-категории присутствуют или явно исключены с причиной | grep + Writer Draft должен содержать список исключений |
| C-3 | Weak signals (беговые колёса, smart-мебель) присутствуют | grep по «Hunnkatt Ekorn MAX», «Мы Бобры Забава», «PurrNook» / «smart» |
| C-4 | Все 11 типов игроков из §4.2 представлены хотя бы одним игроком | grep по типам логики + по load-bearing именам (Catsby, Мы Бобры, КотаМ, Pet БМФ, Hunnkatt, Tuft+Paw, RHRQuality, Catastrophic, RINN, MiaCara) |
| C-5 | Массовый сегмент и B2B-канал присутствуют | grep по «Котосчастье / Зооник / маркетплейс» + «Murr and Woof / B2B» |
| C-6 | International product references присутствуют | grep по минимум 5 зарубежным брендам |
| C-7 | Все CORRECTED формулировки из §4.3 применены | grep на «12000+», «30 кг», «12 минут», «5 лет гарантии», «настенное беговое колесо», «590 млрд», «$199 Cove», «через caretaker» |
| C-8 | REFUTED не используется как утверждение | grep на запрещённые формулировки |
| C-9 | UNRESOLVED помечены как вопросы / зоны добора | grep на «UNRESOLVED», «диапазон не верифицирован», «открытый вопрос» |
| C-10 | Гипотезы R0.11 поданы как открытые вопросы, не как решения | grep на «Alien Cat должен», «рекомендуется», «стратегия для Alien Cat», «решение по линейке» — должен быть clean |
| C-11 | Клиент, читая только SYNTHESIS, видит полную продуктовую карту | reader sanity check: проверка наличия всех 8 категорий, всех ярусов, всех типов игроков, всех ключевых трендов |
| C-12 | Гипотезы и вопросы идут **после** карты, не вместо неё | структурная проверка: гипотезы R0.11 не должны открывать SYNTHESIS, их место — после R1-R7 контент-секций |

### 6.2. LANGUAGE_TECH_PASS — переиспользование канона M2-03

Применяется тот же набор проверок, что и в `M2-03-MD-ACCEPTANCE-GATE.md` §1, но **для client-facing SYNTHESIS**:

- 17 grep-проверок на hard bans / M3-формулировки / рисковые рамки;
- разница с RESEARCH: в SYNTHESIS **запрещён** даже metaframe-список запретов (нет R0.13 как раздела); запрещённые слова не должны появиться вовсе, кроме как в виде явных REFUTED-блоков или анти-примеров в R7-аналоге, если он переносится;
- регистр client-facing: «вы», «вам», «как вы видите» — допустимо в адресовании к Светлане; «исследование показывает», «по данным» — допустимо.

### 6.3. READER_SANITY_PASS

- документ можно читать без знания методологии и без internal RESEARCH;
- 8 категорий, 11 типов игроков, ценовые ярусы и тренды видны с первого прохода;
- ограничения и UNRESOLVED поняты;
- нет дрейфа между разделами SYNTHESIS;
- блоки идут в логичном порядке для клиентского лонгрида.

### 6.4. EDITORIAL_PASS (humanizer + human-style-check)

По runbook §4.3:

- humanizer — editorial critique по Wikipedia «Signs of AI writing»;
- human-style-check — 17 категорий AI signs;
- voice-adapter — только при необходимости подтянуть тон;
- output в формате таблицы Fragment / Problem / Category / Suggested fix / Applied;
- если > 15 содержательных правок → STOP, не чинить вручную, пересобрать Writer Draft с улучшенным prompt.

### 6.5. CLIENT_READY

Ставится только после **всех четырёх** gate: SOURCE_COVERAGE_PASS + LANGUAGE_TECH_PASS + READER_SANITY_PASS + EDITORIAL_PASS.

---

## 7. Открытые методологические вопросы

Эти вопросы требуют решения методологической команды **до** запуска Writer Draft:

### 7.1. Q-1. Roundtable отсутствует

Runbook §4.1 Writer prompt в source packet требует `ROUNDTABLE-CHECK`. Для Alien Cat M2-03 roundtable не проводился (в отличие от Picnic M2-04, где roundtable был частью pipeline). Варианты:

- (a) **Skip roundtable** — обосновать, что RESEARCH MD_ACCEPTED + MCP-corrected claims заменяют roundtable как gate согласованности.
- (b) **Lite roundtable** — провести короткий roundtable на 6 lenses (methodology / marketing-strategy / editorial-client-language / UX / visual-BrandOS / HTML-QA) после Writer Draft, до SOURCE_COVERAGE_PASS.
- (c) **Full roundtable** — провести полный roundtable перед Writer Draft, как делалось в Picnic.

Моя рекомендация: **вариант (b)**, lite roundtable после Writer Draft — это даёт второе мнение по карте, не задерживает запуск.

### 7.2. Q-2. MCP-EVALUATION эквивалент

Runbook §4.1 требует `MCP-EVALUATION` в source packet. У нас есть `M2-03-TARGETED-MCP-RESULTS.md` — это операционный эквивалент. Решение: **использовать M2-03-TARGETED-MCP-RESULTS.md как MCP-EVALUATION**; в Writer prompt явно прописать.

### 7.3. Q-3. Hero Hook copy для SYNTHESIS

По lessons Picnic M2-04 Sprint 1 (см. `feedback_hero_hook_gate.md` в global memory): перед HTML_BRIEF_ACCEPTED обязательны 6-8 вариантов H1 + оценка по 4 критериям. Этот gate применяется на стадии HTML-BRIEF, **после** CLIENT_READY. Но опционально SYNTHESIS-уровень тоже может содержать кандидатов H1 / lead-копий — это снижает риск переписки на HTML-стадии.

Моя рекомендация: **Writer Draft даёт 3-5 рабочих вариантов H1 как часть SYNTHESIS** (раздел / комментарий в начале документа). Финальный H1 — за командой заказчика на стадии HTML-BRIEF.

### 7.4. Q-4. Адресат — клиент или клиент + команда?

Регистр SYNTHESIS зависит от того, читает ли документ:

- (a) только Светлана как владелец — более прямой, доверительный регистр;
- (b) Светлана + команда проекта Alien Cat — более нейтральный, professional-research регистр;
- (c) Светлана + методологическая команда BrandOS — учитывает, что часть читателей в курсе методологии.

Моя рекомендация: **вариант (b)**, professional-research регистр BrandOS-лонгрида. Это нейтральный default, который работает для всех трёх аудиторий.

### 7.5. Q-5. Структура SYNTHESIS

Открытый вопрос — какая структура внутри документа. Варианты:

- (a) **Зеркалировать R1-R9** — короткий executive + категории + игроки + матрица + архитектура + офферы + новинки + упаковка + источники + гипотезы. Минус: похоже на RESEARCH в client-обвёртке, не лонгрид.
- (b) **Драматургия по канону BrandOS Artifacts v1.3** — hero-loft → ставка → не идём → можем → доказательства → справочник → решение. Плюс: жанр client-лонгрида. Минус: «решение» в конце — не вписывается в правило «не делать M3-решения».
- (c) **Гибрид** — driven by main продуктовый narrative (например, «как устроена категория и где её пустоты»), внутри — карта 8 категорий, типология игроков, ценовые ярусы, материалы / proof, новинки, открытые вопросы для следующих модулей.

Моя рекомендация: **вариант (c) гибрид**. Структура драматургическая по форме, но без «решения» в конце — заменяется на «открытые вопросы для M3-M7». Это соответствует жанру RESEARCH SYNTHESIS, который не делает решений.

---

## 8. Acceptance criteria для этого brief

Brief считается готовым к запуску Writer Draft, если методологическая команда:

1. ✅ Утверждает Source-map contract §4.1-§4.6 как обязательное правило сохранения карты.
2. ✅ Утверждает Writer Draft constraints §5.1-§5.3.
3. ✅ Утверждает gate-последовательность §6 (SOURCE_COVERAGE_PASS → LANGUAGE_TECH → READER_SANITY → EDITORIAL → CLIENT_READY).
4. ⚠️ Решает по 5 открытым вопросам §7 (Q-1 roundtable, Q-2 MCP-eval, Q-3 H1, Q-4 адресат, Q-5 структура).
5. ✅ Подтверждает source hierarchy §3.
6. ✅ Подтверждает stop-gate §9.

Без решений по §7.Q-1, Q-4 и Q-5 запуск Writer Draft не имеет смысла — он зайдёт в эти вопросы и потребует переделки.

---

## 9. Stop-gate reminder

До отдельной команды на Writer Draft и до прохождения всех 5 gate (SOURCE_COVERAGE_PASS + LANGUAGE_TECH + READER_SANITY + EDITORIAL + CLIENT_READY) **запрещено**:

- запускать Writer Draft / Pushkin call;
- писать `M2-03-SYNTHESIS.md`;
- собирать client-md;
- собирать HTML-BRIEF;
- собирать HTML;
- publish на hub.

Client-facing layer remains HARD-BLOCKED.

---

## 10. Ledger update

После сохранения этого brief:

| Step | Status | Evidence |
|---|---|---|
| Step 5c LANGUAGE_TECH + READER_SANITY + MD_ACCEPTED | DONE / MD_ACCEPTED | `M2-03-MD-ACCEPTANCE-GATE.md` 2026-05-24 |
| Step 6a SYNTHESIS-BRIEF | **DONE / READY_FOR_METHODOLOGY_CHECK** | этот файл `M2-03-SYNTHESIS-BRIEF.md` |
| Step 6b Writer Draft (Pushkin / writer-mode) | **BLOCKED** until brief accepted + 5 open questions §7 resolved |
| Step 6c SOURCE_COVERAGE_PASS | **REQUIRED** after Writer Draft |
| Step 6d LANGUAGE_TECH_PASS (SYNTHESIS) | BLOCKED | — |
| Step 6e READER_SANITY_PASS (SYNTHESIS) | BLOCKED | — |
| Step 6f EDITORIAL_PASS (Stage 4.9) | BLOCKED | — |
| Step 6g CLIENT_READY | BLOCKED | — |
| Step 7 HTML build / sync (runbook Stage 4) | BLOCKED | — |
| Step 8 VISUAL_REVIEW_PASS (runbook Stage 5.5) | BLOCKED | — |
| Step 9 HTML_READY 4-pass (runbook Stage 6) | BLOCKED | — |
| Step 10 DEPLOY_QC / publish (runbook Stage 7) | HARD-BLOCKED | client-facing stop-gate |

---

*Brief by Claude · 2026-05-24 · transfer-test candidate v1.2 · runbook m2-text-then-visual v0.1 · main rule: SYNTHESIS сжимает доказательства, но не сжимает карту RESEARCH*
