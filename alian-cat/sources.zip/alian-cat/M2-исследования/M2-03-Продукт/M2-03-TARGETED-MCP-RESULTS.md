# M2-03 TARGETED MCP RESULTS — Firecrawl + Exa pass

Дата: 2026-05-24
Модуль: M2-03 Продукт
Статус: Step 4 завершён, transfer-test candidate v1.2
MCP stack used: **Firecrawl + Exa**
Source watchlist: `M2-03-CALIBRATION-LOG.md` §4 (E-XSV-16..32) + carry-over E-XSV-15 из F1

---

## 1. MCP stack used

| Tool | Используется | Calls |
|---|---|---|
| Firecrawl search | да | 8 |
| Firecrawl scrape | да | 5 (1 failed на domik-koshki.ru ERR_TUNNEL, 1 404 на mybobr.ru/begovoe-koleso-zabava-2/) |
| Firecrawl extract | нет | — |
| Exa web_search_exa | нет (Firecrawl search покрыл задачу) | — |
| Exa web_fetch_exa | нет | — |

Не использовалось: Apify, Wordstat, Tavily live, legacy WebFetch.

---

## 2. Claims checked table

### 2.1. КРИТИЧНО (4 из 4 закрыты)

| ID | Claim | Tool | Source URL | Result | Safe wording для RESEARCH |
|---|---|---|---|---|---|
| E-XSV-18 | «Мы Бобры» — гарантия 5 лет на элементы | Firecrawl search | `https://mybobr.ru/garantia_ot_vladelca.html` (заголовок «Гарантия 5 лет на продукцию "Мы Бобры"… без мелкого текста и хитрых условий») | **CONFIRMED** | «Мы Бобры» прямо заявляет 5-летнюю гарантию на элементы изделий (исключая естественный износ), указано на отдельной странице гарантии |
| E-XSV-28 | Рынок зоотоваров РФ 590 млрд за 2025 (Tadviser) | Firecrawl scrape | `tadviser.ru/index.php/Статья:Домашние_животные_в_России` — раздел «**2025: Объем российского рынка зоотоваров за год вырос на 15,8% до 590 млрд рублей**» (страница датирована 2026/02/05 11:28:20) | **CONFIRMED + EXTENSION** | Объём рынка зоотоваров РФ в 2025 г. — 590 млрд ₽ (рост +15,8% к 2024), по данным TAdviser, февраль 2026. Историческая точка: 433 млрд ₽ в 2023 г. (Зооинформ) |
| E-XSV-29 | Salehoo сезонность: +92% за 2 года, +61.7% за 6 мес, пик в ноябре | Firecrawl scrape | `salehoo.com/trends/cat-beds` (page last updated 2026-05-18); цитата «search interest has climbed sharply—roughly +92% over two years and +62% in six months—and the category shows a clear seasonal high in November»; раздел Past 6 Months: Growth 61.70%; High Month November / Low Month May | **CONFIRMED** | По данным Salehoo (май 2026), интерес к категории «cat beds» вырос примерно на 92% за 2 года и на 61,7% за 6 мес; сезонный пик — ноябрь, низкая точка — май. Категория Salehoo измеряется в нише $19-30 (плюшевые лежанки), напрямую к авторской мебели не транслируется, но направление сезона релевантно |
| E-XSV-30 | FMI статистики (48%, 62%, 73%, 76%, CAGR 6.2%, market size $5.2B → $10.3B) | Firecrawl scrape + search | (1) `futuremarketinsights.com/reports/modern-cat-furniture-market` — page reviewed 2025-04-24: «**76%** searching for adaptable to home interior», «**72%** North America Minimalist/Scandinavian», «**68%** Europe same», «**73%** Asia eco-friendly materials», «**62%** multi-functionality», «**70%** quality materials», «**58%** NA smart», «**69%** online shopping»; market size USD 5.2B (2025) → USD 10.3B (2035); CAGR 6.2%; 2024 baseline USD 4.2B; top players Tuft+Paw 15-20%, Frond Design Studios 10-14%, Vesper (Catit) 8-12%, Mau Modern 6-10%. (2) `futuremarketinsights.com/reports/cat-furniture-scratchers-market` — описание: «**48%** of consumers expecting bespoke cat furniture that evolves according to their pet's» | **CONFIRMED** | FMI Modern Cat Furniture Market Report (review 2025-04-24): рынок USD 5,2 млрд в 2025 → USD 10,3 млрд к 2035, CAGR 6,2%; опрос 300 владельцев кошек в NA/EU/Asia. Статистика 48% модульной/bespoke мебели — из отдельного отчёта FMI Cat Furniture & Scratchers Market. Атрибуцию давать раздельно по двум отчётам |

### 2.2. СРЕДНЕ (8 проверено, из них 1 CORRECTED, 6 CONFIRMED, 1 UNRESOLVED)

| ID | Claim | Tool | Source URL | Result | Safe wording для RESEARCH |
|---|---|---|---|---|---|
| E-XSV-16 | Catsby Family «до 1000 комбинаций» | Firecrawl scrape | `catsby-family.ru/` — на главной два явных утверждения: «можно собрать **12000** различных комбинаций комплексов» и «**12000+** вариантов комплексов» | **CORRECTED** | Catsby Family прямо заявляет 12000+ комбинаций модульной системы (не 1000, как было в обоих DR). Использовать «12000+ комбинаций» с атрибуцией к сайту бренда |
| E-XSV-17 | КотаМ (domik-koshki.ru) «до 1000 различных комбинаций» | Firecrawl scrape (failed ERR_TUNNEL) + Firecrawl search | `domik-koshki.ru` — описание подтверждает «природные материалы, продуманная эстетика, 100% натуральный хлопок, арт-объект», но точная цифра комбинаций не извлечена через MCP | **UNRESOLVED** | Использовать только подтверждённое: КотаМ позиционирует модульность и сменность как часть системы. Цифру «1000 комбинаций» без отдельной верификации не давать; в RESEARCH формулировать как «модульная система с возможностью замены отдельных модулей» без числа |
| E-XSV-19 | «Мы Бобры» беговое колесо «Забава» 25 000₽ | Firecrawl search | `mybobr.ru` — «"Забава" настенное беговое колесо для кошек»; цена 25 000₽ из DR не подтверждена прямым прайсом на странице товара (page 404). В одном из отзывов фигурирует «8 500р» рядом со «Забавой» — но это, вероятно, цена другого товара в карточке отзыва. Материалы: берёзовая фанера, хлопковый канат, акриловое стекло | **CONFIRMED partial** | Реальный продукт «Мы Бобры» в линейке: «Забава» — настенное (не напольное, как писал Claude) беговое колесо. Материалы — берёзовая фанера, хлопковый канат, акриловое стекло. Точную цену в RESEARCH давать как «в линейке премиум-сегмента, диапазон 8 000-25 000 ₽ в зависимости от конфигурации» или вынести в R9-gap для будущей проверки |
| E-XSV-20 | Hunnkatt Ekorn MAX 27 660₽ | Firecrawl search | `hunnkatt.com/magazin/folder/begovoe-koleso` — три варианта: 25 080 / 27 660 / 29 200 ₽; главная страница `hunnkatt.com` подтверждает «Колесо беговое для кошек и собак "Ekorn MAX". Кто сказал, что колесо должно быть круглым?! Беговое колесо для кошки с лежанкой и ковролиновой когтеточкой» | **CONFIRMED** | Hunnkatt Ekorn MAX — беговое колесо нестандартной формы с лежанкой и когтеточкой; ценовая линейка 25 080-29 200 ₽. Цена 27 660 ₽ из Claude DR — средний вариант |
| E-XSV-21 | CatioCat авторские деревья 50-120 тыс ₽, натуральные стволы, листва RealTouch, эпоксидная смола | Firecrawl search | `instagram.com/catiocat`, `facebook.com/catiocat`, `catiocat.ru`, Avito-карточки | **CONFIRMED partial** | CatioCat — реальный действующий бренд (Москва), позиционирует «натуральные стволы деревьев, шикарная листва, массив бука или дуба, любой цвет по RAL». Конкретный ценовой диапазон 50-120 тыс ₽ из Claude DR не извлечён MCP-проверкой через публичные каналы (Avito-цены динамичны). В RESEARCH давать как «верхний ценовой ярус РФ, авторские изделия, конкретный диапазон требует direct-quote от бренда» |
| E-XSV-22 | PurrNook Jellyfish Cat Tree $289, LED + motion sensor | Firecrawl search | `purrnook.com/products/sensor-light-jellyfish-cat-tree`, `purrnook.com/products/lovely-jellyfish-cat-tree`; описание: «sculptural perch made from solid wood and motion-sensor lighting», «wireless infrared sensor light», «motion-activated light is built into the top of the litter area» | **CONFIRMED partial** | PurrNook — реальный бренд, флагман Jellyfish Cat Tree существует, оснащён wireless infrared motion-sensor light (LED). Точная цена $289 — не извлечена MCP, требует direct check на purrnook.com. В RESEARCH дать как «smart furniture с интегрированным motion-sensor light» без числа |
| E-XSV-25 | Catastrophic Creations The Juggernaut $645, multiple hammocks, patented hidden bracket | Firecrawl search | `catastrophicreations.com/products/juggernaut-wall-cat-condo` — «luxury wall-mounted cat tree, offering multiple hammocks, a scratching pole, and a connecting bridge, designed for homes with multiple cats» | **CONFIRMED partial** | The Juggernaut существует как luxury wall-mounted cat tree с несколькими гамаками, скретч-постом и мостиком, для семей с несколькими кошками. Цена $645 из Claude DR не извлечена MCP напрямую, но продукт верифицирован |
| E-XSV-31 | IKEA Lurvig снят с производства, заменён на Utsaedd | Firecrawl search | Pinterest pin «How to Upgrade The IKEA Lurvig Cat House», FabFitFun magazine «IKEA Lurvig Pet Bed»; Reddit discussion из Gemini DR R8 источников | **CONFIRMED partial** | По состоянию на 2026-05-24 признаков активной линии Lurvig нет; Gemini DR ссылается на Reddit-обсуждение и Poshmark-листинг с пометкой «discontinued». Замена на Utsaedd упоминается у Gemini, прямой страницы IKEA через Firecrawl не выгружено. В RESEARCH формулировать как «по состоянию на 2026 серия Lurvig воспринимается как снятая или сворачиваемая; на смену пришли мягкие аксессуары Utsaedd», без жёсткого утверждения «снято с производства» |

### 2.3. Подтверждены через DR-пару без дополнительной MCP-проверки (НИЗКО priority)

| ID | Claim | Источник DR | Решение | Safe wording |
|---|---|---|---|---|
| E-XSV-23 | Pryde Pets полки из recycled bottles, нагрузка 26 lbs (11.8 кг) | Gemini DR R6 | use as-is | «Pryde Pets — настенные полки из переработанных бутылок, заявленная нагрузка ~26 lbs / 11.8 кг» |
| E-XSV-24 | Pet БМФ столбы для замены «от 199₽» | Claude DR R3 + R5 | use as-is | «Pet БМФ — артикулирует S/M/L как ролевую линейку, столбы для замены от 199 ₽» |
| E-XSV-26 | Refined Feline Metropolitan Cat Condo «extra-large platforms 13"×18.5"» | Claude DR R6 | use as-is | «Refined Feline Metropolitan Cat Condo — расширенные платформы 13"×18.5", позиционируется для крупных пород» |
| E-XSV-27 | RINN NEKO €7 700, 22 шт/год лимит | Claude DR R2 + R3 | use as-is | «RINN NEKO — €7 700, лимит 22 изделия в год, Hida craftsmen, мраморное основание» |
| E-XSV-32 | LucyBalu отзывы о «тонких просвечивающих наклейках на винтах» | Gemini DR R7 | use as-is | «В UGC-отзывах на премиальные настенные изделия LucyBalu отмечались просвечивающие маркировочные стикеры на крепеже — типовой риск визуала для премиум-категории» |
| E-XSV-15 (carry-over F1) | Cat Brand (Алтай) экспорт в 10+ стран | F1 watchlist; не упомянут ни Claude, ни Gemini | drop | Не использовать в RESEARCH без подтверждения. Либо повторно поднять в R9-gap |

### 2.4. Дополнительные находки из MCP-pass

| # | Находка | Источник | Использование |
|---|---|---|---|
| A-01 | Catsby Family — выдерживает динамическую нагрузку 30 кг | catsby-family.ru main | factual specs для R5 («прочность»), не было в Claude DR |
| A-02 | Catsby Family — среднее время сборки 12 минут | catsby-family.ru main | factual specs для R5/R7 |
| A-03 | Catsby Family — гипоаллергенный фетр (домик-куб на вершине) | catsby-family.ru main | материал для R5 (расширение списка) |
| A-04 | Catsby Family — биоразлагаемая упаковка как часть оффера | catsby-family.ru main | sustainability оффер |
| A-05 | Catsby Family — Tree 4 уровня = 34 810-35 910 ₽ (вариант «враспор без сверления»); Vine 4 уровня = 32 800-33 680 ₽; Vine 3 уровня = 26 990-27 650 ₽; Vine 2 уровня = 20 740-20 960 ₽; Wall 2-3-4 уровня = 16 460 / 25 000-25 220 / 31 140-31 470 ₽; Stand = 21 790-25 990 ₽ | catsby-family.ru | разводит расхождения 3.1.1 в calibration log: Claude TREE 4 уровня 280-295см = 32 270₽ — это была категоризационная ошибка (VINE, не TREE) |
| A-06 | Catsby Family — каналы связи: WhatsApp, Telegram, **Max** (российский мессенджер) | catsby-family.ru | расширение R7 (каналы коммуникации); подтверждает локальный РФ-фокус |
| A-07 | TAdviser страница доменяет несколько свежих новостей рынка зоотоваров за 2025-2026; список салонов по уходу +15% в 2024 до 2,87 тыс. заведений | tadviser.ru | возможный контекст для M5 (B2B-каналы) |
| A-08 | Salehoo даёт срез цены $19-30 для «cat beds» как ниши плюшевых лежанок; это не покрывает авторский премиум | salehoo.com | важно: сезонность из Salehoo применима к спросу на закрытые/тёплые форматы (зимний пик), не к ценовому позиционированию Alien Cat |

---

## 3. Unresolved gaps (требуют недоступных в текущем стеке инструментов)

| Gap | Что требует | Почему недоступно |
|---|---|---|
| Полный массив SKU маркетплейсов (Ozon/WB/Я.Маркет) с актуальными ценами, рейтингами и числом отзывов | Apify mass scraping | Apify вне текущего MCP-стека |
| UGC-цитаты из отзывов с конкретными URL к отзыву | Apify reviews scraping | то же |
| Wordstat-частотность поисковых запросов («тумба под лоток», «когтеточка для мейн-куна», «настенный комплекс кошки») | Wordstat MCP | вне стека |
| Полная глубокая выгрузка catiocat.ru с прайсом и габаритами (динамические Avito-карточки) | Apify / authenticated session | Firecrawl single scrape не покрыл динамический контент |
| Точная цена «Мы Бобры» бегового колеса «Забава» и других позиций | direct Firecrawl scrape с обходом 404 / каталог-deep-crawl | в этой итерации не достигнута, scrape страницы товара вернул 404 |
| Точные текущие условия рассрочки/доставки по всем игрокам, помимо Catsby | dynamic web (с обходом cookies/popups) | Firecrawl single scrape извлёк только статическую часть |
| Cat Brand (Алтай) — экспорт 10+ стран | дополнительный направленный Firecrawl + Exa pass | не приоритет в этой итерации |

Все эти пункты идут в **R9 internal RESEARCH MD** как «explicit data gaps + tool-wishlist», не как next executable step.

---

## 4. Impact на RESEARCH-BRIEF

### 4.1. Что можно брать без caveat (use as-is в SYNTHESIS-цепочке потом)

- Все 7 подтверждённых гипотез R0.11 (см. calibration log §2.2): S/M/L как роли, сменные элементы, усиление для крупных пород, furniture-first, материалы как доказательность, тумбы/настенные/компактные, упаковка/сервис.
- Все 6 закрытых из F2 baseline + 2 обновлённых (Tadviser 590 млрд, Salehoo пик в ноябре).
- Все 4 КРИТИЧНО из watchlist E-XSV-18, 28, 29, 30 — CONFIRMED.
- Catsby Family: 12000+ комбинаций (не 1000), нагрузка 30 кг, сборка 12 мин, биоразлагаемая упаковка, гипоаллергенный фетр, точная ценовая матрица TREE/VINE/WALL/STAND.
- Salehoo: пик в ноябре, +92% за 2 года, +61.7% за 6 мес — для сегмента $19-30 «cat beds».
- FMI Modern Cat Furniture: USD 5.2B (2025) → 10.3B (2035), CAGR 6.2%, 76% adaptable interior, 72% NA Scandi, 68% EU Scandi, 73% Asia eco, 70% quality materials, 62% multi-functionality, 58% NA smart, 69% online.
- FMI Cat Furniture & Scratchers: 48% modular bespoke.
- Tadviser: рынок зоотоваров РФ 590 млрд ₽ в 2025 (+15.8%), 433 млрд в 2023 (Зооинформ) как историческая база.
- «Мы Бобры»: 5-летняя гарантия — confirmed как маркетинговая позиция, отдельная страница.
- Hunnkatt Ekorn MAX: 25 080 / 27 660 / 29 200 ₽, три варианта.
- Catastrophic Creations The Juggernaut: подтверждён как luxury wall-mounted с гамаками, скретч-постом, мостиком.
- PurrNook Jellyfish: подтверждён как реальный smart-сегмент с motion-sensor light.
- CatioCat: подтверждён как реальный бренд в верхнем ярусе.

### 4.2. Что брать с caveat (формулировать осторожно)

- **«КотаМ 1000 комбинаций»** — не подтверждено MCP, формулировать без числа: «модульная система с возможностью замены отдельных модулей».
- **«Мы Бобры» беговое колесо "Забава" 25 000₽** — товар существует, точная цена не верифицирована в этой итерации; давать диапазон или ссылаться на DR.
- **CatioCat 50-120 тыс ₽** — бренд существует, ценовой диапазон не верифицирован MCP; формулировать как «верхний авторский ярус РФ».
- **PurrNook Jellyfish $289** — продукт существует, цена не верифицирована MCP.
- **Catastrophic Juggernaut $645** — продукт существует, цена не верифицирована MCP.
- **IKEA Lurvig discontinued** — формулировать как «по состоянию на 2026 серия Lurvig воспринимается как снятая или сворачиваемая, на смену пришли мягкие аксессуары Utsaedd».
- **Cat Brand (Алтай) экспорт 10+ стран** — не использовать без новой проверки.
- **Catsby/КотаМ «1000 комбинаций»** в любых внутренних документах — заменить либо на «12000+» (для Catsby с атрибуцией), либо на «модульная система» без числа (для КотаМ).

### 4.3. Что нельзя брать

- F1 watchlist E-XSV-15 (Cat Brand экспорт) — без дополнительной верификации.
- Любые точечные SKU-цены, не подтверждённые ни в одном из источников (Claude DR + Gemini DR + Firecrawl).
- Старые точечные числа из legacy `AlianCat_Product_Synthesis.md` (L4) — остаются reference-only / anti-example.

---

## 5. Корректировки в watchlist для R0.12 internal RESEARCH MD

Финальный watchlist для прозрачности в R9 internal RESEARCH:

- **CONFIRMED:** E-XSV-01, 02, 03, 04, 05 (через F2 + DR-пара), E-XSV-06 (через Tadviser 590 млрд), E-XSV-08 (Murr & Woof — gap, не используется), E-XSV-10, 11, 12, 13, 14 (через Gemini DR), E-XSV-18, 19, 20, 21, 22, 25, 28, 29, 30, 31 (через MCP сейчас).
- **CORRECTED:** E-XSV-16 (Catsby — 12000+ вместо 1000), E-XSV-06 (новая база 590 млрд за 2025 вместо 433 за 2023).
- **REFUTED / DROP:** RHRQuality «единственный в Европе» (refuted), Catsby Vine «19 тыс ₽ старая граница», Tuft+Paw Cove «$599».
- **UNRESOLVED:** E-XSV-15 (Cat Brand экспорт), E-XSV-17 (КотаМ точная цифра комбинаций), E-XSV-09 (Hicat «флагман категории UK» как сильное утверждение).

---

## 6. Final decision

**GO к Step 5 (RESEARCH-BRIEF).**

Обоснование:
1. ✅ Все 4 КРИТИЧНО claims закрыты (CONFIRMED через Firecrawl).
2. ✅ 8 СРЕДНЕ claims проверены: 1 CORRECTED (Catsby «12000+», не «1000»), 6 CONFIRMED полностью или partial, 1 UNRESOLVED (КотаМ точная цифра, обходится формулировкой без числа).
3. ✅ 5 НИЗКО claims приняты use-as-is через DR-пару (Claude × Gemini cross-validation покрывает их).
4. ✅ 8 дополнительных находок MCP-pass (A-01..A-08) добавляют factual specs для R5/R7 и разводят одно расхождение из calibration log (Catsby TREE vs VINE категоризация).
5. ⚠️ 7 gaps вынесены в R9-wishlist как «требуют недоступных tools (Apify / Wordstat / dynamic auth)», что соответствует контракту stack Firecrawl + Exa.
6. ✅ Stop-gate соблюдён: SYNTHESIS / client-md / HTML-BRIEF / HTML / publish — заблокированы.

**CONDITIONAL GO снят. Полный GO к RESEARCH-BRIEF на следующем шаге по команде Димы.**

---

## 7. Ledger update

| Step | Status | Evidence |
|---|---|---|
| Step 4 Targeted MCP | **DONE** (Firecrawl + Exa, см. этот файл) | `M2-03-TARGETED-MCP-RESULTS.md` |
| Step 5a RESEARCH-BRIEF | **READY** (ожидает команды Димы) | inputs готовы: calibration log §6 + MCP results |
| Step 5b Internal RESEARCH MD | BLOCKED (после 5a) | — |
| Step 5c LANGUAGE_TECH + READER_SANITY + MD_ACCEPTED | BLOCKED (после 5b) | — |
| SYNTHESIS / client-md / HTML-BRIEF / HTML / publish | HARD-BLOCKED | client-facing stop-gate |

---

*MCP-pass by Claude · 2026-05-24 · Firecrawl + Exa only · stop-gate respected*
