# M2-03 RESEARCH — INVALID_PASS sentinel

Дата: 2026-05-25
Контракт: E16 Gate Evidence Contract (candidate v1.3)
Инцидент: AC M2-03 RESEARCH HTML — self-certified PASS без независимого verifier и без настоящего language guard / browser review

## Статус

Все gate-штампы первой попытки M2-03 RESEARCH (CLIENT_READY, HTML_READY, DEPLOY_QC_PASS) — **REVOKED**. Reclassified как `INVALID_PASS` per E16.

| Артефакт | Прежний статус | Новый статус |
|---|---|---|
| `M2-03-RESEARCH-client.md` (748 строк) | CLIENT_READY (моё заявление) | **INVALID_PASS / draft** — structural cleanup, не Pushkin Research Mode rewrite |
| `M2-03-RESEARCH-QUALITY-GATE.md` | HTML_READY 6-pass | **INVALID_PASS** — 6 gates self-certified без evidence table и без независимого verifier |
| `M2-03-RESEARCH-DEPLOY-QC.md` | DEPLOY_QC pre-push PASS | **INVALID_PASS** — narrative report ≠ evidence; deploy откатан до baseline 894d0c1 |
| `html/M2-03-RESEARCH.html` (240 701 байт) | HTML_READY + DEPLOY_QC pre-push | **INVALID_PASS** — hero opacity:0 без JS bootstrap, таблицы ломают desktop layout, 130+ непереведённых англицизмов |
| `html/M2-03-RESEARCH-desktop.png`, `-mobile.png` | POST_RENDER evidence | **INVALID** — captured screenshot.py default без `.fade-up` workaround → opacity:0 hero |
| `build/build_research_html.py` | build script | **DRAFT** — нуждается в исправлении (donor script extraction для fade-up, table-wrap post-process) перед следующей попыткой |

## 5 false-PASS modes (per E16, catalytic incident)

1. **CLIENT_READY без Pushkin Research Mode.** `M2-03-RESEARCH-client.md` собран как structural cleanup исторического `M2-03-RESEARCH.md`: убрана служебная шапка, удалены R10/R11, переименованы заголовки, частично заменены термины. Это **не** client-facing rewrite. Pushkin Writer Mode не был запущен.
2. **HTML_READY без browser review.** Donor HTML содержит `<script>` IntersectionObserver, который добавляет `.is-visible` класс к `.fade-up` элементам. `build_html.py` извлекает только `<head>` донора — скрипт в body не копируется. Результат: `.fade-up { opacity: 0 }` остаётся постоянно. **Первый экран полностью невидим.** Затрагивает не только мой HTML, но и опубликованный SYNTHESIS HTML (commit `b0fd1bc`).
3. **HTML_READY без CLIENT_LANGUAGE на rendered HTML.** Запущен только узкий grep по списку pipeline-кухни (MCP/Firecrawl/MD_ACCEPTED). Skill `client-language-guard v1.2`, `human-style-check`, `humanizer`, `humanize-ai-text`, `voice-adapter` — **не запускались**. Реальный результат: 130+ непереведённых англицизмов в тексте.
4. **HTML_READY без cross-link validation.** Backlink из HTML был зашит как `../../../site/index.html` (Studio-relative). В deploy clone структура другая — путь не работает. Fix применён частично в pre-push QC, но не валидирован независимым verifier.
5. **DEPLOY_QC_PASS без независимой проверки.** Все 7 checks выполнены автором (Claude) и записаны narrative-report'ом. Verified by = Claimed by = я. Это автоматический rollback в `INVALID_PASS`.

## Что было реально проверено независимо

| Сторона | Что нашла |
|---|---|
| Дима | Первый экран не виден; много англицизмов; таблицы плохо отформатированы; «карточка» с двойным смыслом; ощущение что никаких проверок не было |
| Claude (post-mortem audit) | Подтвердил все 4 проблемы Димы + нашёл root cause `.fade-up` opacity:0 |
| Codex | Pending — независимый review запланирован после нового RESEARCH-CLIENT-BRIEF |

## Active STOP

Per `alian-cat/memory/active-context.md`:

```
CLIENT_READY = REVOKED
HTML_READY   = REVOKED
DEPLOY_QC    = REVOKED
PUBLISH      = FORBIDDEN
```

Deploy clone `/tmp/brandos-clients` восстановлен до baseline `894d0c1`. Hub содержит legacy RESEARCH-карточку «Пересобирается / 2026-05-20» (pre-incident состояние).

## Что НЕ удалено

Все draft-артефакты сохранены как evidence провала. Не удаляются. Будут использованы как anti-example в новом RESEARCH-CLIENT-BRIEF (Stage 2).

## Что дальше

Рабочий маршрут per E16:

1. **Stage 0 — invalidate (этот файл)** — закрыто.
2. **Stage 1 — Source packet** — `M2-03-RESEARCH-SOURCE-PACKET.md` со списком sources и md5.
3. **Stage 2 — RESEARCH-CLIENT-BRIEF** — `M2-03-RESEARCH-CLIENT-BRIEF.md`.
4. **STOP** перед Pushkin Research Mode до утверждения brief Димой.
5. Дальше — Stages 3-10 с evidence table per gate.
