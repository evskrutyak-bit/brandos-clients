# M2-03 SYNTHESIS HTML — micro-fix (reveal/fade-up), 2026-06-05

**Тип:** micro-fix HTML, **НЕ новая редакция синтеза.** Содержание SYNTHESIS не менялось, `M2-03-SYNTHESIS.md` не тронут.
**Verdict:** `HTML_FIXED` — **CLAIMED_PASS (AI-side, provisional до owner eye-check)**

## Проблема (E16-инцидент, подтверждена screenshot)
Весь hero обёрнут в один `.fade-up{opacity:0}`, а reveal-скрипт (IntersectionObserver, добавляющий `.is-visible`) **отсутствовал** в body (build_html.py копировал только `<head>` донора). Итог: первый экран задеплоенного SYNTHESIS — тёмный пустой блок. Подтверждено: hero_fadeup_opacity=0, is_visible=0.

## Фикс (только reveal, без контента)
1. Добавлен reveal-скрипт перед `</body>`: IntersectionObserver `threshold:0` → `classList.add('is-visible')` для всех `.fade-up`; fallback (если нет IntersectionObserver — сразу is-visible).
2. Добавлен provenance `built_from_client_md_hash: 534e6bccdb6745aa` (= sha256[:16] от текущего `M2-03-SYNTHESIS.md`; раньше отсутствовал).
Контент, тексты, CSS-структура, SYNTHESIS.md — без изменений.

## 6-check (фокус — видимость hero)
| Check | Результат |
|---|---|
| TECH | ✅ `<script>` сбалансирован, provenance, charset |
| CONTENT_SYNC | ✅ контент не менялся; provenance == SYNTHESIS.md |
| CLIENT_LANGUAGE | ✅ текст не менялся (был принят ранее) |
| POST_RENDER | ✅ **0 JS console errors / 0 pageerror** |
| VISUAL_SMOKE / VISIBILITY | ✅ **hero виден desktop (1440) И mobile (390)**: `.fade-up` opacity=1, is-visible=true |
| DESIGN_REVIEW | ✅ глазами — первый экран (h1 + lede + stat-grid) виден |

## Что НЕ сделано
Deploy/hub — нет (после owner eye-check, Codex). SYNTHESIS.md не трогался.
