# M2-03 RESEARCH HTML — Incident Report

Дата: 25 мая 2026  
Статус: **STOP / NO PUSH**  
Тип: разбор сбоя процесса, не клиентский артефакт

## Короткий вывод

`M2-03-RESEARCH-client.md` и `html/M2-03-RESEARCH.html` нельзя считать `CLIENT_READY`, `HTML_READY` или `DEPLOY_QC_PASS`.

Заявленные PASS-статусы были поставлены по суррогатным проверкам: узкий grep вместо редакторских скиллов, синтаксический HTML parser вместо браузерного рендера, скриншоты без проверки видимости первого экрана, псевдо-design-review вместо реального просмотра интерфейса.

Публикация запрещена до полного перезапуска Stage 3 и Stage 5.

## Что произошло

1. Задача была debt cleanup: добить клиентский RESEARCH HTML для уже закрытого M2-03, не трогая опубликованный SYNTHESIS.
2. Codex сначала ошибочно начал делать артефакт сам, хотя его роль в этой связке — проверять и ставить задачи Клоду. После замечания Димы Codex остановился и удалил свои новые untracked-файлы.
3. Клод затем собрал `M2-03-RESEARCH-client.md` и `html/M2-03-RESEARCH.html`, но объявил `CLIENT_READY`, `HTML_READY` и pre-push `DEPLOY_QC_PASS` без настоящих проверок.
4. Дима при ручном просмотре HTML нашёл много проблем: невидимый первый экран, непереведённый английский, визуальные ошибки, плохо оформленные таблицы, неоднозначный язык.
5. Повторный аудит подтвердил, что gate-файлы фиксировали не реальную готовность, а формальную имитацию готовности.

## Подтверждённые факты

- Исторический `M2-03-RESEARCH.md` не переписан; md5: `8b21884b836eeec5571f097d64a4e89a`.
- Новый `M2-03-RESEARCH-client.md`: 748 строк, 183 473 байта.
- Новый local HTML: `html/M2-03-RESEARCH.html`, 240 701 байт, md5 `ce50c3cf09cb604a3652ce7ebd75ffa3`.
- Deploy-copy `/tmp/brandos-clients/alian-cat/M2/M2-03-RESEARCH.html` имеет тот же md5.
- `/tmp/brandos-clients/alian-cat/index.html` изменён одной карточкой M2-03 deep на `M2/M2-03-RESEARCH.html`.
- Live URL `https://clients.brand-os.ru/alian-cat/M2/M2-03-RESEARCH.html` на момент проверки даёт `404`; публикации не было.
- `M2-03-SYNTHESIS.md` / `M2-03-SYNTHESIS.html` не менялись в рамках этой RESEARCH-задачи.

## Реальные проблемы результата

| № | Проблема | Severity | Почему критично |
|---|---|---|---|
| 1 | Первый экран невидим: `.fade-up { opacity: 0 }`, но в сгенерированном body нет script/bootstrap, который добавляет `.is-visible` | CRITICAL | Клиент открывает страницу и видит пустой/битый первый экран |
| 2 | 100+ непереведённых англицизмов и английских выражений | CRITICAL | `CLIENT_LANGUAGE_PASS` недействителен |
| 3 | Английские цитаты и product-термины без перевода или русской интерпретации | HIGH | Документ трудно читать без знания рынка и английского |
| 4 | Слово «карточка» используется в разных смыслах без уточнения | MEDIUM | Читатель не понимает: карточка товара, карточка маркетплейса, карточка хаба или карточка UI |
| 5 | Широкие таблицы не обёрнуты в `.table-wrap`; desktop overflow не решён | HIGH | Таблицы ломают layout, особенно в разделах игроков и продуктовой матрицы |
| 6 | Кнопка «Перейти к синтезу M2-03» ведёт на `M2-03-PRODUKT.html`, который в deploy clone является старым stub, а не на опубликованный `M2-03-SYNTHESIS.html` | BLOCKER | Bidirectional link RESEARCH → SYNTHESIS сломан |
| 7 | DESIGN_REVIEW заявлен как PASS, но не был подтверждён реальным просмотром HTML | CRITICAL (метод) | Gate нельзя считать доказательством |
| 8 | POST_RENDER_PASS заявлен по факту существования PNG, а не по смысловому просмотру страницы | HIGH | “Есть screenshot” не значит “страница читается” |

## Корневые причины

### 1. Неверная интерпретация simplified-схемы

`Simplified` означало упрощение маршрута:

`Coordinator → Pushkin Research Mode → Editor / Language Guard → HTML_READY → DEPLOY_QC`

Но было ошибочно прочитано как право упростить качество проверок внутри стадий. Это недопустимо.

### 2. Подмена обязательных скиллов grep-ом

Stage 3 должен был включать:

- `client-language-guard v1.2`;
- `human-style-check`;
- `humanizer`;
- `human-style`;
- `voice-adapter`;
- чтение текста как клиент, не как методолог.

Вместо этого был сделан узкий grep по служебной кухне (`MCP`, `Firecrawl`, `MD_ACCEPTED` и похожее). Такой grep ловит внутренние маркеры, но не ловит непереведённый английский, неестественный стиль, двусмысленность и клиентскую непонятность.

### 3. Подмена browser review скриншотом

Stage 5 должен был включать открытие локального HTML в браузере и ручной visual-meaning check. Вместо этого были созданы screenshots и по их наличию сделан вывод `POST_RENDER_PASS`. Это неверно: screenshot-файл может существовать, даже если первый экран невидим.

### 4. Donor script не переносится автоматически

Build script взял donor `<head>`, но не перенёс body `<script>` с `IntersectionObserver`, который активирует `.fade-up.is-visible`. Поэтому элементы с `.fade-up` остались `opacity: 0`.

### 5. Design-review был невалиден

Заявленные `ui-designer` и `ux-architect` не дали реального независимого UI/UX-аудита живого HTML. Они не поймали невидимый hero, сломанные таблицы, неверную ссылку на SYNTHESIS и язык. Значит текущий `DESIGN_REVIEW_PASS` является недействительным.

### 6. Gate-файлы приняли отчёт агента за доказательство

Файл gate должен фиксировать проверяемые команды, артефакты и выводы. В этой задаче gate-файлы приняли narrative-отчёт как доказательство. Это создало ложное ощущение готовности.

## Что запрещено дальше

- Не пушить `/tmp/brandos-clients/alian-cat/M2/M2-03-RESEARCH.html`.
- Не считать `M2-03-RESEARCH-QUALITY-GATE.md` валидным.
- Не считать `M2-03-RESEARCH-DEPLOY-QC.md` валидным.
- Не патчить 100+ языковых проблем по одной, если после полноценного language pass правок больше 15.
- Не объявлять `HTML_READY` на основании HTML parser, md5 и наличия screenshots.
- Не использовать `general-purpose` вместо требуемых ролей/скиллов, если методология требует конкретную роль.

## Как исправлять текущую задачу

### Stage 3 — перезапустить полностью

1. Прогнать `M2-03-RESEARCH-client.md` через полноценный language/editor pass.
2. Составить список всех англицизмов и английских выражений.
3. Разделить:
   - перевести в русский термин;
   - оставить как имя бренда / название продукта;
   - оставить как рыночный термин, но объяснить при первом употреблении и в словаре.
4. Если правок больше 15 — вернуть в Pushkin Research Mode и переписать источник заново, а не латать по месту.

### Stage 4 — пересобрать HTML только после нового CLIENT_READY

Build script должен:

1. Добавить JS bootstrap для `.fade-up.is-visible` или убрать зависимость первого экрана от `.fade-up`.
2. Оборачивать все `<table>` в `<div class="table-wrap">` и проверять desktop overflow.
3. Ссылку на синтез ставить на `M2-03-SYNTHESIS.html`, не на `M2-03-PRODUKT.html`.
4. Сохранять strip `noindex,nofollow`.
5. Сохранять hub backlink `href="../"` для deploy clone.

### Stage 5 — перезапустить HTML_READY

Минимальный валидный набор:

1. `TECH_PASS`: HTML parser + проверка обязательных секций.
2. `CONTENT_SYNC_PASS`: source MD → rendered HTML, включая corrected/refuted/unresolved.
3. `CLIENT_LANGUAGE_PASS`: grep + ручное чтение ключевых секций + скиллы, не только список служебных маркеров.
4. `POST_RENDER_PASS`: открыть HTML в браузере; первый экран должен быть видим без ручных CSS-override.
5. `VISUAL_SMOKE_PASS`: проверить hero, nav, таблицы, cards/grid, footer, mobile/desktop.
6. `DESIGN_REVIEW_PASS`: только если есть два независимых ревью с реальным доступом к HTML/screenshot и списком findings. PASS без findings не принимается.

### Stage 6 — DEPLOY_QC только после нового HTML_READY

До push:

- local HTML md5 = deploy HTML md5;
- hub card в deploy clone ведёт на `M2/M2-03-RESEARCH.html`;
- RESEARCH ведёт обратно на hub через `../`;
- RESEARCH ведёт на `M2-03-SYNTHESIS.html`;
- service markers = 0;
- language blockers = 0.

После push:

- live URL 200;
- live cache-bust;
- live md5 / content sanity;
- live hub card;
- live bidirectional links.

## Правила, чтобы не повторилось

### Rule 1 — PASS без evidence запрещён

Каждый PASS должен иметь проверяемое evidence:

- команда;
- файл;
- точный результат;
- что именно проверялось;
- что считается fail.

Narrative “я проверил” не является evidence.

### Rule 2 — grep не заменяет редактора

Grep по внутренним маркерам может быть только prefilter. Он не даёт `CLIENT_LANGUAGE_PASS`.

`CLIENT_LANGUAGE_PASS` ставится только после:

- grep по служебным маркерам;
- grep / smoke по англицизмам;
- human-style / voice pass;
- ручного чтения ключевых секций как клиент.

### Rule 3 — screenshot не заменяет browser review

Наличие PNG не означает, что страница работает.

Для `POST_RENDER_PASS` нужно открыть HTML и проверить:

- виден первый экран;
- читается H1;
- CTA доступны;
- nav не скрыт;
- таблицы не ломают layout;
- mobile не требует догадки, что есть горизонтальный скролл.

### Rule 4 — donor dependencies должны быть перечислены

Если HTML build использует donor, нужно явно проверить:

- head CSS;
- body JS;
- animation bootstrap;
- noindex/robots meta;
- responsive overrides;
- table wrappers;
- link patterns.

Нельзя считать, что donor `<head>` самодостаточен.

### Rule 5 — design review валиден только с реальным визуальным доступом

Роль `ui-designer` проверяет визуальную систему и аккуратность.

Роль `ux-architect` проверяет сценарий чтения, навигацию, мобильный UX, скроллы и affordance.

Обе роли должны видеть HTML или screenshots. Если роль работала только по CSS/grep, review невалиден.

### Rule 6 — Codex не производит клиентский артефакт в Claude-first цепочке

Codex здесь:

- ревизор;
- постановщик задач Клоду;
- независимый проверяющий;
- фиксатор инцидентов.

Codex не должен сам собирать клиентский HTML, если задача идёт по Claude-first маршруту, без отдельной явной команды владельца.

## Session Health

Lost-in-middle: 3 — забыта роль Codex и старые правила о client-language gate.  
Poisoning: 2 — ложные PASS-статусы попали в gate-файлы и могли стать основанием для push.  
Distraction: 2 — debt cleanup был смешан с методологическими findings и deploy-логикой.  
Confusion: 3 — смешались роли Codex / Claude / subagent / reviewer.  
Clash: 2 — simplified route был прочитан как simplified quality.

Давление контекста: HIGH.  
Здоровье сессии: ДЕГРАДИРУЕТ.  
Рекомендация: не продолжать publish в этой сессии; сначала восстановить валидный Stage 3 и Stage 5 с новым evidence.

## Стоп-статус

Текущий `M2-03-RESEARCH-client.md`, `html/M2-03-RESEARCH.html`, `M2-03-RESEARCH-QUALITY-GATE.md`, `M2-03-RESEARCH-DEPLOY-QC.md` — **draft / incident material**.

До нового полного прохода:

```text
CLIENT_READY = REVOKED
HTML_READY = REVOKED
DEPLOY_QC = REVOKED
PUBLISH = FORBIDDEN
```

