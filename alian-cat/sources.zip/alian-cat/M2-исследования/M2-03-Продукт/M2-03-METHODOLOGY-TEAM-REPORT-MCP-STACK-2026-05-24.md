# Отчёт методологической команде от рабочей команды Alien Cat — MCP stack drift в M2-03

Дата: 2026-05-24  
Проект: Alien Cat / M2-03 Product  
От кого: рабочая команда, которая сейчас ведёт проект Alien Cat и transfer-test M2-03  
Кому: методологическая команда, которая правит M2 pipeline / candidate v1.2  
Роль Codex: фиксация противоречий и постановка задачи. Не исправлять методологию вместо команды.

## Коротко

Это не абстрактное замечание к документации. Это практический блокер, обнаруженный в живой работе по Alien Cat M2-03 Product.

В M2-03 обнаружен drift между старой инструментальной логикой и текущим MCP-контуром.

## Current MCP Stack Declaration

Дата: 2026-05-24  
Проект: Alien Cat M2-03 Product

Available now:

- Exa — web/source discovery
- Firecrawl — search/map/scrape/extract

Historical baseline:

- Tavily outputs from previous project layers, if already saved on disk

Unavailable in current session:

- Apify marketplace scraping
- Wordstat exact demand frequency
- Tavily live re-check
- Legacy WebFetch wording as executable command

Rule:

Unavailable tools cannot appear as executable steps. They may appear only as gaps / wishlist / historical reference.

Старые материалы и raw DR местами предлагают:

- Tavily как recheck/fact-check инструмент;
- Apify для Ozon/WB/Avito scraping;
- Wordstat для частотности запросов;
- WebFetch как отдельный инструмент.

Текущий доступный/подключённый контур в этой сессии:

- Firecrawl;
- Exa.

Вывод: Wordstat / Apify / Tavily нельзя оставлять как executable default в task briefs, salvage audit, runbook и prompt-шаблонах. Их можно фиксировать только как historical baseline или tool-wishlist/gap.

## Что уже важно для Alien Cat M2-03

M2-03 сейчас идёт как transfer-test candidate v1.2 и salvage-first.

Уже есть новые raw inputs:

- Claude Deep Research: `DR-SOURCES/raw-claude-deepresearch-product-2026-05-24.md`
- Gemini: `DR-SOURCES/raw-gemini-product-2026-05-24.docx`
- Gemini extracted: `DR-SOURCES/raw-gemini-product-extracted-2026-05-24.txt`

Оба новых исследования сами предлагают добор через Apify/Wordstat. Это нельзя принимать как рабочую инструкцию, потому что текущий MCP-контур другой.

## Где конфликт

### 1. Historical Tavily vs current MCP

Файл старого fact-check:

- `M2-исследования/_fact-check/M2-03-PRODUCT-MCP-RESULTS.md`

Это Tavily-эпоха. Он полезен как historical baseline по 6 уже проверенным claims, но не должен задавать текущий маршрут recheck.

Правильная формулировка:

```text
Historical Tavily baseline: можно использовать как guardrail.
New targeted MCP / recheck: Firecrawl + Exa.
```

Неправильная формулировка:

```text
Повторная Tavily-сверка перед использованием.
```

### 2. Apify as default scraping tool

Raw DR и старые рабочие заметки предлагают:

- Apify для Ozon/WB scraping;
- Apify для Avito;
- Apify для UGC reviews.

Если Apify не подключён как текущий доступный инструмент, это не может быть next executable step.

Правильная формулировка:

```text
Проверить через Firecrawl/Exa всё, что доступно в публичном вебе.
Если marketplace/Avito/UGC не достаются текущими инструментами — зафиксировать gap/tool-wishlist: requires Apify-like marketplace scraper.
```

### 3. Wordstat as default demand tool

Raw DR предлагает Wordstat для:

- “мебель для мейн-куна”;
- “тумба под лоток”;
- “мебель для кошек”;
- других продуктовых запросов.

Если Wordstat MCP не подключён, это не рабочий шаг.

Правильная формулировка:

```text
Search demand validation: gap/tool-wishlist unless Wordstat/Yandex demand source is explicitly available.
Exa can find public demand proxies, but not replace Wordstat as exact frequency source.
```

### 4. WebFetch wording

В старых материалах встречается WebFetch как будто это отдельный рабочий инструмент.

В текущем контуре это нужно заменить на:

```text
Firecrawl scrape/map/search + Exa search/source discovery.
```

## Что методологической команде нужно исправить

### A. В candidate v1.2 / M2 structure

Добавить явное правило:

```text
MCP step must be tool-availability aware.
Do not name unavailable tools as executable steps.
If a needed capability is unavailable, record it as gap/tool-wishlist, not as instruction.
```

### B. В runbook M2 text→visual

В разделе source verification / targeted MCP добавить слой:

```text
Current MCP stack declaration:
- actual tools available in session;
- historical baselines;
- unavailable desired capabilities.
```

### C. В шаблоны DR / RESEARCH-BRIEF / MCP-INSTRUCTION

Заменить hardcoded tool names на capability labels:

| Capability | Allowed current implementation | If unavailable |
|---|---|---|
| Web search / source discovery | Exa | record gap |
| Page scrape / catalog page extraction | Firecrawl | record gap |
| Marketplace structured scraping | only if tool available | gap/tool-wishlist |
| Search demand frequency | only if Wordstat/source available | gap/tool-wishlist |
| Historical fact-check baseline | old Tavily outputs if present | do not re-run as default |

### D. В salvage audit template

Раздел “Targeted MCP” должен требовать:

1. сначала перечислить доступные инструменты;
2. потом перечислить claims;
3. потом назначить для каждого claim доступный способ проверки;
4. всё, что не проверяется текущими инструментами, вынести в gap.

### E. В raw DR processing

Добавить правило:

```text
LLM/DR recommendations about tools are advisory only.
They do not override current environment tool availability.
```

То есть если Claude/Gemini пишет “нужен Apify / Wordstat”, это не команда запускать Apify/Wordstat. Это сигнал о gap.

## Практическое решение для Alien Cat M2-03

Для M2-03 сейчас:

1. Не запускать новый full DR.
2. Не исполнять Apify/Wordstat/Tavily как default.
3. Использовать Claude DR + Gemini как raw inputs.
4. Сформировать accepted source packet только после targeted verification.
5. Targeted verification делать через Firecrawl + Exa.
6. Всё, что требует marketplace scraping / exact Wordstat frequency, пометить как unresolved gap unless tool becomes available.

## Acceptance criteria для методологической правки

Методология считается выровненной, если:

- в новых task briefs нет “Tavily recheck” как default;
- Apify/Wordstat не фигурируют как обязательные next steps без проверки доступности;
- Firecrawl + Exa указаны как текущий рабочий стек там, где речь о M2-03 в этой сессии;
- tool-wishlist/gap отделён от executable MCP instruction;
- historical fact-check отделён от current verification;
- raw DR не может диктовать инструментальный маршрут.

## Короткая задача для команды

```text
Методологическая команда, проверьте M2 pipeline candidate v1.2, salvage audit template, MCP-INSTRUCTION template, DR prompt templates и text→visual runbook на hardcoded tool drift.

Нужно заменить Tavily/Apify/Wordstat/WebFetch как default executable steps на capability-based wording с Current MCP stack declaration.

Для текущего Alien Cat M2-03 рабочий стек: Firecrawl + Exa.
Tavily = historical baseline only.
Apify/Wordstat = gap/tool-wishlist unless explicitly available.

Цель: чтобы клон не получил команду запускать несуществующий инструмент и не считал raw DR tool recommendations методологическим каноном.
```
