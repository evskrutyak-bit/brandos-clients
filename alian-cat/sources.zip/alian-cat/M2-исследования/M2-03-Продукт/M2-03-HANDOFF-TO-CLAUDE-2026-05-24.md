# M2-03 Handoff to Claude — session recovery

Дата: 2026-05-24  
Проект: Alien Cat / `~/studio/neyroupakovka/alian-cat/`  
Текущий модуль: M2-03 Product  
Статус: transfer-test `candidate v1.2`, Step 2 pending  

---

## 1. Что случилось

Claude session dropped. Нужно восстановить контекст и продолжить M2-03 без отката к старому pipeline.

Ключевое: **M2-03 не продолжается из старого `AlianCat_Product_Synthesis.md`.** Старый product-layer считается legacy/reference/anti-example.

---

## 2. Роли

- Claude: смысл, методология, архитектура, постановка задач, смысловое ревью.
- Codex: файлы, структура, проверки, HTML/Hub/deploy позже, инженерное ревью.

В M2-03 сейчас Codex уже сделал файловый старт, prompt pack и stop gates. Claude должен продолжать смысловой/методологический pipeline, но не создавать client-facing layers.

---

## 3. Что уже сделано

### Новая рабочая папка

`M2-исследования/M2-03-Продукт/`

Созданы файлы:

- `README.md` — карта нового M2-03.
- `M2-03-START-BRIEF-FOR-CLAUDE.md` — стартовый brief для Claude.
- `M2-03-DR-PROMPT-CHECK.md` — checks для Step 1 prompt.
- `M2-03-DR-UPLOAD-PACK.md` — инструкция по upload-pack для Deep Research.
- `M2-03-PROGRESS-LEDGER.md` — текущий progress ledger.
- `M2-03-STOP-GATE.md` — user stop-rule.
- `DR-SOURCES/README.md` — куда класть raw DR outputs.
- `M2-03-HANDOFF-TO-CLAUDE-2026-05-24.md` — этот файл.

### Root prompt folders

- `prompts/M2-03-DR-PROMPT.md` — готовый Step 1 prompt, 499 строк.
- `prompts-history/README.md` — история prompt.

### Desktop upload pack

Собран пакет для запуска Deep Research:

`/Users/admin/Desktop/AlienCat-M2-03-DR-upload-pack/`

Внутри:

- `00-INSTRUCTIONS.md`
- `01-M2-03-DR-PROMPT-RUNTIME.md`
- `02-upload-files/` с 13 файлами контекста.

---

## 4. Проверки Step 1

`prompts/M2-03-DR-PROMPT.md` прошёл проверки:

- root path: PASS.
- основан на `dr-prompt-produkt.md` Profile E.
- R0.2 использует M2-01 РФ и M2-02 Мир как уже закрытые слои.
- незаполненных `{...}` нет.
- HTML-комментариев нет.
- старого terminal naming `FINAL-client`, `M2-03-FINAL`, `FINAL.md` нет.
- есть paired DR instruction.
- DR/MCP boundary прописана.
- legacy M2-03 suspicious claims включены в R0.12.

---

## 5. Текущий статус

`DR-SOURCES/` пока пустой, кроме README.

Ожидаемые raw outputs:

- `raw-gpt-2026-05-24.md` или `raw-gpt-YYYY-MM-DD.md`
- `raw-gemini-2026-05-24.md` или `raw-gemini-YYYY-MM-DD.md`
- optional: `raw-claude-2026-05-24.md`

Обязательная paired-пара: **GPT + Gemini**. Claude Deep Research — optional third opinion.

Пока raw GPT/Gemini отсутствуют:

- calibration BLOCKED;
- MCP instruction BLOCKED;
- RESEARCH-BRIEF BLOCKED;
- internal RESEARCH BLOCKED.

Не имитировать RESEARCH без raw DR.

---

## 6. User stop-rule

User разрешил:

- DR / source intake;
- normalization;
- calibration;
- MCP instruction;
- MCP collection / evaluation;
- RESEARCH-BRIEF;
- internal RESEARCH;
- MD_ACCEPTED check for RESEARCH.

User запретил до отдельного разрешения:

- `SYNTHESIS.md`;
- client-md;
- HTML-BRIEF;
- HTML;
- hub publish.

Stop before any client-facing layer.

---

## 7. После RESEARCH MD_ACCEPTED

Once RESEARCH is `MD_ACCEPTED`, switch to:

`~/studio/methodology/m2-deep-research/01-working/m2-text-then-visual-runbook.md`

Do not produce client-facing SYNTHESIS or HTML with the old pipeline.

Новая цепочка после MD_ACCEPTED:

```text
Source MD lock
  -> text / editorial pass
  -> CLIENT_READY
  -> HTML build / sync
  -> UX / UI / Visual review
  -> HTML_READY
  -> DEPLOY_QC
  -> publish
```

Но сейчас до этой точки ещё далеко: нужен DR -> calibration -> MCP -> RESEARCH-BRIEF -> internal RESEARCH -> MD_ACCEPTED.

---

## 8. Legacy layer

Не продолжать и не брать как source of truth:

- `M2-исследования/продукт/AlianCat_Product_Synthesis.md`
- `M2-исследования/продукт/AlianCat_Product_Synthesis.html`
- `M2-исследования/продукт/DR продукn AlianCat.md`
- `M2-исследования/продукт/DR_продукт AlianCat.html`
- `site/M2/M2-03-PRODUKT-DR.html`
- `site/M2/M2-03-PRODUKT.html`

Можно использовать legacy только как:

- anti-example;
- watchlist старых claims;
- reference на то, что НЕ переносить.

---

## 9. Следующий разрешённый шаг

Если Дима уже запустил Deep Research и принёс raw outputs:

1. положить их в `M2-исследования/M2-03-Продукт/DR-SOURCES/`;
2. нормализовать имена;
3. прочитать оба файла полностью;
4. собрать `M2-03-CALIBRATION-LOG.md`:
   - cross-check GPT vs Gemini;
   - что совпало;
   - что конфликтует;
   - hallucination/suspicious claims;
   - gaps for MCP;
   - решение GO / CONDITIONAL GO / NO GO для MCP.

Если raw outputs ещё не готовы:

Сообщить Диме: «Ждём raw GPT + Gemini DR outputs. Пока можно только запускать Deep Research из Desktop upload pack».

---

## 10. Короткое сообщение Клоду

Клод, ты восстановился в Alien Cat M2-03 Product. Мы не продолжаем старый `AlianCat_Product_Synthesis.md`. Новый M2-03 идёт как transfer-test `candidate v1.2`. Step 1 уже готов: `prompts/M2-03-DR-PROMPT.md`, upload pack лежит на Desktop. Сейчас ждём raw GPT + Gemini Deep Research outputs в `M2-исследования/M2-03-Продукт/DR-SOURCES/`. Разрешено идти только до DR / calibration / MCP / RESEARCH-BRIEF / internal RESEARCH / RESEARCH MD_ACCEPTED. Запрещены `SYNTHESIS.md`, client-md, HTML-BRIEF, HTML и hub publish. После RESEARCH MD_ACCEPTED переключаемся на `m2-text-then-visual-runbook.md`; старый client-facing pipeline не использовать.

