# M2-03 RESEARCH — Deploy Handoff для Codex (2026-06-06)

> ⚠️ Заменяет `M2-03-RESEARCH-DEPLOY-QC.md` (тот = INVALID_PASS, evidence инцидента E16 2026-05-25). Теперь артефакт OWNER_ACCEPTED с валидной provenance — deploy разрешён.

## Статус
- **Owner eye-check PASS 2026-06-06.** Verdict: OWNER_ACCEPTED, final.
- Артефакт собирал и верифицировал Claude. **Deploy/hub/push — Codex** (по канону `feedback_codex_artefact_handoff`).

## Что деплоить

| Параметр | Значение |
|---|---|
| Source (Studio) | `M2-исследования/M2-03-Продукт/html/M2-03-RESEARCH.html` |
| Provenance | `built_from_client_md_hash: 3b3b2b1a8b770237` (== sha256[:16] от `M2-03-RESEARCH-client.md`) |
| HTML md5 | `b4cbaf77c6aeaeb094c9550e55b947db` |
| HTML sha256[:16] | `d54ecf04f68e4f65` |
| Размер | 218 619 байт |
| Target (deploy clone) | `/tmp/brandos-clients/alian-cat/M2/M2-03-RESEARCH.html` |
| Remote | `evskrutyak-bit/brandos-clients`, branch `main` |

## Два изменения в deploy clone

1. **Новый/перезаписать файл:** `alian-cat/M2/M2-03-RESEARCH.html` ← копия source (md5 должен совпасть после копирования: `b4cbaf77c6aeaeb094c9550e55b947db`).
2. **Hub-карточка «M2-03 · Глубокое»** в `alian-cat/index.html`: перевести ссылку со старого stub `M2/M2-03-PRODUKT-DR.html` → `M2/M2-03-RESEARCH.html`; обновить `data-status`/`data-date`/`data-version` и `card-desc` под фактический документ (как уже сделано для соседней карточки «M2-03 · Синтез», которая live).

> Контекст hub: SYNTHESIS («M2-03 · Синтез» → `M2-03-SYNTHESIS.html`) уже live (commit `b0fd1bc`). Этот deploy добавляет RESEARCH рядом.

## E16 Deploy QC rail (Codex прогоняет после push — Verifier ≠ Builder)
1. md5 source == deploy copy == (после push) live — три точки совпадают.
2. Live URL отдаёт 200.
3. Hub card grep `href="M2/M2-03-RESEARCH.html"` = 1 hit; старый `M2-03-PRODUKT-DR.html` в этой карточке = 0.
4. Cache-bust: live hash после `?v=<commit>` == deploy hash.
5. Live language grep = 0 (кухня/выгрузк/MCP/DR/pipeline/Wordstat/scrape и т.д.).
6. Service markers (noindex, draft, `<!--` лишние, TODO, [INTERNAL]) = 0.
7. Bidirectional links: hub → RESEARCH = 1; RESEARCH → hub («К хабу клиента →» toplink + nav «К хабу») = присутствуют.

## Очередь Codex (вместе с M2-03 RESEARCH)
Параллельно ждут deploy (owner-accepted, см. active-context хвост #1): M2-04 RES `0cd14c9bd5e0747e` / SYN `e23dd6532f4fbfe5`; M2-05 RES `d6712e0a419130d2` / SYN `e549415d43ea63d3`; M2-06 KARTINA `2c60c5ea0468301c`. M2-03 RESEARCH `3b3b2b1a8b770237` добавляется в эту очередь.
