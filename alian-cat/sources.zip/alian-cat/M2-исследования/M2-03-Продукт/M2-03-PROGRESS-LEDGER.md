# M2-03 Progress Ledger — Product

Дата: 2026-05-23  
Канон: `candidate v1.2` transfer-test  
Runbook after RESEARCH MD_ACCEPTED: `~/studio/methodology/m2-deep-research/01-working/m2-text-then-visual-runbook.md`

## Direction-Level Workflow

| Step | Name | Status | Evidence |
|---|---|---|---|
| Step 1 | DR-PROMPT | PASS | `prompts/M2-03-DR-PROMPT.md`; check file `M2-03-DR-PROMPT-CHECK.md` |
| Step 2a | Salvage Audit | PASS | `M2-03-SALVAGE-AUDIT.md` 2026-05-24 — hybrid decision (salvage F1/F2/F3 + paired DR as input) |
| Step 2b | Paired DR intake | PASS | `DR-SOURCES/raw-claude-deepresearch-product-2026-05-24.md` + `raw-gemini-product-2026-05-24.docx` (+ extracted .txt). Canon-deviation finding: ожидалось GPT+Gemini, получили Claude+Gemini — кросс-валидация валидна |
| Step 3 | Calibration | PASS | `M2-03-CALIBRATION-LOG.md` 2026-05-24 — CONDITIONAL GO. Расхождений, требующих третьего GPT-прогона, нет. 4 КРИТИЧНО suspicious + 7 СРЕДНЕ для MCP, 6 НИЗКО опционально |
| Step 4 | Targeted MCP (Firecrawl + Exa) | DONE | `M2-03-TARGETED-MCP-RESULTS.md` 2026-05-24. Все 4 КРИТИЧНО CONFIRMED. 8 СРЕДНЕ: 1 CORRECTED (Catsby 12000+ комбинаций, не 1000), 6 CONFIRMED, 1 UNRESOLVED (КотаМ цифра). 5 НИЗКО приняты через DR-пару. 7 gaps в R9-wishlist (Apify/Wordstat недоступны). GO к Step 5a |
| Step 5a | RESEARCH-BRIEF | **DONE** | `M2-03-RESEARCH-BRIEF.md` 2026-05-24. Source packet + R1-R9 outline + 30 acceptance criteria + 22 CORRECTED/UNRESOLVED/REFUTED фиксации + paired DR finding для canon-update |
| Step 5b | Internal RESEARCH MD | **DONE** | `M2-03-RESEARCH.md` 2026-05-24. Profile E полный R0-R9 + R10 limitations + R11 self-check. 8 категорий, 37 игроков, 67 SKU, 15 кейсов архитектуры, 41 оффер, 20+7 новинок, 38 источников, 8 гипотез с вердиктами. Self-check: 28/30 acceptance criteria PASS; Stage 4 и Stage 4.8 — внешний gate |
| Step 5c | LANGUAGE_TECH + READER_SANITY + MD_ACCEPTED | **DONE / MD_ACCEPTED** | `M2-03-MD-ACCEPTANCE-GATE.md` 2026-05-24. LANGUAGE_TECH_PASS (17 проверок, 0 violations, patches не требуются). READER_SANITY_PASS (7 проверок, 0 issues, patches не требуются). MD_ACCEPTED поставлен. До отдельной команды на переключение в text-to-visual runbook client-facing layer остаётся STOP |
| Step 6a | SYNTHESIS-BRIEF | **DONE / READY_FOR_METHODOLOGY_CHECK** | `M2-03-SYNTHESIS-BRIEF.md` 2026-05-24. Главное правило: SYNTHESIS сжимает доказательства, но не сжимает карту RESEARCH. Source-map contract (§4) фиксирует 6 обязательных карт: product categories, players, assortment, trust/materials, refuted/unresolved, hypotheses. Writer constraints (§5), gate package (§6: SOURCE_COVERAGE_PASS → LANGUAGE_TECH → READER_SANITY → EDITORIAL → CLIENT_READY), 5 открытых методологических вопросов (§7: roundtable, MCP-eval, H1, адресат, структура) |
| Step 6b | Writer Draft (Pushkin / writer-mode) | **DONE** | `M2-03-SYNTHESIS-DRAFT.md` 2026-05-24. Восемь содержательных частей + Hero Hook material (5 working H1) + краткое резюме + приложение источников. Все шесть карт Source-map contract сохранены. CORRECTED формулировки применены, REFUTED отсутствуют, UNRESOLVED помечены. Финал — гипотезы как вопросы для M3-M7, не решения. Lite roundtable (3 зоны) — ожидает запуска отдельно |
| Step 6c | SOURCE_COVERAGE_PASS | **DONE / PASS** (after patches) | `M2-03-SOURCE-COVERAGE-GATE.md` 2026-05-24. 12/12 criteria PASS. Patches применены: Patch 1 (LucyBalu × Choupette caretaker Françoise Caçote, Часть 2 «Гибридные игроки», строка 147) + Patch 2 (опечатка «при добо» → «при доборе», строка 69). Rerun grep подтвердил C-7 и C-9 closed, не-регрессия по M3-формулировкам |
| Step 6d | LANGUAGE_TECH (SYNTHESIS) | **DONE / PASS** | `M2-03-SYNTHESIS-LANGUAGE-TECH-GATE.md` 2026-05-24. 44 grep-проверки по 6 направлениям. 0 violations. CORRECTED wording preserved во всех 8 ключевых местах. AI-канцелярит clean. Notes по meta-блокам Writer Draft (служебная разметка с методологическими терминами) вынесены в §6 для EDITORIAL и зачистки перед CLIENT_READY |
| Step 6e | READER_SANITY (SYNTHESIS) | **DONE / PASS_WITH_EDITORIAL_QUEUE** | `M2-03-SYNTHESIS-READER-SANITY-GATE.md` 2026-05-24. Patch RS-3 (точные цены Hunnkatt Ekorn MAX 25 080/27 660/29 200 ₽) применён в строках 69, 215, 265. Остальные 7 issues в очереди: 4 под EDITORIAL (стилистика), 3 под CLIENT_READY (meta-разметка draft) |
| Step 6f | EDITORIAL (Stage 4.9) | **DONE / PASS** | `M2-03-SYNTHESIS-EDITORIAL-PASS.md` 2026-05-24. 5 patches applied: RS-4 (значимый строка 107), RS-5 расширенный (инверсия + английский жаргон строка 159), RS-6 (составной вопрос гипотезы 8), RS-7 (self-discipline statement → позитив), EF-1 (consistency PurrNook строка 295). Editorial queue полностью закрыта |
| Step 6g | CLIENT_READY | **DONE / PASS** | `M2-03-CLIENT-READY-GATE.md` 2026-05-25. CLIENT_READY queue полностью закрыта: RS-1 (шапка), RS-2 (Hero Hook material), RS-8 (подпись/служебный блок). Fresh grep по 13 служебным маркерам — 0 hits. Non-regression: все 8 категорий + 11 типов игроков + 10 CORRECTED + 4 UNRESOLVED preserved |
| Canonical SYNTHESIS | DONE | `M2-03-SYNTHESIS.md` 2026-05-25 — побайтная копия `M2-03-SYNTHESIS-DRAFT.md` (89 995 байт, 455 строк). DRAFT-файл сохранён как рабочая история, не используется как HTML source |
| Step 7a | HTML-BRIEF | **DONE / HTML_BRIEF_ACCEPTED** (ревизия 2026-05-25) | `M2-03-HTML-BRIEF-SYNTHESIS.md`. Раунд 1 уточнений: H1 № 2, stat-cards № 3 + № 4 строгие подписи, stop-rule «HTML не делает M3-решение». **Раунд 2 ревизии:** H1 заменён на № 5 («От столбика за тысячу до авторского дерева за сто: как устроен рынок интерьерной мебели для кошек»); stat-card № 2 заменён с «37 игроков» на «11 типов игроков» (проверяемо по клиентскому source); §8.3 переписан: VISUAL_REVIEW_PASS = VISUAL_SMOKE_PASS + DESIGN_REVIEW_PASS, последний валиден только с ui-designer + ux-architect |
| Step 7b | HTML build (rebuild + design patches) | **DONE** | `M2-03-SYNTHESIS.html` 2026-05-25. Initial rebuild 128 771 байт; после design patches 135 195 байт; после DEPLOY_QC cleanup/backlink 135 287 байт. H1 финал, 4 stat-cards (8 / 11 / 590 млрд ₽ TAdviser / 20-30% сменность). Design patches: 10 (1 CRITICAL P-1 mobile sticky-nav + 9 HIGH + 2 связанных MEDIUM) — CSS injection перед `</style>` + post-processing card-grid для players/architecture/trends/packaging (5 `.section-grid`, 46 `.grid-card`) + footer-CTA `<aside>`. Source MD не менялся. Предыдущие builds в `build/stale/` |
| Step 8 | TECH_PASS | **DONE / PASS** | `M2-03-HTML-CHECKS-GATE.md` §1: 0 parser errors, tag balance 270/270, 10 nav-pills ↔ 10 sections, screenshots renderable |
| Step 8 | CONTENT_SYNC sanity check | **DONE / PASS** | §2: H1 буква-в-букву, 4 stat-cards (8/11/590млрд/20-30%), 10 секций, все CORRECTED preserved (Catsby 12000+ ×4, Hunnkatt 25 080/27 660/29 200 ×3, «Мы Бобры» 5 лет ×2, Cove $199 ×3, LucyBalu caretaker ×1, FMI два отчёта раздельно, TAdviser 590 + 433 оговорка), 5 UNRESOLVED меток, 0 REFUTED как утверждений, 3 CTA. Таблиц в source MD нет (R3/R5/R8 сжаты в narrative по правилу SYNTHESIS) — 0 `<table>` в HTML это корректно |
| Step 8 | CLIENT_LANGUAGE_PASS | **DONE / PASS** | §3: 13 pipeline-маркеров 0 hits, 0 M3-формулировок (1 legitimate transfer «продуктовая стратегия Alien Cat — вопрос M3»), 0 запрещённых рамок v1.2, чистый HTML-only текст (nav/buttons/footer/badges) |
| Step 8 | POST_RENDER_PASS | **DONE / PASS** | §4: screenshots desktop 5,1 MB + mobile 14 MB сгенерированы, 0 пустых DOM-блоков, parser OK |
| Step 8 | VISUAL_SMOKE_PASS | **DONE / PASS** | §5: hero/nav/stat-cards читаются, цены Hunnkatt не расползаются |
| Step 8 | DESIGN_REVIEW_PASS (ui-designer + ux-architect) | **DONE / PASS** (после patches + delta-review) | `M2-03-DESIGN-DELTA-REVIEW.md` 2026-05-25. Initial PATCH_REQUIRED medium закрыт через 10 design patches (P-1..P-10 + P-13 + P-15). Delta-review двух subagent'ов: ui-designer = UI_REVIEW_PASS (0 BLOCKERS, 0 WARNINGS, 2 косметических SUGGESTIONS); ux-architect = UX_REVIEW_PASS (BLOCKER UX-6 CLOSED, 0 WARNINGS, 3 косметических SUGGESTIONS). 5 MEDIUM остались как recommendations для будущих итераций |
| **Step 8 Checks package (совокупно)** | **DONE / HTML_CHECKS_PASS** | все 6 components PASS |
| Step 9 | VISUAL_REVIEW_PASS (= VISUAL_SMOKE + DESIGN_REVIEW) | **DONE / PASS** | оба компонента PASS |
| Step 9 | **HTML_READY 4-pass** (= TECH + CLIENT_LANGUAGE + POST_RENDER + VISUAL_REVIEW) | **DONE / HTML_READY** | все 4 условия выполнены; `M2-03-DESIGN-DELTA-REVIEW.md` §6 фиксирует условия как met |
| Step 10 | DEPLOY_QC / publish | **DONE / DEPLOY_QC_PASS / LIVE** | `M2-03-DEPLOY-QC.md` 2026-05-25. Commit `b0fd1bc` в `evskrutyak-bit/brandos-clients`; live URL `https://clients.brand-os.ru/alian-cat/M2/M2-03-SYNTHESIS.html?v=b0fd1bc`. 7/7 checks PASS: deploy copy md5+size, live URL 200, hub card, cache-bust hash, live language grep 0 hits, no service markers, hub link + backlink |

## Client-Facing Stop Gate (закрыто 2026-05-25)

RESEARCH MD_ACCEPTED закрыт 2026-05-24 (Step 5c). Запущен новый Writer Draft route по runbook `m2-text-then-visual` через цепочку gate'ов (6a brief → 6b draft → 6c source coverage → 6d language tech → 6e reader sanity → 6f editorial → 6g client ready → HTML build → visual review → HTML_READY → DEPLOY_QC → publish).

Старый «client-facing pipeline» (прямой переход от RESEARCH к финальному `SYNTHESIS.md` без gate-пакета) был заблокирован методологически и заменён на новый Writer Draft route.

Финальный статус:

| Layer | Status | Reason |
|---|---|---|
| `M2-03-SYNTHESIS.md` | CLIENT_READY_PASS / frozen | канонический клиентский source, source MD не трогался на деплое |
| client-md | NOT APPLICABLE | single-file route, отдельный client-md не создавался |
| HTML-BRIEF | DONE / HTML_BRIEF_ACCEPTED | `M2-03-HTML-BRIEF-SYNTHESIS.md` |
| HTML | DONE / LIVE | `M2-03-SYNTHESIS.html`, live commit `b0fd1bc` |
| Visual Review | DONE / PASS | VISUAL_SMOKE + DESIGN_REVIEW |
| HTML_READY 4-pass | DONE / HTML_READY | TECH + CLIENT_LANGUAGE + POST_RENDER + VISUAL_REVIEW |
| Hub publish / DEPLOY_QC | DONE / DEPLOY_QC_PASS | 7/7 deploy checks PASS, hub обновлён |

M2-03 route закрыт до live. Следующие изменения M2-03 — только через patch-релиз и новый DEPLOY_QC.

## Runbook Switch Rule

Once `M2-03-RESEARCH.md` gets `MD_ACCEPTED`, switch to:

`~/studio/methodology/m2-deep-research/01-working/m2-text-then-visual-runbook.md`

That means no old-pipeline client-facing SYNTHESIS or HTML. The new path is:

```
Source MD lock
  → text / editorial pass
  → CLIENT_READY
  → HTML build / sync
  → UX / UI / Visual review
  → HTML_READY
  → DEPLOY_QC
  → publish
```

## Current State

M2-03 закрыт до live. Step 10 DEPLOY_QC / publish выполнен 2026-05-25: `M2-03-SYNTHESIS.html` опубликован на `clients.brand-os.ru`, hub-карточка ведёт на новый URL, live hash совпадает с deploy copy, live language grep чистый. Source MD по-прежнему не трогаем. Любые следующие изменения M2-03 — только как patch-релиз с новым DEPLOY_QC.
