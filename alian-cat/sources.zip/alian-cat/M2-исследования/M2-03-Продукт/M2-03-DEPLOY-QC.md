# M2-03 DEPLOY_QC — product synthesis

Дата: 2026-05-25  
Deploy repo: `evskrutyak-bit/brandos-clients`  
Commit: `b0fd1bc` — `publish(alian-cat): add M2-03 product synthesis`  
Verdict: **DEPLOY_QC_PASS / LIVE**

---

## 1. Deploy copy

Source:

- `M2-исследования/M2-03-Продукт/M2-03-SYNTHESIS.html`

Deploy copy:

- `/tmp/brandos-clients/alian-cat/M2/M2-03-SYNTHESIS.html`

Checks:

- md5 source: `f0482c97cbe68aaa0c3bfcac0af95ef5`
- md5 deploy: `f0482c97cbe68aaa0c3bfcac0af95ef5`
- size source: `135287`
- size deploy: `135287`

Status: **PASS**

Notes:

- Before deploy, HTML-only service cleanup was applied: removed `noindex,nofollow`.
- Backlink to hub was added in HTML layer via logo link `href="../"`.
- Source MD `M2-03-SYNTHESIS.md` was not touched.

---

## 2. Live URL

Live:

- https://clients.brand-os.ru/alian-cat/M2/M2-03-SYNTHESIS.html?v=b0fd1bc

HTTP:

- status: `200`
- server: `GitHub.com`
- content-length: `135287`
- last-modified: `Sun, 24 May 2026 23:26:07 GMT`

Status: **PASS**

---

## 3. Hub card

Live hub:

- https://clients.brand-os.ru/alian-cat/?v=b0fd1bc

Card attributes:

- `href="M2/M2-03-SYNTHESIS.html"`
- `data-version="v1.0"`
- `data-status="M2-03 готов"`
- `data-date="25 мая 2026"`
- visible version: `v1.0`

Status: **PASS**

---

## 4. Cache-bust verify

Live HTML downloaded with cache-bust:

- `/private/tmp/alian-cat-m2-03-live.html`
- md5 live: `f0482c97cbe68aaa0c3bfcac0af95ef5`
- size live: `135287`

Live hub downloaded with cache-bust:

- `/private/tmp/alian-cat-hub-live-b0fd1bc.html`
- md5 live hub: `1eba012d68338b4d47e6c99f40072b2e`
- size live hub: `77093`

Local deploy hub md5:

- `/tmp/brandos-clients/alian-cat/index.html`
- md5: `1eba012d68338b4d47e6c99f40072b2e`
- size: `77093`

Status: **PASS**

---

## 5. Final live language grep

Checked live files:

- `/private/tmp/alian-cat-m2-03-live.html`
- `/private/tmp/alian-cat-hub-live-b0fd1bc.html`

Pattern groups:

- 13 pipeline markers: `draft`, `gate`, `ledger`, `source_coverage`, `language_tech`, `reader_sanity`, `editorial`, `md_accepted`, `client_ready`, `writer draft`, `brief`, `runbook`, `html_ready`
- Forbidden frames v1.2: `Кошкин Дом`, `VIP`, `люкс`, `эксклюзив`, `премиальная мебель`, `1000 комбина`, `1491 отзыв`, `$599`, `после Лагерфельда`, `+59% весной`
- M3/directive formulas: `Alien Cat должен`, `рекомендуем`, `финальная продуктовая стратегия`, `готовая стратегия`
- service index markers: `noindex`, `nofollow`

Result:

- 0 hits

Status: **PASS**

---

## 6. Service markers and data attributes

HTML parser:

- `python3 -m html.parser /private/tmp/alian-cat-m2-03-live.html` — PASS
- `python3 -m html.parser /private/tmp/alian-cat-hub-live-b0fd1bc.html` — PASS

Service markers:

- `noindex` — 0 hits
- `nofollow` — 0 hits

Data attributes:

- body data attributes present in HTML: `data-artefact="M2-03"`, `data-contour="SYNTHESIS"`, `data-client="alien-cat"`, `data-version="1.0"`, `data-source="M2-03-SYNTHESIS.md"`
- hub card data attributes present and correct: `data-version="v1.0"`, `data-status="M2-03 готов"`, `data-date="25 мая 2026"`

Status: **PASS**

---

## 7. Hub links

Hub → M2-03:

- live hub contains `href="M2/M2-03-SYNTHESIS.html"`

M2-03 → hub:

- live HTML contains `href="../"` with label `Вернуться в хаб Alien Cat`

Status: **PASS**

---

## Final

`M2-03-SYNTHESIS.html` is live.

HTML_READY is now promoted to publish-ready through DEPLOY_QC:

```text
HTML_READY + DEPLOY_QC_PASS = LIVE
```

No source MD changes were made during deploy.
