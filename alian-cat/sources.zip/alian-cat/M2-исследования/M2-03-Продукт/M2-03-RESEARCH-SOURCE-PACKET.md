# M2-03 RESEARCH — Source packet

Дата: 2026-05-25
Контракт: E16 Gate Evidence Contract (candidate v1.3)
Назначение: фиксация source packet для второй попытки M2-03 RESEARCH client-facing rewrite. Все source-файлы прочитаны, md5 зафиксирован — для отслеживания изменений между Stage 1 (packet lock) и Stage 3 (Pushkin Research Mode).

---

## 1. Primary sources (главные входы для Pushkin Research Mode)

### 1.1. Исторический internal RESEARCH

| Файл | md5 | Размер | Роль в новом маршруте |
|---|---|---|---|
| `M2-03-RESEARCH.md` | `8b21884b836eeec5571f097d64a4e89a` | 187 138 байт (870 строк) | **Главный source.** MD_ACCEPTED 24 мая 2026, 28/30 acceptance criteria PASS. Содержит полную карту фактов: 8 категорий, 37 игроков, 67 SKU, 41 оффер, 27 новинок и слабых сигналов, 32 источника, 15 кейсов архитектуры, 8 гипотез с вердиктами. Pushkin Mode rewrite опирается на эту карту фактов, не на мой failed client.md. |

**Не использовать как primary:** `M2-03-RESEARCH-client.md` (failed первая попытка, `6407c70360193704c598bbb15e562719`, 183 997 байт) — anti-example только. См. `M2-03-RESEARCH-INVALID-PASS.md`.

### 1.2. RESEARCH-BRIEF (исторический, для internal RESEARCH сборки)

| Файл | md5 | Размер | Роль |
|---|---|---|---|
| `M2-03-RESEARCH-BRIEF.md` | `63b3190600c28a2a9f35a72dd254e051` | 41 794 байт | **Decision brief для internal RESEARCH.** Source packet, R1-R9 outline, 30 acceptance criteria, 22 CORRECTED/UNRESOLVED/REFUTED фиксации. Pushkin Mode наследует фактическую матрицу отсюда, но **жанр текста не наследует** — это brief для internal, не для client-facing. |

### 1.3. Targeted MCP results

| Файл | md5 | Размер | Роль |
|---|---|---|---|
| `M2-03-TARGETED-MCP-RESULTS.md` | `5807b7d1b347a3dca5c7ccf8d7d11319` | 25 641 байт | **Primary для CORRECTED формулировок.** 4 КРИТИЧНО CONFIRMED через Firecrawl + Exa: «Мы Бобры» гарантия 5 лет, TAdviser 590 млрд ₽ 2025, Salehoo сезонность ноябрь, FMI два отчёта разведены. 8 СРЕДНЕ: Catsby 12 000+ комбинаций (не 1000), Hunnkatt Ekorn MAX три варианта 25 080/27 660/29 200 ₽, и др. Эти формулировки в client-RESEARCH сохраняются буква-в-букву. |

### 1.4. Calibration log

| Файл | md5 | Размер | Роль |
|---|---|---|---|
| `M2-03-CALIBRATION-LOG.md` | `a4262eb43e4a7cea55290e75c55f62e7` | 30 825 байт | Кросс-валидация Claude DR × Gemini DR (24 мая). 12-пункт чек-лист. CONDITIONAL GO с 4 КРИТИЧНО + 7 СРЕДНЕ для MCP-pass + 6 НИЗКО опционально. Reference для верификации фактов и решения по 8 гипотезам R0.11. |

### 1.5. Raw paired Deep Research

| Файл | md5 | Размер | Роль |
|---|---|---|---|
| `DR-SOURCES/raw-claude-deepresearch-product-2026-05-24.md` | `e67ca9323ebf095cd6ec2d857b10e9e8` | 90 013 байт | Claude DR structured skeleton: 8 категорий R1, 23 игрока R2, 24 РФ + 11 зарубежных SKU R3, 15 кейсов R4, 31 оффер R5. |
| `DR-SOURCES/raw-gemini-product-2026-05-24.docx` | `b1a2b9b2993347c894c90a64e3726260` | 68 753 байт | Gemini DR raw DOCX. |
| `DR-SOURCES/raw-gemini-product-extracted-2026-05-24.txt` | `4c9b63deb909913c841eeb46bbed006f` | 105 869 байт | Gemini DR extracted text. Prose-narrative, явный блок «Проверка Suspicious Claims (R0.12)». Список игроков, которых нет у Claude (PurrNook, Pryde Pets, Armarkat, TOWALKER, Miza/Peelorange, Dhanus Decor). |

---

## 2. Brand inputs (для R0.1 контекст и языковая рамка)

| Файл | md5 | Назначение |
|---|---|---|
| `brand/profile.md` | `c808a6063dd79b08031f67bd35f0f17b` | Профиль бренда v0.1 (19 мая 2026). Светлана Северина / ИП Северина; категория «дизайнерская интерьерная мебель для кошек»; Avito основной канал; рабочие S/M/L 20-30 / 30-50 / 75-100 тыс. ₽; рассрочка не подтверждена; Instagram личный, не бренд-площадка. |
| `brand/offer-core.md` | `ad3636a0a9c49d30859bcc1120708a37` | Главный оффер v0; ценностные слои; линейка S/M/L; барьеры покупки. |
| `brand/audience.md` | `68b0c54dff196f9289272775eb884528` | Аудиторные гипотезы v0; эстетический владелец дома и кошки как ядро; группы для проверки в M4; язык аудитории v0. |
| `brand/voice-style.md` | `26f62d35ad809d3b34c0a2a60bc387b7` | **Голос бренда v0.** Формула: «спокойная интерьерная забота с лёгкой кошачьей иронией». Три режима: Мастер / Эстет / Кот. Лексика использовать / избегать. Принципы текста. Это входной документ Pushkin Mode — текст RESEARCH должен звучать в этом регистре. |
| `brand/personal-dna.md` | `29bffc353c5f49d2c117bfa6e3fe46d8` | Личная DNA Светланы. Reference для интонации. |
| `brand/selling-map.md` | `b09f4f7f37e9d95e6698d327cb21958f` | Карта продаж v0. |
| `brand/social-proof.md` | `2e43c7fdd6ca496420799ca412b8988f` | Social proof — отзывы Юлии, Андрея, Варвары, Оксаны, Summer Cherry; контекст для понимания клиента. |
| `brand/style-guide.md` | `bba29ce2df0fec4e66c4f994d0fb504e` | Стиль-гайд. |

---

## 3. Context-only (НЕ source для копирования)

### 3.1. Опубликованный SYNTHESIS

| Файл | md5 | Назначение |
|---|---|---|
| `M2-03-SYNTHESIS.md` | `8001f6315371e9611e40994703ab81e7` | 89 995 байт. **Контекст-only.** Опубликован 25 мая 2026 (commit `b0fd1bc`, live https://clients.brand-os.ru/alian-cat/M2/M2-03-SYNTHESIS.html?v=b0fd1bc). RESEARCH — отдельный жанр, не выжимка SYNTHESIS и не его дублирование. Не копировать формулировки. Reference для тональности и оформления. |
| `M2-03-SYNTHESIS.html` | — | Live commit `b0fd1bc` в `evskrutyak-bit/brandos-clients`. CSS donor для RESEARCH HTML. **Известная проблема:** hero `.fade-up { opacity:0 }` без JS bootstrap — затрагивает и live SYNTHESIS, и нашу будущую RESEARCH сборку. Отдельная задача за пределами этого packet'а. |

### 3.2. Closed модули

- M2-01 «Рынок РФ» (RESEARCH `eb1e75e` + FINAL `006ae91`) — для не-повторения общей структуры рынка РФ.
- M2-02 «Рынок мир» (RESEARCH `7b7792c` + SYNTHESIS `3dd5a5f`) — для не-повторения мировых трендов и страновых ориентиров.

Не source. Не для копирования. Reference: «что уже закрыто и не повторяется» в R0.2 нового RESEARCH.

---

## 4. Anti-example (для brief'а — что НЕ делать)

| Файл | md5 | Что показывает |
|---|---|---|
| `M2-03-RESEARCH-client.md` (failed первая попытка) | `6407c70360193704c598bbb15e562719` | 1) Что structural cleanup исторического RESEARCH ≠ Pushkin Research Mode rewrite. 2) Что 130+ непереведённых англицизмов проходят узкий grep кухни. 3) Что «карточка» в 19 местах с двойным смыслом не ловится автоматически. 4) Что R0 переписанный одним проходом без brief'а получается длинным coordinator-style блоком. |
| `M2-03-RESEARCH-QUALITY-GATE.md` | — | INVALID_PASS. Что значит self-certified PASS без evidence table. |
| `M2-03-RESEARCH-DEPLOY-QC.md` | — | INVALID_PASS. Что значит narrative DEPLOY_QC без независимой проверки. |
| `html/M2-03-RESEARCH.html` (failed first build) | — | INVALID_PASS. 1) `.fade-up` opacity:0 без JS — первый экран невидим. 2) Таблицы 11 колонок × 39 строк ломают desktop. 3) `cat behaviorists`, `litter box`, `bespoke`, `furniture-first` и пр. в rendered. |
| `html/M2-03-RESEARCH-desktop.png`, `-mobile.png` | — | Что captured screenshot не равен browser review. Default screenshot.py + opacity:0 → no evidence. |

---

## 5. Source-map contract (заимствован из SYNTHESIS-BRIEF, адаптирован под RESEARCH-жанр)

Pushkin Research Mode rewrite **обязан** сохранить шесть карт фактов целиком, не сжимая до резюме. RESEARCH — жанр карты, не выжимки.

1. **Карта продуктовых категорий** — 8 категорий с ролями, размерами, ценовыми диапазонами, частотой покупки, зрелостью в РФ.
2. **Карта игроков** — 37 игроков с типологией продуктовой логики (модульно-сменные / флагман-строители / ремонтно-сменные / кастомные / гибридные / вход-строители / B2B-премиум / умные функции / эко-recycled / сезонный / мебельная интеграция).
3. **Карта ассортимента** — 51 SKU РФ + 16 зарубежных, целевая 67. Колонки: формат, размер, материалы, цена, что включено, роль, ярус, канал, дата доступа, URL.
4. **Карта доказательности** — 41 оффер с цитатами и URL. Материалы / прочность / гарантия / сменность / сервис / философия.
5. **Карта корректировок** — CORRECTED / REFUTED / UNRESOLVED. 10 CORRECTED формулировок (Catsby 12 000+, Hunnkatt 25 080/27 660/29 200 ₽, «Мы Бобры» гарантия 5 лет, TAdviser 590 млрд ₽ 2025, FMI два отчёта разведены, Tuft+Paw Cove $199, LucyBalu × Choupette через caretaker, Lotus ~440 USD, RHRQuality «крупнейший в Европе» вместо «единственный», IKEA Lurvig снят / Utsaedd на смену). REFUTED не используются вовсе. UNRESOLVED помечены прямо в таблицах.
6. **Карта гипотез** — 8 гипотез заказчика с вердиктами: S/M/L как роли, сменные элементы как повторная покупка, усиление для крупных пород, furniture-first, материалы и ремонтопригодность, тумбы/настенные/компактные, упаковка/сервис, Avito vs собственный сайт.

Если в новом RESEARCH MD одна из шести карт сжата до резюме или потеряна — `SOURCE_COVERAGE_FAIL`, возврат в Pushkin Mode с уточнённым brief.

---

## 6. Что считается VERIFIED для этого packet'а

Этот packet считается VERIFIED, если:

- md5 всех 18 файлов в таблицах §1, §2 и контекста-only §3.1 совпадает с локальными файлами (можно перепроверить любой строкой `md5 -q <path>`);
- ни один из draft-файлов §4 не используется как primary source в Pushkin Mode (только как anti-example);
- Source-map contract §5 принят как обязательное условие для Pushkin Mode.

| Поле | Значение |
|---|---|
| Gate | SOURCE_PACKET_LOCKED |
| Claimed by | Claude (Coordinator) |
| Verified by | **pending owner / Codex independent review** |
| File | этот файл `M2-03-RESEARCH-SOURCE-PACKET.md` |
| Method | md5 на всех 18 файлов; список содержания primary / brand / context-only / anti-example по таблицам |
| Evidence | md5 в таблицах; ссылки на конкретные строки исторических артефактов |
| Fail criteria | hash mismatch у любого источника; отсутствие brand-входа; отсутствие anti-example; нет source-map contract |
| Result | CLAIMED — ожидает независимого verifier |
| Verdict | **CLAIMED_PASS до review.** Не VERIFIED_PASS без независимого verifier. |
