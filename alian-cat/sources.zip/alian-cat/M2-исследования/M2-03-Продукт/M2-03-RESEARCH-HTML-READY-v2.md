# M2-03 RESEARCH HTML — Gate Stamp (6-check) — закрытие долга E16

> Этот файл — single source of truth по статусу HTML. Сверху — **CURRENT** (актуально сейчас). Всё ниже раздела HISTORY — **NOT CURRENT** (superseded), оставлено только как аудит-след.

---

## ✅ CURRENT VERDICT

**Verdict:** `OWNER_ACCEPTED` — owner eye-check PASS 2026-06-06. Final. Осталось только: **deploy + hub через Codex.**
**Date:** 2026-06-06 (evidence refresh + owner accept)

| Поле | Значение (CURRENT) |
|---|---|
| **Source MD** | `M2-03-RESEARCH-client.md` (CLIENT_READY VERIFIED — см. `M2-03-RESEARCH-CLIENT-READY-GATE-v2.md`) |
| **Current provenance** | **`3b3b2b1a8b770237`** — единственный действительный hash. HTML `built_from_client_md_hash` == sha256[:16](MD). |
| **HTML** | `html/M2-03-RESEARCH.html` (1670 строк, ~214 KB), file-hash `d54ecf04f68e4f65` |
| **Builder** | Sonnet Agent (BUILT). **Verifier** — Claude, независимо (Builder ≠ Verifier). |
| **Deploy/hub** | НЕ делались (после owner eye-check, через Codex). |

**Evidence-chain ordering (mtime, 2026-06-06):** MD `00:29:04` → HTML `00:40:07` → этот gate (пишется последним). HTML mtime > MD mtime ✓; gate mtime > HTML mtime ✓.

### Active 6-check (всё против `3b3b2b1a8b770237`)
| # | Check | Evidence (2026-06-06) | Результат |
|---|---|---|---|
| 1 | TECH | doctype + `<!-- built_from_client_md_hash: 3b3b2b1a8b770237 -->` + charset; section 12/12; reveal-script (IntersectionObserver threshold:0) на месте | ✅ PASS |
| 2 | CONTENT_SYNC | provenance `3b3b2b1a8b770237` == MD; 12 секций; 8 категорий / 37 игроков / 67 SKU / 41 оффер / 38 источников / словарь — без сжатия. **5 sample rows поле-в-поле = MD:** Hicat #61 (натуральное кокосовое волокно (Natural Coir), татами, AVM Wool, сизаль + Что включено/Канал/URL) ✓; Karimoku #59 (микрозамша (suede), от 50 000 ¥) ✓; Cove #52 (199 USD, все поля) ✓; Catit #64 (150-200 USD, все поля) ✓; offer #25 Catastrophic («Patented hidden bracket system» + URL) ✓ | ✅ PASS |
| 3 | CLIENT_LANGUAGE (rendered) | развилк=0; сильная кухня (прогон/заход/лог сверки/искусственн интеллект/MCP/firecrawl/exa/DR/pipeline/roundtable/[M2-0X])=0; `выгрузк`=0; англ-утечки (parts-accessories/suede/e-commerce)=0. Греп MD+HTML = 0 | ✅ PASS |
| 4 | POST_RENDER | Playwright desktop (1440) + mobile (375), **0 pageerror** на обоих (2026-06-06) | ✅ PASS |
| 5 | VISUAL_SMOKE + ВИДИМОСТЬ (корень E16) | свежие скриншоты 2026-06-06: hero виден desktop И mobile; с force-`.fade-up:opacity:1` весь документ рендерится, 12 секций. reveal threshold:0 (untouched от прошлого PASS). Невидимый первый экран устранён | ✅ PASS |
| 6 | DESIGN_REVIEW | **Claude посмотрел свежие hero-скриншоты глазами:** hero full-width, nav + «К хабу» pill (hub-link ✓), H1 «Продуктовое поле дизайнерской мебели для кошек», лид, 4 stat-card (8/37/67/41), мета Client Ready. desktop + mobile. Single-reviewer (AI-side) | ✅ VERIFIED — provisional до owner eye-check |

### Hero stat-grid (E13 — verifiable из MD)
8 продуктовых категорий · 37 игроков · 67 изделий (SKU) · 41 оффер.

### Что НЕ сделано
Deploy/hub — нет (после owner eye-check, через Codex).

---

## HISTORY / NOT CURRENT (superseded — только аудит-след)

> Hash-цепочка: `ca9c48be17e53c5c` → `cb19b9cc1590fc17` → **`3b3b2b1a8b770237`** (current). Любая строка ниже, ссылающаяся на `ca9c48be` или `cb19b9cc`, — историческая и НЕ описывает текущий файл.

- **`ca9c48be17e53c5c`** — первый verified RESEARCH client.md (post-incident E16). СНЯТ при Language patch 2.
- **`cb19b9cc1590fc17`** — после кухня-cut (Patch 2/3). СНЯТ при Language patch 4 (реворд «выгрузка»).

**Patch 2 (2026-06-05)** — русская процессная кухня убрана из HTML; provenance был `cb19b9cc1590fc17`. *(superseded)*

**Patch 3 (owner-caught 2026-06-05)** — удалены целые разделы внутренней кухни (MD+HTML): «Как собран материал», «Исправленные формулировки», «Что не используется» (§«О документе» оставлен). Контент-фиксы: «густонаселённая зона» → «плотно занятый ценовой коридор, рядом много игроков»; «беговые колёса — новая под-категория» → «новый формат у двух игроков» (overclaim 1/5 убран). Provenance был `cb19b9cc1590fc17`. *(superseded)*

**CONTENT_SYNC patch (owner-caught 2026-06-05)** — билдер сократил SKU/source-таблицы (колонки «Что включено/Канал/URL», русские расшифровки); fixer-агент вернул полные колонки из MD; field-level верификация Claude прошла (те же 5 sample rows). Provenance был `cb19b9cc1590fc17`. *(включено в current CONTENT_SYNC)*

**Independent Verifier-pass (2026-06-06, Claude ≠ Builder)** — реверификация штампа вскрыла 2 остатка, которые прежний PASS пропустил: (1) HTML-десинк §02 sub обещал удалённые подразделы → выровнен по MD; (2) «выгрузка Avito недоступна в этом исследовании» + термин «выгрузка» (8 MD + 4 HTML) → owner-решение «переформулировать» → «детальный разбор предложений на Avito». *(привело к current hash)*

**Language patch 4 (2026-06-06)** — реворд выгрузка→детальный разбор предложений → MD hash `cb19b9cc1590fc17` СНЯТ, новый **`3b3b2b1a8b770237`** (current). HTML синхронизирован поле-в-поле; правки чисто текстовые (CSS/reveal не тронуты, div 625/625). *(это и есть current)*
