# M2-05 Targeted Verification — Конкуренты Alien Cat

Дата: 2026-05-29
Статус: `TARGETED_VERIFICATION_DONE / NOT_RESEARCH_READY`
Основание: `M2-05-SALVAGE-AUDIT.md` § 6, `M2-05-SOURCE-PACKET.md` § 5.2
Метод: targeted Exa web search + Exa highlights по backlog K-TV-01..K-TV-10. Не Deep Research и не клиентский артефакт.
Дополнение к: `_fact-check/M2-05-KONK-MCP-RESULTS.md` (Tavily 2026-04-27, 6 KРИТИЧНО фактов).

---

## 1. Контекст и backlog

Salvage-аудит и source packet оставили длинный список подозрительных и устаревших claims по M2-05 Конкуренты. Tavily-сверка 27 апреля закрыла 6 КРИТИЧНО-фактов (Catsby рассрочка, Catsby цены, Murr & Woof Dubai/Milan, €700/Raf Simons, AD Russia публикация, объём рынка 433 млрд ₽). Эта проверка добавляет десять точечных Exa-проб по другому набору claims — главным образом, по продуктовым деталям, ассортименту и легитимности игроков, которые не были в Tavily-списке и которые блокируют будущий M2-05 Research.

Цель — снять или ослабить часть красных флагов до открытия DR/RESEARCH-BRIEF, а оставшиеся честно зафиксировать как `WEAK_SIGNAL` или `NOT_VERIFIED`.

Что проверял (10 проб):

- K-TV-01 Catsby Family — AR-примерка в современном виде.
- K-TV-02 Catsby Family — продуктовая матрица и условия покупки.
- K-TV-03 Teddy Room — ассортимент, индивидуальный заказ, контакты.
- K-TV-04 Murr & Woof — текущий статус бренда и команды.
- K-TV-05 PETTEL — позиционирование и активность.
- K-TV-06 Cat Brand — «алтайские мастера» и география.
- K-TV-07 TOMEOW — модель и упоминания в медиа.
- K-TV-08 Katacombas — формат бизнеса и активность.
- K-TV-09 Глобальные премиум-бренды (Tuft+Paw, RHRQuality, LucyBalu) — текущие цены и роль.
- K-TV-10 Российские дизайн- и lifestyle-медиа — публикации о российских брендах мебели для кошек 2022–2025.

---

## 2. Матрица verdicts

| ID | Claim | Источник старого DR / suspicious | New finding | Verdict | Caveat |
|---|---|---|---|---|---|
| K-TV-01 | Catsby Family — AR-примерка на сайте | D-XSV-03 (СРЕДНЕ) | Активная страница `catsby-family.ru/ar` с реальным списком моделей для AR-примерки в смартфоне | `SUPPORTED` | Использовать как факт на 2026-05-29 |
| K-TV-02 | Catsby Family — продуктовая матрица WALL/VINE/TREE/STAND + рассрочка + гарантия возврата | Старый DR + D-XSV-04 | Подтверждены 4 типа (WALL, VINE, TREE, STAND), указаны рассрочка `×10 мес.`, «гарантия лёгкого возврата 7 дней», доставка по миру | `SUPPORTED` | Гарантия 6 мес как продуктовая — не подтверждена; на сайте видна только гарантия возврата 7 дней |
| K-TV-03 | Teddy Room — ассортимент, индивидуальный заказ, контакты | D-XSV-05, D-XSV-06 (СРЕДНЕ) | Сайт активен, каталог содержит «Когтеточки», «Тумбы для лотка», «Модульные комплексы», «Индивидуальные изделия», «Плетеные домики»; контакт +7 (996) 004-93-30, Telegram/WhatsApp; индивидуальный заказ — отдельный раздел каталога | `SUPPORTED` | Конкретные акции «второе изделие за полцены» — НЕ найдены в текущей выдаче; SSL/render сайта частично сломан (двоичный мусор в Exa-highlights) |
| K-TV-04 | Murr & Woof — текущий статус бренда | D-XSV-07, D-XSV-08, D-XSV-09 | Studio Supaform теперь в Париже (`supaform.studio`, Paris/France); найден активный бренд `purr-murr.ru` (PURR MURR), с дубовой мебелью, гарантией 6 мес, дизайн похож на старый Murr & Woof; AD Russia-публикация 2019 подтверждена через прямую дату (`2019-12-26`) | `SUPPORTED_WITH_CAVEAT` | AD Russia публикация = 2019-12-26 — снимает «без года» caveat; старый бренд Murr & Woof в текущем виде не найден; вероятный rebrand → PURR MURR требует прямой проверки клиентом |
| K-TV-05 | PETTEL — позиционирование как luxury pet design | D-XSV-10 (СРЕДНЕ) | Подтверждено через CatPeople.ru («российский бренд PETTEL и его невероятно стильные предметы»), Design-milk (2019, «Moscow-based product designer Olga Shvetsova», «luxury pet brand»), Domasan (2024); рассрочка через банки в Exa-highlights не найдена | `SUPPORTED_WITH_CAVEAT` | Бренд активен как минимум в публичной среде; рассрочка через банки — НЕ верифицирована, оставить как `NOT_VERIFIED` |
| K-TV-06 | Cat Brand — «алтайские мастера», экспорт 10+ стран | D-XSV-11 (СРЕДНЕ) | Подтверждено: производство на Алтае (Новоалтайск, г. Барнаул), ИП Кобызев Е.Ю., адрес возврата ул. Загородная 129 Барнаул; материал — алтайский ивовый прут; самозаявление «живут более чем в 10 странах мира» на собственном сайте; отдельная компания «Алтайская ива» в том же регионе подтверждает категорию | `SUPPORTED_WITH_CAVEAT` | Алтайское происхождение — `SUPPORTED`. «Экспорт в 10+ стран» — это self-claim на сайте бренда, не независимая верификация. Использовать как «по утверждению бренда» |
| K-TV-07 | TOMEOW — позиционирование «№1 в России», картонная мебель | Старый DR | Сайт `tomeow.homezoomarket.ru` активен, «№1 производитель когтеточек» — self-claim в title; ассортимент — Кубик, Юрта, лежанки Medium/Equator/Aquarium/Eyes/Wheels; цены 490 ₽ за базовый домик; vc.ru-упоминание Exa не нашёл, но через `Yopt.org` есть похожий игрок «Кот Барон (Тумяу)» — отдельный бренд под ИП Ермаков (СПб) | `SUPPORTED_WITH_CAVEAT` | «№1» — self-claim; vc.ru как источник не подтверждён в этой проверке |
| K-TV-08 | Katacombas — мем-комьюнити, дизайнерская мебель | Старый DR | Подтверждено через Sberbusiness.live (2023): основательница Дарья Сулыга, СПб, самозанятая, выручка ~150 000 ₽/мес, ассортимент — когтеточки, миски, домики, ступеньки, корзинки, гамаки; найдены два адреса в СПб (Тверская 12/15Б, Аптекарский пр. 2); Sobaka.ru (2022) подтверждает мем-стиль («хлебницы», «заправочные станции», «шкрабадло»); бренд использует слово «Wabi-Sabi Woodstock» в собственных продуктах | `SUPPORTED` | Малый бизнес/самозанятая модель, не корпоративный premium peer для Alien Cat |
| K-TV-09 | Глобальные премиум-бренды — цены, ассортимент, легитимность | Старый DR + salvage list | Подтверждено: Tuft+Paw (USA) — Cove Litter Box $199, Grove Cat Tower $399–499, Frond Cat Tree $209–299, Stellar Cat Bed $239–299, Nuzzle Cat Bed $135–169; RHRQuality (NL/UK) — Maine Coon Tower Crown €451, Panther XXL £529, Cat Paradise €509, кастомная высота 2–2.95 м, 20 cm сизаль; LucyBalu (DE) — premium, made by small German manufacturers, коллаборации с Choupette/Karl Lagerfeld, sieger design, упоминание AD Magazin как один из лучших немецких designers | `SUPPORTED` | Все три бренда живые в 2026. Cove Litter Box — $199 (что закрывает старый Tuft+Paw $599 claim как пересмотренный). RHRQuality — реальный лидер премиум-сегмента для крупных пород |
| K-TV-10 | Российские дизайн- и lifestyle-медиа публикуют материалы о мебели для кошек | D-XSV-13 (СРЕДНЕ) | Подтверждено по AD Magazine (`admagazine.ru`): Murr & Woof 2019-12-26, Catastrophicreations / Cat Mod 2019-05-21, Cat Flat от 24Storage 2020-02-11. Sobaka.ru: «11 российских брендов для любимых кошек и собак» (2022-09-06, актуализировано 18.11.2024); myDecor: коллекция Anima от ADJ Style (2025-06-12), материал об ИКЕА коллекции Lurvig (2024-03-29); Build2Last (2024-12) — CATable 2.0 | `SUPPORTED` | Все 4 медиа (AD / Sobaka / myDecor / build2last) реально работают с темой и публикуют материалы о категории. Но из этой выдачи НЕ следует, что они являются продажным каналом — это legitimacy layer, не funnel |

Сводка:
- `SUPPORTED`: 5 (K-TV-01, K-TV-02, K-TV-03, K-TV-08, K-TV-09, K-TV-10) → 6
- `SUPPORTED_WITH_CAVEAT`: 3 (K-TV-04, K-TV-05, K-TV-06, K-TV-07) → 4
- `WEAK_SIGNAL`: 0
- `NOT_VERIFIED`: 0
- `REJECTED`: 0

(Поправка по подсчёту: SUPPORTED — 6 / SUPPORTED_WITH_CAVEAT — 4 / итого 10 проверенных)

---

## 3. Подробные находки по каждой проверке

### K-TV-01 — Catsby Family: AR-примерка на сайте

**Запрос (Exa):** `Catsby Family мебель для кошек когтеточки AR примерка дополненная реальность сайт 2026`

**Что найдено:** Найдена прямая страница `https://catsby-family.ru/ar` с заголовком «Дополненная реальность с Catsby Family». На странице перечислены конкретные модели для AR-примерки: VINE (118, 145, 175, 192, 232 см / 2-4 уровня), WALL (63, 100, 120, 147, 177 см / 2-4 уровня), TREE (240–255 см, установка враспор), STAND, домик-будка, ступени STEP, гамаки. Цитата: «Примерьте комплекс в своём интерьере с помощью телефона. Выберите комплекс».

**Verdict:** `SUPPORTED`. AR-примерка Catsby — живой инструмент на 2026-05-29 и охватывает 20+ моделей.

**Использовать в M2-05 как:** подтверждённое технологическое преимущество Catsby. На D2C-уровне в РФ это редкий и сильный CX-сигнал.

---

### K-TV-02 — Catsby Family: продуктовая матрица + условия

**Запрос:** тот же что K-TV-01 + product pages.

**Что найдено:** На странице товара «Комплект из 3-х ступеней STEP» (5390 ₽ со скидкой / 6468 ₽ без / 539 ₽ × 10 мес. в рассрочку) виден стандартный лейбл условий: «Гарантия лёгкого возврата в течение 7 дней с момента получения / Доставка по России до двери / Доставка по миру EMS, TNT, Почтой России». Материалы — натуральный дуб, белый канат (фанера для домика-будки берёзовая, покрытие натуральным маслом и воском). Артикулы: STEP-3-NW, VINE, WALL, TREE, STAND, HOUSEPET.

**Verdict:** `SUPPORTED`. Продуктовая матрица WALL/VINE/TREE/STAND + STEP + домик подтверждена. Рассрочка `×10 мес.` отображается на карточках товара. Доставка по России и миру.

**Caveat:** «Гарантия 6 месяцев» из старого DR в этой проверке НЕ подтверждена. На сайте видна только «гарантия лёгкого возврата 7 дней». Большие гарантийные обязательства Catsby не нашёл — снять из M2-05 как `NOT_VERIFIED` или переформулировать как «возврат 7 дней».

---

### K-TV-03 — Teddy Room: ассортимент, индивидуальный заказ, контакты

**Запрос:** `Teddy Room мебель для кошек индивидуальный заказ когтеточки тумбы вольеры`

**Что найдено:** Сайт `teddy-room.ru` отдаёт частично сломанный markdown (Exa highlights показывают двоичный мусор), но карта каталога восстанавливается через подстраницы:

- `/catalog` — список разделов: «Изделия для собак», «Изделия для кошек», «Общий каталог», «Все новинки», «Популярные товары», «Изделия на заказ».
- `/catalog/products-for-cats/scratching-posts` — «Когтеточки» (отдельный раздел: Все, Домики, Плетеные домики, Когтеточки, Тумбы для лотка, Модульные комплексы, Индивидуальные изделия, Подставки под миски, Матрасы и подушки).
- Карточка `Teddyroom Double Qvadro Wood House` — двухэтажный домик-вольер 34 390 ₽, контакты через WhatsApp/Telegram.
- Контакт: +7 (996) 004-93-30, форма обратной связи.

Дополнительно `mebel-dlya-zhivotnih.orgs.biz` цитирует self-claim Teddy Room: «протестировали 10 видов покрытий», «более 40 домашних животных», «возможен индивидуальный дизайн мебели».

**Verdict:** `SUPPORTED`. Teddy Room на 2026-05-29 — активный бренд с реальным каталогом, индивидуальным заказом и ценами 30+ тыс. ₽ за крупные изделия.

**Caveat:** Акция «второе изделие за полцены» (D-XSV-05) в текущей выдаче НЕ найдена. Это либо устаревший снапшот, либо акция временная — не использовать в M2-05 без свежей даты.

---

### K-TV-04 — Murr & Woof: текущий статус бренда

**Запрос:** `Murr Woof Москва сайт официальный мебель животных Supaform 2024 2025`

**Что найдено:**

1. AD Russia публикация 2019-12-26 подтверждена прямой датой и автором (Софья Шатохина) — снимает caveat «без года» из Tavily-сверки.
2. Studio Snorhaar (NL) подтверждает «Murr & Woof (Moscow)» как клиента в портфолио — это закрывает старый московский статус.
3. Studio Supaform — теперь Paris-based (`supaform.studio`, контакт Paris/France, +39 351 467 7025, INSTAGRAM). На Миланской неделе дизайна 2025 показали инсталляцию `The Waiting Room` через Alcova. То есть основная креативная команда бренда (по AD-2019 — «совместно со студией Supaform») сейчас работает из Европы.
4. Найден отдельный бренд `purr-murr.ru` (PURR MURR) — дубовая мебель для кошек, лежанка Nekomori, материалы и цвета, гарантия 6 мес, бесплатная доставка по России. Это либо rebrand Murr & Woof, либо отдельный игрок с похожим неймом — требует прямой проверки клиентом.

**Verdict:** `SUPPORTED_WITH_CAVEAT`. AD Russia публикация = 2019-12-26 (`SUPPORTED`). Supaform → Париж (`SUPPORTED`, что объясняет, почему Tavily не нашёл Dubai/Milan showroom как Murr & Woof — это не их сцена сейчас). PURR MURR как возможный преемник — `WEAK_SIGNAL`, нужен owner check.

**Использовать в M2-05 как:** Murr & Woof в исходном виде 2019-2020 — historic art-piece бренд, легитимность через AD Russia публикацию. Текущая активность бренда под старым именем — не подтверждена. Все luxury-claims Dubai/Milan/Maison&Objet остаются в stop-list. Возможный преемник PURR MURR — оставить в M2-05 backlog как `NEEDS_OWNER_CHECK`.

---

### K-TV-05 — PETTEL: позиционирование luxury pet design

**Запрос:** `PETTEL мебель для кошек когтеточки дизайн интерьер ассортимент`

**Что найдено:**

- CatPeople.ru (без даты) — интервью с основательницей: «российский бренд PETTEL», ассортимент включает двойные миски Double F, лежанки для лофт-интерьеров, в планах «интерьерные комплексы, вертикальные когтеточки, лежанки для двух кошек, красивые полки для лазанья, летняя коллекция для загородного дома».
- Design-milk (2019-05-21) — «Founded by Moscow-based product designer Olga Shvetsova, PETTEL is a luxury pet brand focused on bringing high-quality interior objects to dog and cat owners across the globe... furniture sets, daybeds, dog stairs, clothing racks».
- Domasan (2024-04-13) — «Ольга Швецова создает мебель для домашних животных как полноценные предметы интерьера... В планах Ольги — расширение ассортиментной линейки, а также сотрудничество с другими дизайнерами мебели для разработки новых коллекций под брендом Pettel».
- Terdo / kupiprodai (2023-2024) — карточки PETTEL в Москве с описанием «домики, лежанки, когтеточки, вешалки и аксессуары... вся мебель ручной работы».

**Verdict:** `SUPPORTED_WITH_CAVEAT`. PETTEL — реальный российский luxury/интерьерный pet-бренд, активный с 2019 и упоминаемый в дизайн-медиа в 2024. Self-positioning — «luxury pet brand».

**Caveat:** Старый claim D-XSV-10 «рассрочка через банки» в этой выдаче НЕ верифицирован. Оставить как `NOT_VERIFIED` до проверки на самом сайте. Рамку «furniture-first / интерьерные объекты» можно использовать.

---

### K-TV-06 — Cat Brand: «алтайские мастера», экспорт 10+ стран

**Запрос:** `Cat Brand Алтай Барнаул производство мебель для кошек ивовая лоза экспорт`

**Что найдено:**

- Официальный сайт `cat-brand.ru` подтверждает: «собственное производство мебели для кошек на Алтае», материал «настоящий ивовый прут». Self-claim: «Наши комплексы, когтеточки, домики, миски живут более чем в 10 странах мира» — на странице ценителей.
- Оферта `cat-brand.ru/agreement`: «Продавец — ИП Кобызев Евгений Юрьевич (ОГРНИП 3200320061460, ИНН 220803225296, Юр. адрес: 658041, г. Новоалтайск, ул. 1-я Ипподромная, 32)». Адрес возврата — Барнаул, ул. Загородная, 129. Это подтверждает алтайское происхождение бизнеса как факт.
- `cat-brand.orgs.biz` — конкретные цены: Комплекс настенный «Луна» 21 800 ₽, «Лили» 25 100 ₽, «Бруно» 29 100 ₽, «Тиида-2» 28 600 ₽, «Тиида» 30 960 ₽, домик плетеный «Феня» 7 000 ₽, когтеточка с лежанкой «Соло» 15 500 ₽, комплекс «Дикси» 20 000 ₽.
- Параллельно `fabricators.ru` показывает отдельную компанию «Алтайская ива» (Барнаул, с июня 2014) — производит плетёные изделия из ивовой лозы, включая «домики для домашних животных».

**Verdict:** `SUPPORTED_WITH_CAVEAT`.

`SUPPORTED`: алтайское происхождение, ИП Кобызев, Новоалтайск/Барнаул, материал — алтайский ивовый прут.

`CAVEAT`: «экспорт в 10+ стран» — это self-claim на собственном сайте бренда, без независимой верификации. Использовать как «по утверждению бренда — продукция отправлялась в более чем 10 стран». Не как доказанный факт промышленного экспорта.

**Каталог цен:** реальный диапазон Cat Brand 7 000–31 000 ₽ — ниже Alien Cat. Это даёт другой ценовой ярус — Cat Brand НЕ прямой ценовой peer для L-сегмента Alien Cat (75-100 тыс. ₽).

---

### K-TV-07 — TOMEOW: модель и медиа

**Запрос:** `TOMEOW картонная мебель для кошек дизайн домик vc.ru стартап`

**Что найдено:**

- Сайт `tomeow.homezoomarket.ru` живой. Self-positioning: «TOMEOW — №1 производитель когтеточек в России!». Материал — 3-х слойный гофрокартон с печатью. Ассортимент: домики Кубик (490 ₽), Юрта (490 ₽), когтеточки-лежанки Medium, Equator, Aquarium, Eyes, Wheels.
- На `Yopt.org` отдельная карточка `Кот Барон (Тумяу)` — ИП Ермаков Марк Валерьевич (СПб), «производитель картонных когтеточек премиум класса с 2017 года». Это похоже на другой бренд той же категории, не сам TOMEOW.
- Sobaka.ru (2022-09-06) подтверждает TOMEOW в подборке «11 российских брендов»: «бренд с полным циклом производства в Петербурге... используется гофрокартон высшего сорта... гамаки оконные и батарейные для бердвотчинга, многофункциональный игровой центр».

**Verdict:** `SUPPORTED_WITH_CAVEAT`.

`SUPPORTED`: TOMEOW — активный российский бренд картонной мебели из СПб, на маркетплейс-уровне 490–1 500 ₽ за единицу, Sobaka.ru-публикация 2022 как реальная legitimacy-точка.

`CAVEAT`: claim «№1 производитель в России» — self-claim, не независимо верифицирован. vc.ru-источник в этой проверке не найден. TOMEOW и «Кот Барон (Тумяу)» — два разных ИП, не путать.

**Для M2-05:** TOMEOW — low-tier картонный фон категории, не peer Alien Cat ни по материалу, ни по цене, ни по сценарию использования.

---

### K-TV-08 — Katacombas: формат бизнеса и активность

**Запрос:** `Katacombas мебель для кошек дизайн домики комплексы цены`

**Что найдено:**

- Sberbusiness.live (2023-12-20) — большое деловое интервью: основательница Дарья Сулыга (СПб), статус — самозанятая, выручка 150 000 ₽/мес, бренд с 2017 года, ассортимент «когтеточки, миски с подставками, домики, ступеньки, корзинки и гамаки». Прямые цитаты Дарьи об экспериментах с фанерой и тканью.
- Sobaka.ru (2022-09-06) — Katacombas как один из 11 российских брендов: «усатый тестировщик Шани, в соцсетях отличные мемы, на сайте большой выбор мебели и аксессуаров для кошек и собак».
- Собственный блог бренда `poleznyj.katacombas.com` — фирменный язык: «Wabi-Sabi Woodstock», «бетонные алтари», «деревянные алтари», «настенная когтеточка бохо», «алтайский ивовый прут».
- Адреса в СПб: Тверская ул., 12/15Б (точка по будням и субботам до 22:00) и Аптекарский просп., 2 (точка пн-пт 09:00–18:00).

**Verdict:** `SUPPORTED`. Katacombas — реальный, активный российский бренд из СПб с двумя точками в городе и собственным языком позиционирования.

**Caveat:** Формат бизнеса — самозанятая Дарья Сулыга. Это не корпоративный premium peer Alien Cat. Бренд использует слово «Wabi-Sabi» в продуктовой коммуникации (важно для M6: эта эстетическая территория уже занята).

**Для M2-05:** Katacombas — design-сегмент mid-цены с сильным голосом и собственной мем-стилистикой. Не прямой peer Alien Cat по цене, но конкурент по эстетическому позиционированию «природный/wabi-sabi/крафт». ВАЖНО: ранее в salvage-аудите фигурировал claim «природный эко-люкс / wabi-sabi как ось Alien Cat» — но эта территория уже маркирована Katacombas. Это сильный сигнал для M6.

---

### K-TV-09 — Глобальные премиум-бренды: цены и легитимность

**Запросы:**
1. `Tuft and Paw modern cat furniture price Cove cat tree luxury 2026`
2. `RHRQuality cat tree premium large Maine Coon price catalog 2026`
3. `LucyBalu cat furniture luxury design Germany price collaboration`

**Что найдено:**

**Tuft+Paw (USA):**
- Cove Modern Litter Box: $199 (прямая цена с карточки).
- Grove Modern Cat Tower: $399 (со скидкой 25%, от $499).
- Frond Cat Tree: $209 (от $299).
- Stellar Cat Bed: $239 (от $299).
- Nuzzle Cat Bed: $135 (от $169).
- Litter Box Scoop: $25, Cubby Litter Box: $69.
- Сторонний обзор thevetdesk.com (2026-01-05) — «one of the most modern and stylish luxury cat furniture on the market», «high price... for people that want modern, high-quality furniture and aren't limited by a budget».

**RHRQuality (NL/UK):**
- Maine Coon Tower Crown (Cream) 255–275 cm: €451,41 (карточка обновлена 2026-01-27). 20 cm sisal, кастомная высота 2–2.95 м.
- Cat Tree Cat Paradise (Cream): €509, Blackline Plus (Light Grey): €589.
- Panther XXL (Beige) для большых пород: £529 (UK).
- Maine Coon Lounge: €169–199, Devon Rex: €199, Corner Coon: €299, Cat Penthouse: €419.
- Подтверждено `RHR Pets` как retailer, EU/UK сегмент large breeds.

**LucyBalu (DE):**
- Self-positioning: «Premium brand for cats and their humans» (`lucybalu.com`).
- Производство «as far as possible by small manufacturers in Germany».
- Коллаборации: Choupette × Karl Lagerfeld SWING hammock (limited 1000 exemplars), sieger design (GARÇON s.v.p. напкоятиоиник), Hanna Krüger (urn / Trinkbrunnen / porcelain).
- LucyBalu упоминается «als einer der besten Designer:innen Deutschlands» в AD Magazin (нем.).
- Контекст: «in Deutschland mehr als 16 Millionen Katzen, in Europa weit über 100 Millionen».

**Verdict:** `SUPPORTED`. Все три бренда — живые в 2026, цены и продуктовые матрицы верифицированы.

**Для M2-05 (global benchmark):**
- L-сегмент Alien Cat (75-100 тыс. ₽ ≈ €750–1000) находится в зоне RHRQuality Maine Coon Tower Crown €451 + Cat Paradise Blackline Plus €589 и Tuft+Paw Grove Cat Tower $499. То есть Alien Cat L по цене сопоставим с топ-комплексами западного премиума.
- LucyBalu даёт пример того, как luxury bridge через интернациональные дизайн-коллаборации (Karl Lagerfeld / sieger / Hanna Krüger) превращает категорию в дизайн-объект. Для Alien Cat это benchmark M6/M7 (как растить media legitimacy), не M2-05 как direct competitor.
- Tuft+Paw Cove Litter Box $199 — закрывает старый M2-03 caveat: «Cove не 599$, а 199$» подтверждён.

---

### K-TV-10 — Российские дизайн- и lifestyle-медиа: публикации о российской мебели для кошек

**Запросы:**
1. `AD Magazine Russia дизайн мебель кошек российские бренды публикация 2023 2024 2025`
2. `Sobaka.ru myDecor российские бренды мебель для кошек публикация 2024 2025`

**Что найдено:**

**AD Russia (`admagazine.ru`):**
- 2019-12-26 — «Наше русское: мебель для домашних животных Murr and Woof» (автор Софья Шатохина) — материал о российском бренде + дизайнерская ткань Kvadrat/Raf Simons на изделиях.
- 2019-05-21 — «Модульная мебель для кошек» (Catastrophicreations Cat Mod, US).
- 2020-02-11 — «Cat Flat: дом для кошек от 24Storage» (Швеция).

**Sobaka.ru:**
- 2022-09-06 — «11 российских брендов для любимых кошек и собак: классные шлейки, свитеры, когтеточки и уютные домики» — большой материал, в подборке Katacombas, Cat Brand, TOMEOW и др. Актуализирован 18.11.2024.
- Тематическая рубрика `sobaka_loves_locals` — регулярно работает с локальными брендами.

**myDecor:**
- 2025-06-12 — «Сделано с душой: коллекция для домашних питомцев Anima» (российский бренд ADJ Style, основательница Екатерина, корзины-лежанки + домик + подставка с мисками). Это свежая 2025-публикация дизайн-медиа о российской pet-furniture коллекции.
- 2024-03-29 — материал о коллекции ИКЕА Lurvig.

**Build2Last:**
- 2024-12-26 — материал «Увлекательный лабиринт для кошек и мебель для людей: модульная система CATable 2.0» (LYCS Architecture, азиатский дизайн).

**Verdict:** `SUPPORTED`. Российские дизайн- и lifestyle-медиа реально работают с темой мебели для кошек.

**Для M2-05:**
- Категория «дизайнерская мебель для кошек как интерьерный объект» имеет подтверждённый media legitimacy layer в РФ: AD Russia, Sobaka.ru, myDecor, Build2Last.
- Свежий 2025-материал myDecor про Anima от ADJ Style показывает, что медиа продолжают находить новых российских игроков для публикаций — это потенциальная точка входа для Alien Cat в M7.
- НО: ни одна из этих публикаций не доказывает, что медиа — продажный канал. Это legitimacy layer, как и фиксирует `SOURCE-PACKET.md` § 2.7.
- D-XSV-13 (СРЕДНЕ): «работают ли эти редакции с подобным контентом сейчас» — `YES`, подтверждено myDecor 2025-06-12.

---

## 4. Источники

### Российские бренды (прямая верификация)

- Catsby Family — https://catsby-family.ru/, https://catsby-family.ru/ar, https://catsby-family.ru/catalog, https://catsby-family.ru/housepet, https://catsby-family.ru/step-3-nw
- Teddy Room — https://teddy-room.ru/, https://teddy-room.ru/catalog, https://teddy-room.ru/catalog/products-for-cats/scratching-posts
- Cat Brand — http://cat-brand.ru/, http://cat-brand.ru/agreement, http://cat-brand.ru/tproduct/613291153-577878499731-domik-shanti, https://cat-brand.orgs.biz/
- PETTEL — https://catpeople.ru/catification/pettel.html, https://design-milk.com/modern-pet-feeders-beds-and-more-from-pettel/, https://domasan.ru/statyi/portret-stilynaya-mebely-dlya-hvostatyh-pitomtsev-ot-pettel-design-stsetivw-vs~67190581
- TOMEOW — https://tomeow.homezoomarket.ru/, https://homezoomarket.ru/tag/tomeow/
- Katacombas — https://poleznyj.katacombas.com/tpost/4h35y17mg1-novinki-i-eschyo-koe-chto, https://sberbusiness.live/publications/zapisyvaemsia-na-kogotochki-kak-samozaniataia-iz-peterburga-prodaiot-mebel-dlia-koshek-na-150-000-v-mesiats, https://sankt-peterburg1.jsprav.ru/korma-dlya-zhivotnyih/katacombas-stilnaia-mebel-dlia-zhivotnykh/
- Hunnkatt — https://hunnkatt.com/
- LUI CATON — https://lui-caton.ru/
- Murr & Woof / Supaform / PURR MURR — https://www.admagazine.ru/design/nashe-russkoe-mebel-dlya-domashnih-zhivotnyh-murr-and-woof, https://www.snorhaar.com/shop/travel-cat-bag/, https://supaform.studio/, https://wolmagazine.com/journal/design/supaform, https://purr-murr.ru/materials-and-colors, https://purr-murr.ru/nekomoricatbed

### Зарубежные benchmarks

- Tuft+Paw — https://www.tuftandpaw.com/products/cove-litter-box-full, https://www.tuftandpaw.com/products/grove-cat-tower, https://www.tuftandpaw.com/collections/modern-cat-furniture, https://www.tuftandpaw.com/collections/all
- The Vet Desk (обзор Tuft+Paw) — https://thevetdesk.com/pet-lifestyle/cats/tuft-and-paw-modern-cat-furniture-review/
- RHRQuality / RHR Pets — https://rhrpets.com/en/collections/scratch-post-maine-coon, https://rhrpets.co.uk/collections/cat-tree-for-large-cats, https://rhrpets.com/en-de/products/krabpaal-maine-coon-tower-crown-creme-1
- LucyBalu — https://lucybalu.com/en, https://lucybalu.com/, https://lucybalu.com/pages/collabs

### Российские дизайн-медиа / legitimacy layer

- AD Russia: 2019-12-26 Murr and Woof, 2019-05-21 Catastrophicreations Cat Mod, 2020-02-11 Cat Flat 24Storage.
- Sobaka.ru: 2022-09-06 «11 российских брендов», https://www.sobaka.ru/lifestyle/design/154589 (актуализация 2024-11-18); рубрика `sobaka_loves_locals`.
- myDecor: 2025-06-12 «Сделано с душой: коллекция Anima от ADJ Style» https://mydecor.ru/news-design/sdelano-s-dushoi-kollekciya-dlya-domashnikh-pitomcev-anima/; 2024-03-29 ИКЕА Lurvig https://mydecor.ru/news/design/novaya-kollekciya-ikea-dlya-domashnikh-pitomcev/.
- Build2Last: 2024-12-26 CATable 2.0 https://build2last.ru/blog/modulnaya-sistema-catable-20-ot-lycs-architecture/.

### Сторонние блоги / агрегаторы

- O-XX Design — https://o-xx.ru/blog/furniture-for-pets (обзор Robbie house, WOODOG, российских pet-design брендов).
- Region29 — https://region29.ru/2021/12/06/61adfb1cbba6674f2b711ca2.html (архангельский pet-инфлюенсер кот Рыжик, 16k Instagram, рекламодатели — корма, аксессуары, косметика по уходу за шерстью).
- SMM-agentstvo.ru — портфолио SMM-продвижения питомников мейн-кунов (контекст для M4/M7).

---

## 5. Ограничения проверки

1. **Tool limitation:** Exa возвращает highlights и метаданные, но не всегда полный markdown сайта. Часть данных Teddy Room и Catsby Family пришлось восстанавливать по нескольким страницам, потому что главный markdown отдавался частично как binary. Эта проверка НЕ заменяет полный crawl сайта; для M2-05 Research нужны прямые scrape-снимки с полным каталогом и датой доступа.
2. **Сроки публикаций маркетплейс-цен:** Carousel цен Tuft+Paw / RHRQuality зависит от скидки, валюты и региона. Указанные диапазоны — это срез на 2026-05-29 по официальным сайтам и retailer-партнёрам.
3. **vc.ru / Tomeow:** упоминание TOMEOW на vc.ru, ожидавшееся из salvage backlog, в этой проверке Exa не нашёл. Это `NOT_VERIFIED`, а не `REJECTED` — возможно, материал был, но Exa его не подсветил.
4. **Murr & Woof rebrand / PURR MURR:** найденный домен `purr-murr.ru` похож на преемника Murr & Woof, но без owner-подтверждения это `WEAK_SIGNAL`. Для M2-05 Research нужно прямо спросить клиента или провести независимую верификацию.
5. **Avito / private makers:** эта проверка НЕ покрывала Avito-выгрузку (она вынесена в § 5.3 SOURCE-PACKET как отдельный пакет). Без Avito-выгрузки M2-05 не может быть закрыт как Research.
6. **Pet-инфлюенсеры РФ:** найден один полезный кейс (кот Рыжик из Архангельска, 16k Instagram), но это не systemic landscape российских pet-инфлюенсеров и не доказательство коллабораций с pet-furniture брендами. Для M4/M7 нужен отдельный pass.
7. **Дизайн-медиа как канал продаж:** проверка подтверждает категориальную легитимность (медиа публикуют), но НЕ подтверждает медиа как продажный канал. Все выводы в этом направлении остаются на гипотезу M7.

---

## 6. Следующий допустимый шаг

После этой verification остаётся два допустимых следующих gate:

**Опция A — Research Brief напрямую:** на базе SOURCE-PACKET + этой verification собрать `M2-05-RESEARCH-BRIEF.md` с явными `SUPPORTED` / `SUPPORTED_WITH_CAVEAT` ярлыками и source-map contract.

**Опция B — Avito/marketplace выгрузка перед Brief:** если методконтроль решит, что Avito-слой критичнее, чем у Catsby/Teddy/Murr, то перед Brief нужна отдельная выгрузка по § 5.3 SOURCE-PACKET.

Без owner-решения по этим двум опциям остаётся:

`TARGETED_VERIFICATION_DONE / NO_RESEARCH_READY / NO_CLIENT_READY / SYNTHESIS_BLOCKED / HTML_BLOCKED`

---

*M2-05 Targeted Verification | Alien Cat | 2026-05-29 | 10 проверенных claims | 6 SUPPORTED + 4 SUPPORTED_WITH_CAVEAT*
