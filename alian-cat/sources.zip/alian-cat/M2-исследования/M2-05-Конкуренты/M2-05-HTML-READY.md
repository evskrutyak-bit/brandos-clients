# M2-05 HTML — Gate Stamp (PATCH-02: terminology downstream-safety)

> **СТАТУС ФАЙЛА:** ниже один актуальный CURRENT verdict. Всё, что ниже разделителя «История / отменённые статусы», — HISTORY / NOT CURRENT.

**Verdict:** `HTML_READY` — **OWNER-ACCEPTED 2026-06-05** (PATCH-02; Дима вычитал глазами, принял RESEARCH + SYNTHESIS)
**HTML provenance:** `built_from_client_md_hash: d6712e0a419130d2` — встроен в `html/M2-05-RESEARCH.html` (sha256[:16] от обновлённого `M2-05-RESEARCH-client.md`). derive_state AC-M2-05 --check = PASS.
**Deploy:** делает Codex отдельной командой (хаб + карточка). На момент accept — не задеплоено.

> **PATCH-02 — почему переоткрыт owner-accepted статус.** Прежний `HTML_READY` (owner-accepted 2026-06-05 12:20, provenance `ee06b621d8fc6c92`) → **REVOKED / OBSOLETE** из-за source terminology patch: в `M2-05-RESEARCH-client.md` исправлена рамка M2 «развилки» → «гипотезы» (source poisoning, 12 мест), иначе термин ушёл бы в KARTINA/M3/M6/M7. Source изменился → старый hash и старый accept недействительны. HTML пересобран под новый client.md, новый provenance замкнут. **Нужен повторный owner eye-check.** Deploy/hub НЕ делались.

**Изменения PATCH-02 в RESEARCH HTML (терминология, без структуры):**
- §9 eyebrow «09 · Развилки» → «09 · Гипотезы»; title «…позиционные развилки» → «…позиционные гипотезы»
- §9.4 h3 «Позиционные развилки для M6» → «Позиционные гипотезы для M6»
- 5 obs-title «Развилка по …» → «Гипотеза по …»
- alert «а развилки, требующие» → «а открытые гипотезы, требующие»
- contract-таблица «позиционные развилки» → «позиционные гипотезы»
- TECH после правок: section 11/11, div 717/717 — баланс цел.

---

## ⤴ Прежний CURRENT (PATCH-01, 2026-06-05 12:20) — REVOKED PATCH-02

**Verdict:** ~~`HTML_READY` (owner-accepted 2026-06-05 12:20)~~ — **REVOKED PATCH-02** (source terminology patch)
**HTML provenance:** ~~`ee06b621d8fc6c92`~~ — устарел (источник изменён).
**Round 6 закрыт:** §5 + §7 tier-block баг починен (8 блоков перестроены); §8.11 «8 глобальных трендов» переведён из check-list в таблицу 4×8 (Тренд / Что значит / Глобально / В России).
**Date:** 2026-06-05
**Module:** M2-05 Конкуренты
**Client:** Alien Cat
**Stamped by:** Claude (Opus 4.7, 1M context), session `c28076a6-1282-4db7-b5be-6b5f8587a022`

---

## Round 5 — TERMINOLOGY_PATCH (2026-06-05)

**Trigger:** Дима поймал клиентскую таксономию первого экрана: «лига» как базовая таксономия не работает; двойная вложенность «кластер → лига» путает; Wabi-Sabi Woodstock без inline-расшифровки.

**Что сделано:**

1. **Terminology в client.md и HTML синхронно** (Python smart-replace, не blind replace_all):
   - «лига» → «сегмент» (все 28 вхождений в основном тексте + UI hero stat-label + eyebrow + section-sub + HTML-комментарии + словарь подзаголовков)
   - «кластер» → «контур» (внутри российского прямого) / «сегмент» (для CatioCat ультра-уровня) / «глобальные ориентиры» (для глобальных)
   - Грамматическое согласование родов: «Первая / Вторая / Третья / Четвёртая —» → «Первый / Второй / Третий / Четвёртый сегмент» в §1 decision-box.

2. **Wabi-Sabi Woodstock — inline-расшифровка** при первом упоминании в §1 (Katacombas карточка-резюме):
   > *«Wabi-Sabi Woodstock»* **(фирменная языковая территория Katacombas вокруг японской эстетики вабисаби — несовершенство и природная фактура)** как название собственного продукта.

3. **Sticky nav обновлён:**
   - pill «Категории» → **«Контуры»** (соответствует новой таксономии).
   - Добавлен **12-й pill «Словарь»** → `#glossary` (anchor добавлен на H3 Приложения В).

4. **§7 «Каналы конкурентов» — вёрстка починена.**
   Builder положил длинный текст («Avito и Ярмарка Мастеров — канал частных мастеров» и т.п.) в `.tier-label` — компонент с фиксированным размером 40×40px для цифры. Текст наезжал на основной `<p>`. Переделано в каноническую структуру:
   ```html
   <div class="tier-block">
     <div class="tier-header">
       <span class="tier-label tier-label--N">N</span>   <!-- цифра -->
       <h3 class="tier-name">Длинное название канала</h3>
     </div>
     <p>...</p>
   </div>
   ```
   4 из 4 tier-block в §7 перестроены.

5. **Заголовки разделов:**
   - §2 H2: «Категории игроков» → **«Контуры конкурентного поля»**
   - §2.1: «… четыре лиги внутри одного кластера» → **«… четыре сегмента внутри прямого контура»**
   - §2.3: «Глобальный ориентир категории — мировой дизайн-премиум» → **«Глобальные ориентиры — мировой дизайн-премиум»**
   - §2.4: «Сводная таблица категорий и лиг» → **«Сводная таблица контуров и сегментов»**

**Проверки:**

| Метрика | До | После |
|---|---|---|
| «лиг*» в HTML (видимый текст + comments) | 28 | **0** |
| «кластер*» в HTML | 29 | **0** |
| Wabi-Sabi Woodstock inline-расшифровка | нет | **есть** в §1 (client.md + HTML) |
| 11 → 12 pills в sticky nav | 11 | **12** (+ «Словарь» → `#glossary`) |
| `#glossary` anchor на Прил.В | нет | **есть** |
| §7 tier-header структура | 0 (сломано) | **4 канонических блока** |
| HTML mtime > client.md mtime | n/a | **client 11:55:04 < HTML 11:55:14** ✓ |

Бэкапы:
- `M2-05-RESEARCH-client.md.bak-terminology` (до terminology pass)
- `html/M2-05-RESEARCH.html.bak-pre-terminology` (до HTML terminology+UI patch)

---

---

# ⤵ История / отменённые статусы (HISTORY — NOT CURRENT)

> Всё ниже — трейл прошлых раундов. Перекрыто CURRENT verdict сверху (`HTML_READY`, owner-accepted 2026-06-05 12:20). Не использовать как действующий статус.

## ~~Почему не HTML_READY ещё~~ — `HISTORY / NOT CURRENT`

> **Снято:** owner закрепил `HTML_READY` 2026-06-05 12:20 (eye-check пройден). Текст ниже описывал состояние ДО owner-acceptance.

Дима явно сказал: «M2-05 HTML не закреплять как финальный HTML_READY. Статус: TERMINOLOGY_PATCH_REQUIRED.» После применения patch — статус становится `TERMINOLOGY_PATCHED, awaiting eye-check`. Финальный HTML_READY ставит **владелец после визуальной проверки**, не Claude. По правилу E16 / E17 + HANDOFF 2026-06-04 — это owner-acceptance level.

---

## Что НЕ сделано (по контракту)

- **Не deploy.** HTML локальный.
- **Не запущен SYNTHESIS.**
- **Не запущен KARTINA.**

Жду либо «закрепляй HTML_READY» (если читка глазами Димы прошла), либо новый patch-list.

---

## Источники (прежние Round 1–4) — `HISTORY`

# ~~M2-05 HTML-READY — Gate Stamp (Patched)~~ — `REVOKED / NOT CURRENT`

**Verdict:** ~~`HTML_READY`~~ (после применения PATCH_REQUIRED-протокола) — **REVOKED 2026-06-05 в Round 5, статус снят до eye-check; далее перекрыт CURRENT verdict (owner-accepted 12:20). Историческая запись.**
**Date:** 2026-06-05
**Module:** M2-05 Конкуренты
**Client:** Alien Cat
**Stamped by:** Claude (Opus 4.7, 1M context), session `c28076a6-1282-4db7-b5be-6b5f8587a022`

---

## Source chain

| Поле | Значение |
|---|---|
| MD source | `M2-исследования/M2-05-Конкуренты/M2-05-RESEARCH-client.md` |
| MD mtime | 2026-06-04 23:06:52 |
| MD size | 1 561 строка, 372 KB |
| Language gate | `M2-05-LANGUAGE-READY.md` (Verdict `CLIENT_LANGUAGE_PASS`, 4 verifier-runs) |
| HTML output | `M2-исследования/M2-05-Конкуренты/html/M2-05-RESEARCH.html` |
| HTML mtime | 2026-06-05 10:38:40 |
| HTML size | 243 KB (было 175 KB до P1+P2+P3) |
| Ordering | HTML mtime > MD mtime ✓ |

---

## История проверок и патчей

| Round | Verdict | Источник | Что сделано |
|---|---|---|---|
| 1 | `BUILT, awaiting Claude eye-check` | Sonnet builder agentId `a11e73b6cbbf0e3a3` | Skeleton-first + section-by-section сборка |
| 2 | Claude post-build | — | 3 точечных Edit: 4 nav-label по спецификации + 2 битых href к M2-04 |
| 3 | PATCH_REQUIRED (Дима) | Eye check | Нет приложений А/Б/В; language-регрессии D2C/AR/SKU/POV/ESG; inline-styles 79 |
| 4 | Claude PATCH-run | Sonnet rate-limit → Opus сам | P1 + P2 + P3 (см. ниже) |

---

## P1 — Приложения добавлены

| Приложение | Заголовок в HTML | Содержание | Статус |
|---|---|---|---|
| А | `<h3>Приложение А — все цитаты</h3>` | `<table class="table-brandos">` с 67 цитатами (все 67 из MD строк 1286–1352) | ✓ |
| Б | `<h3>Приложение Б — исходники и карта источников</h3>` | Б.1 — 5 источников в `<ol>` + блок «контекста»; Б.2 — `<table>` контракта покрытия 15 пунктов (все ✓) | ✓ |
| В | `<h3>Приложение В — словарь терминов и иностранных названий</h3>` | 7 `<dl class="glossary">` подсекций: Иностранные термины / Зарубежные бренды / Российские бренды / Маркетплейсы / Аналитика / Дизайн-медиа / Выставки | ✓ |

Все приложения вставлены внутри section `#sources` после блока «alert--ok / что закрыто в M2-05». Anchor-id остались прежними — 11 штук в sticky nav.

---

## P2 — Language-расшифровки first-use в HTML

| Аббревиатура | Где | Что стоит сейчас |
|---|---|---|
| **D2C** | hero stat-desc (line 1127) | «российского D2C-кластера (D2C — прямые продажи производителя клиенту, без посредников)» |
| **AR** | section #summary decision-box (line 1161) | «связке AR-примерки (дополненной реальности) + рассрочка ×10 мес» |
| **SKU** | section #product (line 1288) | «отдельные позиции каталога (SKU)» |
| **POV** | section #brands карточка Katacombas (line 1448) | «POV-формат от лица кота» (билдер изначально применил расшифровку) |
| **ESG** | section #global (line 2336) | «маркеры устойчивого развития (ESG)» |

Все 5 first-use расшифровок присутствуют. Дальнейшие использования сокращений в документе — после расшифровки, допустимы.

---

## P3 — Inline-styles сокращены

| Метрика | Было | Стало |
|---|---|---|
| Всего `style=` в HTML | 79 | **42** (−47%) |

**Добавленные utility-классы** (в `<style>` блок):
- `.mt-6`, `.mt-8`, `.mt-10`, `.mt-12`, `.mt-14` — margin-top variants
- `.h3-sub`, `.h3-sub-14` — section-title h3 sub-variants
- `.h3-tier`, `.h3-tier-first` — лиги внутри section #brands
- `.h4-appendix` — H4 заголовков приложений
- `.obs-stack` — grid 1col stack для observation-cards
- `.glossary` + `.gloss-full` + `.gloss-tier` — словарь Прил.В с подзаголовками лиг и full-width записями

Оставшиеся 42 inline-стиля — точечные (отдельные font-size в hero/observation-card, единичные margin/padding), не подпадают под повторяющиеся паттерны.

---

## Hard check v1.3 (5 классов)

| Класс | Hits | Status |
|---|---|---|
| `.toplink` | 9 | ✓ |
| `.nav-loft` | 5 | ✓ |
| `.hero-loft` | 10 | ✓ |
| `.stat-card` | 5 (4 в hero `.stat-grid` + 1 inline) | ✓ |
| `.badge-dot` | 2 | ✓ |

---

## 11 sticky nav-pills

| # | Label | Anchor | id присутствует |
|---|---|---|---|
| 1 | Резюме | `#summary` | ✓ |
| 2 | Категории | `#categories` | ✓ |
| 3 | Бренды | `#brands` | ✓ |
| 4 | Продукт | `#product` | ✓ |
| 5 | Сервис | `#service` | ✓ |
| 6 | Язык | `#language` | ✓ |
| 7 | Каналы | `#channels` | ✓ |
| 8 | Глобальные | `#global` | ✓ |
| 9 | Разрывы | `#gaps` | ✓ |
| 10 | Что важно | `#takeaways` | ✓ |
| 11 | Источники | `#sources` | ✓ |

---

## Hero metrics

| Label | Value | Desc |
|---|---|---|
| Лиги | **4** | Различимых сегмента внутри российского D2C-кластера (D2C — прямые продажи производителя клиенту, без посредников) |
| Карточки брендов | **19** | Детальных профилей: российские + международные |
| Глобальные ориентиры | **13** | Международных брендов-бенчмарков категории |
| Цитаты брендов | **67** | Прямых высказываний и формулировок из материалов брендов |

Все 4 — про предмет исследования, не про процесс. Никакого word count, MCP, Exa, Firecrawl, agent, prompt, pipeline.

---

## Date check

«4 июня 2026» — в hero-meta-loft (`<span class="hero-meta-value">`) и в footer. Документ выпущен на дату публикации.

---

## Kitchen sweep

`grep -niE 'MCP|Exa|Firecrawl|Tavily|K-TV|D-XSV|P0|targeted|salvage|по выгрузке|source word|Users/admin|pipeline'` после фильтрации CSS-классов и `@media` правил:

- В авторском видимом тексте — **0 hits**.
- В Прил.Б.1 — **3 имени файлов** (`M2-05-TARGETED-VERIFICATION.md`, `M2-05-KONK-MCP-RESULTS.md`, `M2-05-MCP-2026-06-03.md`) как URL-идентификаторы реальных файлов в репо. Это легитимно (тот же контракт, что и для M2-05-LANGUAGE-READY: имена файлов trust trail, не методологический язык).

---

## Что НЕ сделано (по контракту)

- **Не deploy.** HTML локальный.
- **Не запущен SYNTHESIS.**
- **Не запущен KARTINA.**

---

## Real-run evidence chain

| Run | Что | Agent / Tool | Tool calls | Tokens |
|---|---|---|---|---|
| Builder | Initial M2-05-RESEARCH.html assembly | Sonnet Agent `a11e73b6cbbf0e3a3` | 52 | ~135k |
| PATCH-run | P1 + P2 + P3 (3 приложения + 5 расшифровок + inline-styles 79→42) | Sonnet rate-limited → Opus inline (Python для генерации Прил.А/Б/В + Edit) | ~30 | inline |

**Бэкап до PATCH-run:** `html/M2-05-RESEARCH.html.bak-html-patch` (если потребуется откат).

---

## Что разблокировано этим stamp

- **HTML-артефакт M2-05** готов как production-документ.
- **SYNTHESIS M2-05** может стартовать (Шаг 8) — берёт `M2-05-RESEARCH-client.md` как факт-источник.
- **HTML deploy** в `clients.brand-os.ru/alian-cat/m2-05/` — отдельным решением через `brandos-hub`/Codex.
