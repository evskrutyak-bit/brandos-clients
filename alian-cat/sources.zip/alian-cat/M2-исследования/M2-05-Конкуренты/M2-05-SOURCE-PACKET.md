# M2-05-SOURCE-PACKET - Конкуренты

Клиент: Alien Cat / Кошкин Дом  
Модуль: M2-05 Конкуренты  
Дата сборки: 2026-05-27  
Основание: `M2-05-SALVAGE-AUDIT.md = ACCEPTED_AS_INTERNAL_RECOVERY_LAYER`  
Режим: source packet only  
Статус: `NO_RESEARCH_READY / NO_CLIENT_READY / SYNTHESIS_BLOCKED / HTML_BLOCKED`

## 0. Граница файла

Этот файл - входной source packet для следующего методологического решения по M2-05. Он не является Research, Synthesis, клиентским артефактом, HTML-brief, gate-pass или ready-статусом.

Что сделано:

- собран clean competitor universe;
- разложены источники по иерархии P0-P4;
- составлена таблица "конкурент / категория / источник / что подтверждает / что не подтверждает / статус / что проверить";
- вынесен stop-list;
- зафиксирован DR/MCP backlog.

Что не делалось:

- не создавался `M2-05-RESEARCH.md`;
- не создавался `M2-05-SYNTHESIS.md`;
- не создавались HTML/hub/publish-изменения;
- не ставились `RESEARCH_READY`, `CLIENT_READY`, `HTML_READY`;
- legacy synthesis не превращался в структуру нового M2-05;
- не формулировались позиционирование, GTM, M3-решения или канальная стратегия Alien Cat.

## 1. Source hierarchy

| Приоритет | Слой | Файлы / источники | Как использовать | Ограничение |
|---|---|---|---|---|
| P0 | Принятые guardrails | `M2-03-RESEARCH.md`, `M2-04-RESEARCH.md`, `M2-04-RESEARCH-PATCH-01-CHANNELS-REPORT.md` | Жёсткая рамка: что уже принято по продукту, аудитории и каналам-гипотезам. | Не расширять M2-03/M2-04 внутри M2-05; не закрывать M3/M4/M6/M7. |
| P1 | Проверенные claims из fact-check | `_fact-check/M2-05-KONK-MCP-RESULTS.md` | Использовать только проверенные/скорректированные claims с датой проверки 2026-04-27. | Условия конкурентов динамичны; перед финальным Research нужны даты доступа и при необходимости повторная сверка. |
| P2 | Старый DR как raw | `Dr конкуренты/DR конкуренты ALianCAT.md` | Использовать как сырой список конкурентов, категорий, SKU, CX-тем и источников для нового source map. | Не считать accepted Research; часть ссылок повреждена `span_*`; часть claims не проверена. |
| P3 | Legacy synthesis как hypothesis | `Dr конкуренты/синтез конкуренты.md`, старые rendered HTML в `Dr конкуренты/html/` | Использовать только как список вопросов, развилок и методологических предупреждений. | Не принимать структуру, выводы, стратегические гипотезы, 90-day plans и канальные решения как M2-05. |
| P4 | Rejected / suspicious claims | `_fact-check/M2-05-KONK-suspicious-facts.md`, evaluator notes, stop-list из salvage audit | Использовать как блокировки и очередь targeted verification. | Нельзя передавать Claude как факт; только как "проверить / снять / ослабить". |

## 2. Clean competitor universe

### 2.1. Прямые РФ-конкуренты

Игроки, которые могут сравниваться с Alien Cat по продуктовой логике, визуальному уровню, интерьерности, кастому, цене, сервису или D2C-модели.

- Catsby Family
- Teddy Room
- PETTEL / Pettel
- Murr and Woof
- Cat Brand
- Katacombas
- Komod-Pet
- KotoSчастье
- КотаМ
- Мы Бобры
- Hunnkatt
- CatioCat
- Pet БМФ
- Пушок

### 2.2. Avito-мастера / частные мастера

Не единый бренд, а слой предложений, который важен из-за текущего канала Alien Cat и продуктовой близости отдельных изделий.

- Мастера Avito по запросам "когтеточка", "мебель для кошек", "домик для кошки", "коряга для кошки", "когтеточка из дерева", "мейн-кун когтеточка".
- Ярмарка Мастеров / локальные столярные мастерские.
- Частные мастера в VK/локальных сообществах, если будут найдены в DR/MCP.

Статус: не готовая competitor map, а обязательный слой для новой выгрузки.

### 2.3. Маркетплейсы

Маркетплейсы не являются конкурентами как бренды, но являются средой сравнения цен, отзывов, сроков доставки и альтернатив.

- Ozon
- Wildberries
- Яндекс Маркет
- Megamarket, если всплывает в ценовой проверке Catsby / Catit / масс-маркета.

Статус: marketplace evidence layer, не M7 channel decision.

### 2.4. Масс-маркет / mid

Нужны как заменители и низовой фон категории, а не как peer group для позиционирования Alien Cat.

- Trixie
- PetTails
- Catit / Vesper
- IKEA Lurvig / Utsaedd
- Зооник
- Домоседы
- Котосчастье
- PET PRIDE
- картонные игроки, если конкурируют по визуальному "дизайн за малый чек".

### 2.5. Дизайнерские бренды

Игроки, у которых важны визуальный код, интеграция в интерьер, бренд-язык, предметность и доверие.

- Catsby Family
- PETTEL / Pettel
- Murr and Woof
- Katacombas
- Tomeow
- ArtCarton
- Hunnkatt
- КотаМ
- CatioCat
- зарубежные benchmarks: MiaCara, Tuft+Paw, LucyBalu, RINN, The Refined Feline, Mau.

### 2.6. Зарубежные benchmarks

Использовать как сравнительные ориентиры, не как доказательство спроса в РФ.

- RHRQuality
- Lotus Cat Tower / The Refined Feline
- Tuft+Paw
- MiaCara
- LucyBalu
- Goldtatze
- Catastrophic Creations
- RINN
- Hicat
- Mau
- KBSPETS
- Bon Cat
- Armarkat
- Kattens No.1
- TOWALKER
- Dhanus Decor
- Miza / Peelorange

### 2.7. Дизайн-медиа как legitimacy layer

Дизайн-медиа фиксировать не как канал продаж, а как слой легитимации категории "предмет для кошки как часть интерьера".

- AD Russia / AD Magazine Russia
- myDecor
- Interior+Design
- Sobaka.ru
- CatPeople / профильные pet-media, если подтверждают дизайнерский контекст
- медиа и журнальные публикации конкурентов, если есть прямая ссылка

Статус: legitimacy layer. Нельзя писать, что публикация в медиа гарантирует заявки или продажи.

## 3. Competitor source table

Статусы claim:

- `P0_GUARDRAIL` - принято в M2-03/M2-04 как рамка.
- `P1_VERIFIED` - проверено fact-check.
- `P1_CORRECTED` - старый claim скорректирован fact-check / guardrail.
- `P2_RAW` - есть в старом DR, требует проверки.
- `P3_LEGACY_HYPOTHESIS` - есть в старом synthesis, только гипотеза/вопрос.
- `P4_REJECTED_OR_SUSPICIOUS` - нельзя использовать как факт.
- `NEEDS_VERIFICATION` - требует targeted verification / DR / выгрузки.

| Конкурент / слой | Категория | URL или источник | Что подтверждает сейчас | Что не подтверждает | Статус claim | Что проверить дальше |
|---|---|---|---|---|---|---|
| Alien Cat guardrail | P0 рамка продукта | `M2-03-RESEARCH.md` | Категория: дизайнерская интерьерная мебель и когтеточные изделия; S/M/L; натуральное дерево, канат, искусственный мех; кастом; текущий Avito; рабочая цена S 20-30, M 30-50, L 75-100 тыс. ₽. | Не закрывает финальную линейку, цены, позиционирование, GTM. | `P0_GUARDRAIL` | Удерживать как рамку при новом M2-05. |
| Audience/channel guardrail | P0 рамка аудитории | `M2-04-RESEARCH.md` | Avito как текущий канал; channel universe; дизайнеры - weak signal; заводчики/pet-инфлюенсеры - гипотезы; каналы не являются медиапланом. | Не доказывает эффективность каналов и не закрывает M4. | `P0_GUARDRAIL` | Не переносить старую M2-05 канальную стратегию в Research. |
| Catsby Family | прямой РФ / технологичный D2C / дизайнерский бренд | `https://catsby-family.ru/`; old DR; fact-check; M2-03 | Рассрочка 0% на 10 месяцев подтверждена на 2026-04-27; Catsby есть как продуктовый benchmark в M2-03; уточнена матрица WALL/VINE/TREE/STAND. | Старый диапазон 19-30 тыс. ₽ для комплексов; текущие AR/гарантия/условия сборки без свежей сверки. | `P1_VERIFIED` + `P1_CORRECTED` | Повторить scrape сайта и маркетплейсов: цены, AR, гарантия, рассрочка, нагрузка, доставка, SKU. |
| Teddy Room | прямой РФ / крафт / лофт | `https://teddy-room.ru/`; old DR | Есть в old DR как крафт-лофт игрок, тумбы/вольеры/домики, индивидуальность, маркетплейсы. | Акции, индивидуальный заказ, отзывы VK, сроки и актуальный ассортимент не подтверждены. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить сайт, Ozon/WB, отзывы, наличие "второе изделие за полцены", кастом, сроки. |
| PETTEL / Pettel | прямой РФ / интерьерная мебель для людей и питомцев | old DR; M2-03 competitor list; вероятный сайт/медиа требует уточнения | Фигурирует как интерьерный игрок / furniture-first reference. | Рассрочка, текущий ассортимент, активность и каналы не подтверждены. | `P2_RAW` / `NEEDS_VERIFICATION` | Найти официальный URL, проверить каталог, цены, условия, медиа-след. |
| Murr and Woof | РФ / luxury / B2B-premium / дизайн-медиа | AD Russia URL из fact-check: `admagazine.ru/design/nashe-russkoe-mebel-dlya-domashnih-zhivotnyh-murr-and-woof`; old DR | Публикация в AD Russia подтверждена; можно использовать как осторожный legitimacy fact без года. | Dubai/Milan showroom, Maison&Objet, €700, Kvadrat/Raf Simons, текущая география, цены, сервис - не подтверждены. | `P1_VERIFIED` + `P4_REJECTED_OR_SUSPICIOUS` | Прямая проверка сайта/соцсетей/архивов выставок/каталогов. |
| Cat Brand | РФ / эко / плетёная лоза | old DR | Есть как эко-ориентир по натуральному материалу. | Экспорт в 10+ стран, "алтайские мастера", дилеры и актуальный ассортимент не подтверждены. | `P2_RAW` / `P4_REJECTED_OR_SUSPICIOUS` | Найти официальный URL, проверить ассортимент, географию, материалы, каналы. |
| Katacombas | РФ / дизайнерский mid / комьюнити | `https://vk.com/katacombas`; old DR | Есть как бренд с ярким TOV/мем-комьюнити в old DR. | TikTok/Instagram активность, текущий ассортимент, цены, виральность не подтверждены. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить VK, сайт, соцсети, ассортимент, актуальность бренда. |
| Tomeow | РФ / картонная дизайнерская мебель | `https://tomeow.homezoomarket.ru/`; old DR | Есть как картонный дизайн-ориентир и низкий ценовой фон. | "№1", текущие цены, статус ассортимента, каналы и отзывы не подтверждены. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить сайт, Ozon/WB, цены, отзывы, материалы. |
| ArtCarton | РФ / картонная мебель | `https://artcarton.ru/`; old DR | Есть как картонный экологичный слой и персонализация. | Срок службы до 5 лет, текущие цены, ассортимент, доставка не подтверждены. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить сайт, цены, условия, продуктовую матрицу. |
| Komod-Pet | РФ / дерево / крафт | old DR | Есть как деревянный/эко игрок с слабой цифровой представленностью в old DR. | Актуальность, цены, канал, количество подписчиков, сайт не подтверждены. | `P2_RAW` / `NEEDS_VERIFICATION` | Найти активные площадки, каталог, цены, отзывы. |
| KotoSчастье / Котосчастье | РФ / mass-mid / деревянные комплексы | old DR; M2-03 mass-mid layer | Есть как массовый/средний заменитель. | Цены, ассортимент, активность и уровень интерьерности не подтверждены. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить официальный сайт/маркетплейсы, отзывы, текущие SKU. |
| КотаМ | РФ / модульно-сменный / сервис | M2-03 P0; old universe | M2-03 использует как пример сменных элементов, установки, утилизации, 3D-макета. | Не является глубоко проверенным в M2-05 как конкурентный профиль. | `P0_GUARDRAIL` / `NEEDS_VERIFICATION` | Включить в новый DR как mature service benchmark. |
| Мы Бобры | РФ / модульные системы / сервис | M2-03 P0; old universe | M2-03 подтверждает гарантию 5 лет, монтаж, котодромы, беговое колесо "Забава" как продуктовый reference. | Не закрыт полный конкурентный профиль, актуальные цены части SKU. | `P0_GUARDRAIL` / `NEEDS_VERIFICATION` | Проверить каталог, гарантию, сервис, цены, визуал, отзывы. |
| Hunnkatt | РФ / кастом / wall systems / тумбы | M2-03 P0; old universe | M2-03 фиксирует тумбы, визуализацию в Telegram, колесо Ekorn MAX, wall systems. | Для M2-05 нужен отдельный конкурентный профиль и источники. | `P0_GUARDRAIL` / `NEEDS_VERIFICATION` | Проверить сайт/соцсети, цены, кастом, доставку, визуальную подачу. |
| CatioCat | РФ / авторский ultra | M2-03 P0; old universe | M2-03 фиксирует как author/ultra reference 50-120 тыс. ₽ из DR. | Диапазон не закрыт direct-quote, нужен current source. | `P0_GUARDRAIL` / `NEEDS_VERIFICATION` | Найти официальный source, подтвердить цены и ассортимент. |
| Pet БМФ | РФ / ремонтно-сменные элементы | M2-03 P0 | Есть как пример сменных столбов/сервисного центра. | Не профиль M2-05, неизвестна релевантность как конкурент Alien Cat. | `P0_GUARDRAIL` / `NEEDS_VERIFICATION` | Проверить ассортимент и роль в competitor universe. |
| Пушок | РФ / AR / массово-средний | M2-03 P0 | Упоминается в M2-03 как AR-примерка и видеоинструкция. | Не был в старом M2-05 как крупный профиль. | `P0_GUARDRAIL` / `NEEDS_VERIFICATION` | Проверить текущие AR, каталог, цены, позиционирование. |
| Мастера Avito | Avito / частные мастера / DIY / крафт | old DR; old synthesis; M2-03/M2-04 guardrails | Важны как текущий канал и потенциально близкий продуктовый слой; Avito у Alien Cat зафиксирован как текущий поток. | Старые цены 8-25 / 10-70 тыс. ₽, "ровно тот же продукт", "провальный CX" без выборки. | `P3_LEGACY_HYPOTHESIS` / `NEEDS_VERIFICATION` | Нужна Avito-выгрузка и ручная классификация карточек. |
| Ярмарка Мастеров | private makers / handmade marketplace | old DR | Возможный слой частных мастеров и craft-продуктов. | Нет источников, цен, активных карточек. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить выдачу и релевантные продавцы. |
| Ozon | marketplace evidence layer | `https://www.ozon.ru/`; old DR links по Catsby/Teddy/Catit | Использовать как источник цен, отзывов, доставки, карточек и availability. | Не доказывает бренд-стратегию; цены/скидки динамичны. | `NEEDS_VERIFICATION` | Нужна выгрузка по брендам и запросам, date-stamped snapshot. |
| Wildberries | marketplace evidence layer | `https://www.wildberries.ru/`; old DR | Источник цен, отзывов, ассортимента и скидок. | Не доказывает прямую конкурентность; динамика цен. | `NEEDS_VERIFICATION` | Нужна выгрузка по брендам/запросам. |
| Яндекс Маркет | marketplace evidence layer | `https://market.yandex.ru/`; old DR | Источник импортных/массовых товаров, отзывов, availability. | Не закрывает премиум/D2C. | `NEEDS_VERIFICATION` | Выгрузка по запросам и брендам. |
| Catit / Vesper | импорт / mid-market / маркетплейсы | Ozon brand page из old DR; M2-03 | Есть как импортный модерн и заменитель через маркетплейсы. | Текущая доступность, цены и селлеры требуют проверки. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить Ozon/WB/Я.Маркет, официальность селлеров. |
| Trixie | масс-маркет / зооритейл | old DR / M2-03 mass layer | Нужен как массовый фон и язык категории. | Не peer group Alien Cat; детали не проверены. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить текущие популярные SKU и отзывы. |
| PetTails | бюджетный mass-mid | old DR / Яндекс Маркет source | Есть как низовой заменитель. | Текущие цены, устойчивость, отзывы не подтверждены. | `P2_RAW` / `NEEDS_VERIFICATION` | Marketplace scrape. |
| IKEA Lurvig / Utsaedd | исторический mass benchmark | Яндекс Маркет old source; M2-03 | M2-03 фиксирует сворачивание Lurvig/замену Utsaedd как контекст. | Не прямой конкурент; availability через параллельный импорт динамична. | `P0_GUARDRAIL` / `P2_RAW` | Проверить только как массовый фон. |
| Зооник / Домоседы / PET PRIDE | масс-маркет | M2-03 P0 | Нужны как фон массовой категории. | Не профиль M2-05 без отдельной проверки. | `P0_GUARDRAIL` / `NEEDS_VERIFICATION` | Решить, включать ли в новый DR как фон или исключить для фокуса. |
| RHRQuality | зарубежный benchmark / крупные породы / replaceable parts | M2-03 P0 | M2-03 подтверждает: крупный европейский игрок, Maine Coon, warranty/parts. | Не российский спрос; absolute "единственный" снят. | `P0_GUARDRAIL` | Использовать как benchmark по крупным породам и сменности. |
| Lotus / The Refined Feline | зарубежный benchmark / design + replaceable parts | M2-03 P0 | M2-03 фиксирует Lotus Cat Tower и replacement logic. | Точные review counts не использовать. | `P0_GUARDRAIL` | Проверить актуальные цены и parts/accessories, если включать в DR. |
| Tuft+Paw | зарубежный benchmark / furniture-first | M2-03 P0 | M2-03 использует как furniture-first и litter furniture reference; Cove $199 corrected. | Не доказывает РФ-спрос; old price $599 снят. | `P0_GUARDRAIL` | Использовать как benchmark, не как direct competitor. |
| MiaCara | зарубежный benchmark / luxury design | M2-03 P0 | Есть как premium/luxury design benchmark, Torre €559. | Не российская competitor reality. | `P0_GUARDRAIL` | Проверить актуальный каталог, если нужен western benchmark. |
| LucyBalu | зарубежный benchmark / design media / collaborations | M2-03 P0 | LucyBalu x Choupette подтверждена через caretaker framing. | Не использовать старые неточные атрибуции. | `P0_GUARDRAIL` | Только benchmark. |
| Goldtatze | зарубежный benchmark / кастом под потолок | old DR / M2-03 context | Полезен как западный кастомный ориентир. | Нужна свежая проверка каталога и цен. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить сайт/каталог. |
| Catastrophic Creations | зарубежный benchmark / wall systems | M2-03 P0 | M2-03 фиксирует wall systems и ценовой range. | Не доказывает РФ-спрос на стеновые системы. | `P0_GUARDRAIL` | Использовать как benchmark для M3 questions. |
| RINN | зарубежный luxury / art furniture | M2-03 P0 | RINN NEKO как extreme luxury benchmark. | Не переносить как рыночный ориентир РФ. | `P0_GUARDRAIL` | Только benchmark. |
| Hicat | зарубежный bespoke segment | M2-03 P0 | Формулировка ослаблена до "один из игроков UK bespoke-сегмента". | Не "флагман категории UK". | `P0_GUARDRAIL` | Только аккуратный benchmark. |
| Mau / KBSPETS / Bon Cat / Armarkat / Kattens No.1 | зарубежные benchmarks | M2-03 P0 | Используются для materials, replaceability, large cats, warranties. | Не direct competitors. | `P0_GUARDRAIL` | В новый M2-05 включать только при необходимости как reference appendix. |
| AD Russia | design-media legitimacy | fact-check + old DR | Публикация Murr & Woof подтверждена как факт. | Год 2019 не подтверждён Tavily; публикация не доказывает продажи. | `P1_VERIFIED` | Прямая проверка страницы и даты. |
| myDecor | design-media legitimacy | old synthesis / suspicious list | Может быть medium для категориальной легитимации. | Нет подтверждённых публикаций про конкретных конкурентов в старом M2-05. | `NEEDS_VERIFICATION` | Найти релевантные публикации или снять. |
| Interior+Design | design-media legitimacy | old synthesis / suspicious list | Потенциальный legitimacy source. | Не подтверждён как источник продаж или публикаций конкурентов. | `NEEDS_VERIFICATION` | Проверить публикации. |
| Sobaka.ru | design-media legitimacy | old synthesis / suspicious list | Потенциальный regional/lifestyle legitimacy source. | Не подтверждён как публикационный слой по конкурентам. | `NEEDS_VERIFICATION` | Проверить публикации. |
| CatPeople / pet-media | pet/design media | old DR | Может подтверждать категориальный язык и отдельные игроки. | Не sales channel. | `P2_RAW` / `NEEDS_VERIFICATION` | Проверить релевантные статьи. |

## 4. Stop-list

Эти формулировки нельзя передавать в Claude как факты и нельзя включать в будущий M2-05 Research без отдельного решения/проверки.

### 4.1. Murr & Woof luxury-claims

- шоурумы в Дубае и Милане;
- участие в Maison&Objet;
- мини-диван за €700;
- ткани Kvadrat / Raf Simons как текущий факт;
- текущая география "Москва / Дубай";
- пожизненный сервис / полная перетяжка как подтверждённый факт.

Разрешено только: "есть подтверждённая публикация в AD Russia" при наличии ссылки и аккуратной формулировки без неподтверждённого года.

### 4.2. Старые Avito-цены и выводы о мастерах

- "мастера Avito стоят 8-25 тыс. ₽";
- "мастера Avito стоят 10-70 тыс. ₽";
- "у них ровно тот же продукт";
- "у них провальный CX";
- "они главный конкурент по продукту" как утверждение без новой выгрузки.

Разрешено только: "Avito-мастера - обязательный слой для проверки, потому что Avito является текущим каналом Alien Cat".

### 4.3. 90-дневные планы, KPI и операционные прогнозы

- 30/60/90-дневный план продаж;
- цели 5-8 / 10-15 / 25-30 продаж;
- outreach 20 дизайнерам как задача;
- 3 reels в неделю как задача;
- KPI по дизайнерам и каналам;
- найм плотника/SMM;
- CRM, логистика, договорённости с курьерами как операционный план;
- прогнозы "без рассрочки теряется 15-25% сделок".

Это M7/операционный слой, не M2-05.

### 4.4. Дизайнеры как доказанный канал

Запрещено писать:

- дизайнеры уже являются каналом продаж;
- дизайнер гарантирует сделки;
- один дизайнер = 3-6 продаж в год;
- 3D/BIM-библиотека должна быть создана как решение.

Разрешено: "дизайнеры интерьеров - weak signal / M4_REQUIRED / legitimacy or influence hypothesis".

### 4.5. Absolute claims

Запрещено:

- "никто не делает";
- "нет прямой защиты";
- "безусловное лидерство";
- "рынок прочитает";
- "окно не вечное";
- "единственный игрок";
- "пустая ниша" без оговорки.

Разрешённая форма: "в проверенном массиве источников пока не найдено", "требует проверки", "выглядит как гипотеза".

### 4.6. Wabi-sabi как позиционирование Alien Cat

Запрещено писать как факт/решение:

- Alien Cat = wabi-sabi;
- "природный эко-люкс" как принятое позиционирование;
- "природная коряга = Alien Cat";
- "Дом, в котором красиво обоим" как H1;
- "продукт Avito + сервис Catsby" как главный вывод.

Разрешено только как M6 hypothesis / question: "есть ли основание проверять природную/биофильную эстетику как одну из возможных позиционных территорий?"

## 5. DR/MCP backlog

### 5.1. Что требует нового Deep Research

Новый DR нужен, если методконтроль решит, что старый DR недостаточен как source base.

DR должен собрать:

1. Актуальный competitor universe с активными источниками и датами доступа.
2. Разделение конкурентов по типам: прямые РФ, Avito/мастера, маркетплейсы, mass-mid, дизайнерские бренды, зарубежные benchmarks, design-media legitimacy.
3. Для каждого ключевого игрока: продуктовая матрица, цены, материалы, сервис, доставка, гарантия, сборка, кастом, визуальный стиль, каналы присутствия.
4. Отдельную карту marketplace evidence: Ozon/WB/Яндекс Маркет не как стратегия, а как среда сравнения.
5. Отдельную карту Avito/private makers: свежие карточки, цены, фото, доверие, юридичность, доставка, отличие от брендов.
6. Отдельную карту design-media legitimacy: публикации, не продажи.
7. Чистый source map: источник / что подтверждает / ограничение.

DR не должен:

- писать позиционирование Alien Cat;
- назначать стратегию каналов;
- писать цены/линейку Alien Cat;
- превращать M2-05 в M6/M7/M3.

### 5.2. Что требует targeted verification

Targeted verification нужен до или после DR по самым рискованным claims:

- Catsby Family: AR-примерка, рассрочка, гарантия, сборка, текущие цены и SKU.
- Teddy Room: индивидуальный заказ, текущие акции, маркетплейсы, отзывы, сроки.
- Murr & Woof: официальный статус, актуальная география, материалы, цены, AD Russia, снятие Dubai/Milan/Maison&Objet/€700/Kvadrat/Raf Simons claims.
- Pettel: официальный URL, ассортимент, рассрочка, медиа/интерьерная роль.
- Cat Brand: экспорт, материалы, дилеры, география, ассортимент.
- Katacombas: актуальность сайта/соцсетей, ассортимент, TikTok/Reels.
- Design-media: AD Russia, myDecor, Interior+Design, Sobaka.ru как legitimacy layer.
- Макроцифры: 433 млрд ₽ 2023 / 590 млрд ₽ 2025 использовать только как контекст, не размер ниши.

### 5.3. Что требует Avito/marketplace выгрузки

Avito:

- запросы: "когтеточка", "мебель для кошек", "домик для кошки", "когтеточка из дерева", "коряга для кошки", "мейн-кун когтеточка";
- поля: название, цена, город, материалы, фото/визуальная подача, юр./частное лицо, доставка, отзывы/рейтинг, сроки, кастом, ключевые формулировки;
- задача: понять, какие private makers реально конкурируют с Alien Cat по продукту/цене/доверю.

Marketplace:

- Ozon/WB/Яндекс Маркет по Catsby, Teddy Room, Catit/Vesper, Trixie, PetTails, Котосчастье, ArtCarton/Tomeow;
- поля: текущая цена, старая цена, скидка, рейтинг, число отзывов, доставка, seller, наличие, фото, описание, ключевые claims;
- задача: разделить marketplace price pressure и D2C premium peers.

### 5.4. Что оставить Claude как методологический вопрос

1. Где граница M2-05 vs M2-03: какие продуктовые игроки уже закрыты M2-03 и не должны повторяться глубоко?
2. Насколько широкий competitor universe нужен: только 8-12 ключевых игроков или полный слой с appendices?
3. Нужно ли включать Avito-мастеров в основной DR как отдельную категорию или вынести в targeted appendices?
4. Как развести "дизайн-медиа как legitimacy" и "каналы продаж" так, чтобы не уйти в M7?
5. Что делать со старой осью "Avito product + Catsby service": оставить как M6/M7 hypothesis или полностью снять из M2-05?
6. Нужно ли отдельное MCP-before-DR по Murr & Woof и Avito или сначала полный DR?
7. Какой следующий gate открыть: DR prompt/upload pack или targeted verification pack?

## 6. Минимальный upload/context pack для следующего шага

Если методконтроль разрешит следующий слой, Claude можно передать:

1. `M2-05-SOURCE-PACKET.md` - этот файл.
2. `M2-05-SALVAGE-AUDIT.md` - accepted internal recovery layer.
3. `M2-03-RESEARCH.md` - P0 product guardrail.
4. `M2-04-RESEARCH.md` + `M2-04-RESEARCH-PATCH-01-CHANNELS-REPORT.md` - P0 audience/channel guardrail.
5. `_fact-check/M2-05-KONK-MCP-RESULTS.md` - P1 verified/corrected claims.
6. `_fact-check/M2-05-KONK-suspicious-facts.md` - P4 suspicious queue.
7. `_fact-check/evaluations/M2-05-KONK-evaluator.md` - evaluator warning layer.
8. `Dr конкуренты/DR конкуренты ALianCAT.md` - P2 old raw DR.
9. `Dr конкуренты/синтез конкуренты.md` - P3 legacy hypotheses only.

Не передавать как accepted:

- `site/M2/M2-05-KONKURENTY-DR.html`;
- `site/M2/M2-05-KONKURENTY.html`;
- `Dr конкуренты/html/*`.

Их можно смотреть только как legacy/rendered output.

## 7. Следующий допустимый методологический выбор

После этого source packet методконтроль может выбрать один из двух безопасных путей:

1. Новый DR prompt/upload pack по M2-05, если нужен широкий пересбор конкурентного исследования.
2. Targeted verification pack по самым рискованным claims, если сначала нужно снять красные флаги Murr & Woof, Avito, Catsby, Teddy Room и дизайн-медиа.

До такого решения остаётся:

`NO_RESEARCH_READY / NO_CLIENT_READY / SYNTHESIS_BLOCKED / HTML_BLOCKED`

