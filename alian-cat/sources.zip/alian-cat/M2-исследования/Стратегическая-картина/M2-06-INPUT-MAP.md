# M2-06 KARTINA — Input Map (read-only prep)

> **Назначение:** инвентарь входов KARTINA по 5 направлениям M2. **НЕ KARTINA**, не генерация, не Writer/Pushkin. Только карта готовности входов + блокеры.
> **Дата:** 2026-06-05
> **Правило (owner, Дима):** KARTINA берёт как равный вход ТОЛЬКО client-ready / source-ready SYNTHESIS. Draft входом быть не может.

---

## Инвентарь входов M2-01…M2-05

| Направление | SYNTHESIS-вход | Статус MD | Готов для KARTINA? | SYNTHESIS HTML |
|---|---|---|---|---|
| **M2-01 Рынок РФ** | `DR рынки/Рынок рф/M2-01-FINAL-client.md` (legacy FINAL = SYNTHESIS) | «финальный короткий синтез для клиентского обсуждения» + ROUNDTABLE-CHECK + LANGUAGE-PREFLIGHT | ✅ **client-ready** (legacy-нейминг) | ✅ есть |
| **M2-02 Рынок мир** | `M2-02-Рынок-мир/M2-02-SYNTHESIS.md` | «выводы и гипотезы после глубокого исследования» + полный gate-набор (ROUNDTABLE-CHECK, COPYWRITER-PASS, LANGUAGE-PREFLIGHT, HTML-QC) | ✅ **client-ready** | ✅ есть |
| **M2-03 Продукт** | `M2-03-Продукт/M2-03-SYNTHESIS.md` | CLIENT-READY-GATE + DEPLOY-QC, **deployed** (b0fd1bc) | ✅ **client-ready** (deployed) | ✅ есть |
| **M2-04 ЦА** | `M2-04-ЦА/M2-04-SYNTHESIS.md` | ⛔ **«внутренний draft. Не клиентская версия и не CLIENT_READY»** (явно в шапке) | ❌ **НЕ готов — BLOCKER** | ❌ нет |
| **M2-05 Конкуренты** | `M2-05-Конкуренты/M2-05-SYNTHESIS.md` | CLIENT_READY PATCH-02 (гипотезы + стандартная self-description) | ⏳ **provisional** — ждёт owner eye-check | ✅ есть (awaiting eye-check) |

---

## Блокеры старта KARTINA (оба должны закрыться)

### 🔴 Блокер 1 — M2-04 SYNTHESIS = internal draft
- Файл `M2-04-ЦА/M2-04-SYNTHESIS.md` в шапке: «Статус: внутренний draft. Не клиентская версия и не CLIENT_READY».
- RESEARCH-сторона M2-04 закрыта (`M2-04-RESEARCH.md` ACCEPTED 2026-05-27, HTML есть).
- SYNTHESIS HTML M2-04 **отсутствует**.
- **Нужно:** довести M2-04 SYNTHESIS до CLIENT_READY по короткой схеме (Pushkin Synthesis Mode → SOURCE_COVERAGE → language → CLIENT_READY) + собрать SYNTHESIS HTML. Делать по **свежему канону** (гипотезы-рамка, hub-link, synthesis-description).

### 🟡 Блокер 2 — M2-05 provisional
- M2-05 RESEARCH + SYNTHESIS ждут owner eye-check. После accept — вход готов.

---

## Что каждый вход передаёт в KARTINA (carry-forward — указатели, не контент)

| Направление | Где лежит carry-forward в KARTINA |
|---|---|
| M2-01 Рынок РФ | гипотезы FINAL-client (таблица гипотез «как повлияет на следующие модули») |
| M2-02 Рынок мир | гипотезы SYNTHESIS (comfort-luxury / quiet luxury и др.) |
| M2-03 Продукт | SYNTHESIS гипотезы по продукту/ценам/SKU |
| M2-04 ЦА | сегменты/мотивы/барьеры — **после закрытия draft** |
| M2-05 Конкуренты | §7.1 SYNTHESIS: Wabi-Sabi занят, CatioCat-каркас, 4 сегмента, AR-практика, разведение Catsby D2C vs marketplace; §7.2 в M6, §7.3 в M3, §7.4 в M7 |

---

## Готовность к старту KARTINA

```
READY:        M2-01 ✅  M2-02 ✅  M2-03 ✅
PROVISIONAL:  M2-05 ⏳ (owner eye-check)
BLOCKED:      M2-04 ⛔ (draft → нужен CLIENT_READY + HTML)

KARTINA START = заблокирован до: M2-05 accept + M2-04 SYNTHESIS закрыт (MD CLIENT_READY + HTML)
```

## Рабочий порядок (owner, Дима)
1. Owner eye-check M2-05 RESEARCH + SYNTHESIS HTML.
2. Если принято — M2-05 закрепить / deploy отдельной командой.
3. Закрыть M2-04 SYNTHESIS по короткой схеме.
4. Собрать M2-04 SYNTHESIS HTML.
5. После этого — старт M2-06 KARTINA.

> Этот файл — только карта. KARTINA не генерируется, `M2-06-KARTINA.md` не пишется, Writer/Pushkin/Agent не запускаются до закрытия блокеров.
