<!-- STATUS: ФИНАЛ. Состав, источники, provenance-хеши, frontmatter-правило зафиксированы. owner-go на HTML дан 2026-06-16. Codex может запускать. -->

# TASK для Codex — HTML модуля M4 «Аудитория» (клиентские, обычный BrandOS) + публикация на хаб

> ⚠️ **READ-ONLY ВХОД.** Source MD — ЧИТАТЬ, не править. HTML = verbatim render (HTML ≠ MD по тексту/числам = ошибка).
> 🟢 Обычный публичный BrandOS-артефакт. БЕЗ плашки «INTERNAL», БЕЗ провенанс-хешей/«source MD»/кодов модулей в видимом тексте, БЕЗ серого management-вида.
> Схема — как M3 (`alian-cat/M3/`), прецедент: `M3-продукт/M3-03-06-CLIENT-HTML-TASK-CODEX-2026-06-11.md`.

## Источники — ТОЛЬКО эти 6 CLIENT-READY MD (все в `neyroupakovka/alian-cat/M4-аудитория/`)

| Документ (H1 из файла) | Source MD | Provenance (sha256[:16]) |
|---|---|---|
| Кто покупает Alien Cat: группы спроса | `M4-01-YADRO-SPROSA-CLIENT.md` | `69b822292f327ebd` |
| Аватары покупателей и их задачи | `M4-02-AVATARY-JTBD-CLIENT.md` | `1e37bd89cbb14b05` |
| Покупатель с интерьерным запросом — подробный портрет | `M4-03-SEGMENT-1-CLIENT.md` | `97179d838aaf33f2` |
| Путь покупателя: от первого интереса до заказа | `M4-04-PUT-POKUPATELYA-CLIENT.md` | `b7f43ca64b57ef84` |
| Язык аудитории | `M4-05-YAZYK-AUDITORII-CLIENT.md` | `5bff69c9a46ee86a` |
| Карта болей, мотиваций, барьеров и доказательств | `M4-06-KARTA-BOLEY-CLIENT.md` | `6d1773bcc1b4c512` |

> Только эти 6. Source-версии (`*-v1.md`, `*-v3.md`, `*-v2.md`), рабочие файлы (`*-WORKING-MAP`, `*-DECISION-FRAME`, `*-LOG`, `M4-00-INPUT-MAP`, sample, gate-файлы, эта задача) — НЕ источник и НЕ публикуются.

## FRONTMATTER — разобрать, НЕ выводить как текст (критично)

Каждый CLIENT-MD начинается с yaml-frontmatter (`provenance` + `hero_stats`). Наивный рендер вываливает его текстом — это ошибка.
- **`hero_stats`** → собрать hero-блок страницы (плитки value/label/desc как у M3-артефактов). source-поле — подпись/служебное, не выводить кодом.
- **`provenance`** → техническая метаданность (для QC можно вшить в html-комментарий/meta), **в видимый текст НЕ попадает**: ни «provenance», ни «produced_by», ни «real-agent», ни «методолог», ни сырой yaml на странице.
- В видимом HTML не должно быть остатков frontmatter.

## Сборка
1. **Verbatim render** тела CLIENT-MD (всё ниже H1) — дословно. Все таблицы и числа точно как в MD.
2. Стиль — обычный клиентский BrandOS-артефакт (hero из `hero_stats`, нормальная палитра/фазы, как у живых M3). Заголовок страницы — человеческий H1 из файла.
3. **Hub-возврат** как у других артефактов (toplink «К хабу клиента →» + nav-пилюля).
4. **fade-up:** `IntersectionObserver threshold:0` (НЕ 0.12 — на длинных секциях ломает fade, белая середина; известный баг).
5. ASCII-имена:
   `M4-01-YADRO-SPROSA.html` · `M4-02-AVATARY-JTBD.html` · `M4-03-SEGMENT-1.html` · `M4-04-PUT-POKUPATELYA.html` · `M4-05-YAZYK-AUDITORII.html` · `M4-06-KARTA-BOLEY.html`.
6. Скриншоты desktop + mobile по каждому.

## Деплой — обычная публичная схема (как все артефакты)
- Репо `evskrutyak-bit/brandos-clients`, branch `main`, каталог `alian-cat/M4/`.
- Добавить карточки M4 (6 шт.) в хаб клиента, обновить счётчик артефактов, обычная навигация (блок M4 рядом с M3).
- Коммит: `feat(alian-cat): M4 audience docs (demand-core/avatars/segment-1/journey/language/pain-map)`.

## После сборки — СТОП
НЕ объявлять готовность, НЕ закрывать сам. Передать Claude на независимый DEPLOY_QC.

## Условие приёмки (Claude DEPLOY_QC, не самоотчёт Codex)
По каждому из 6: live provenance == source-хеш · текст/таблицы/числа verbatim против CLIENT-MD · **в видимом HTML нет frontmatter** (provenance/produced_by/hero_stats-как-текст/сырой yaml) · нет кухни/англицизмов/кодов модулей (M4/M6/JTBD/БДФ/GTM/CRM/Хант)/«INTERNAL»/меток [гипотеза] · hub-возврат present · fade корректен (threshold:0) · нагрузка 10 кг. PASS/FAIL пер-артефакт. «M4 опубликован» — только после PASS по всем 6.

## Границы
НЕ трогать: сами MD, IZDELIE, рабочие исходники и внутренние файлы M4-зоны. Рендер только из 6 CLIENT-READY MD.

---
*TASK Codex · M4 клиентские HTML (обычный BrandOS, публичный деплой) · 2026-06-16 · 6 артефактов, verbatim, frontmatter разобрать-не-выводить, QC за Claude.*
