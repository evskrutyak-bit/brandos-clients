# DEPLOY-NOTES — Alien Cat

## Текущее состояние deploy (уточнено 2026-04-30, после проверки live)

**Live URL:** https://clients.brand-os.ru/alian-cat/

**Реальная модель deploy:** **Модель A** — клиент уже обслуживается из общего monorepo `evskrutyak-bit/brandos-clients` через путь `alian-cat/` → `clients.brand-os.ru/alian-cat/`. Никакой миграции архитектуры делать не нужно, она уже выполнена.

- Live-источник: `https://github.com/evskrutyak-bit/brandos-clients` (подпапка `alian-cat/`)
- Branch: `main`
- HTTP-заголовки live отдают `server: GitHub.com` — раздаёт инфраструктура поверх monorepo

## Параллельный legacy: evskrutyak-bit/alien-cat

Отдельный repo `evskrutyak-bit/alien-cat` остаётся как **legacy/параллельная копия**:

- Remote: `https://github.com/evskrutyak-bit/alien-cat.git`
- Имеет собственный workflow `.github/workflows/deploy.yml` → деплоит на Beget FTP (`i72250km.beget.tech`)
- Beget-копия не является источником live URL `clients.brand-os.ru`
- Bundle-бэкап локальной истории, удалённой из Studio: `archive/git-bundles/alian-cat-2026-04-30.bundle`

Открытая задача: подтвердить, что legacy alian-cat repo нигде не используется (Beget-хостинг, прежние ссылки, поисковая выдача), и архивировать его на GitHub как read-only. Делать отдельной сессией, ничего не сносить раньше времени.

## Фикс sources.zip (2026-04-30, commit `d360d98`)

Старый `alian-cat/sources.zip` имел кириллические имена файлов, которые на Windows/Finder при распаковке превращались в mojibake (`M0-в�?од/M0-01-�?Х�?�?�?�?�?-�?У�?�?Т.md`).

**Что сделано:**
- Архив пересобран с латинизированными ASCII-путями по образцу `loft-prostranstvo`.
- 17 файлов сохранены 1:1, поменялось только имя/путь, содержимое не тронуто.
- Старый размер 208934 байт (sha `8931f84d…`) → новый 209476 байт (sha `f9193d62…`).
- Push в `evskrutyak-bit/brandos-clients`: commit `d360d98 fix(alian-cat): rebuild sources.zip with ASCII paths`.
- Live `clients.brand-os.ru/alian-cat/sources.zip` обновился через 51 секунду; SHA live совпадает с локальным.

**Структура нового zip:**
```
alian-cat/M0/M0-01-VKHODNOI-AUDIT.md
alian-cat/M0/M0-02-BREND-BRIF.md
alian-cat/M1/M1-01-ID-PROFIL.md … M1-07-KARTA-BARYEROV.md
alian-cat/M2/01-RYNOK-RF/M2-01-RYNOK-RF-GIPOTEZY.md
alian-cat/M2/02-RYNOK-MIR/M2-02-RYNOK-MIR-GIPOTEZY.md
alian-cat/M2/03-CA/M2-03-CA-{DR,GIPOTEZY}.md
alian-cat/M2/04-PRODUKT/M2-04-PRODUKT-{DR,GIPOTEZY}.md
alian-cat/M2/05-KONKURENTY/M2-05-KONKURENTY-{DR,GIPOTEZY}.md
alian-cat/M2/M2-06-KARTINA.md
```

## Где живёт sources.zip

В Studio `.gitignore` действует правило `*.zip`, поэтому `neyroupakovka/alian-cat/site/sources.zip` **в Studio не закоммичен** и не является tracked-файлом. Архив существует только в deploy-monorepo `evskrutyak-bit/brandos-clients` и в локальной рабочей копии Studio. При пересборке zip пересобирается из исходных `.md` Studio по схеме переименования из этого DEPLOY-NOTES. Это сознательное решение: Studio = источник правды по контенту, monorepo = транспорт публикации.

## Историческая справка (75 файлов)

В момент удаления внутреннего `.git` у `neyroupakovka/alian-cat/` (2026-04-30) HEAD legacy alien-cat repo содержал 75 файлов, которых физически не было в `neyroupakovka/alian-cat/`. Проверено: все они присутствуют в `fabrika/alian-cat/` (ФК-песочница) — это были устаревшие копии, мигрировавшие в ФК по правилу клиентского CLAUDE.md. Потери нет.

## M2-02 RESEARCH publish (2026-05-22, commit `7b7792c`)

Опубликован M2-02 «Мировой рынок — глубокое исследование» после Patch E5 gate:

- `TECH_PASS`
- `CLIENT_LANGUAGE_ACCEPTED`
- `POST_RENDER_PASS`

Deploy repo: `evskrutyak-bit/brandos-clients`, path `alian-cat/`.

Изменены только:

- `alian-cat/M2/M2-02-RYNOK-MIR-DR.html` — заменён placeholder на финальный HTML research.
- `alian-cat/index.html` — карточка `M2-02 · Глубокое исследование` переведена в `Готово / v2.0 / 2026-05-22`.

Не менялось:

- `M2-02-RYNOK-MIR.html` — на момент RESEARCH deploy синтез оставался placeholder / «Пересобирается» до отдельной сборки SYNTHESIS. Закрыто отдельным deploy `3dd5a5f` от 2026-05-23.
- `sources.zip` — не обновлялся; source-bundle остаётся отдельным пайплайном.
- Legacy repo `evskrutyak-bit/alien-cat` — не используется.

Live:

- https://clients.brand-os.ru/alian-cat/M2/M2-02-RYNOK-MIR-DR.html
- https://clients.brand-os.ru/alian-cat/

## M2-02 SYNTHESIS publish (2026-05-23, commit `3dd5a5f`)

Опубликован M2-02 «Мировой рынок — синтез» после расширенного клиентского gate:

- `LANGUAGE_TECH_PASS`
- `READER_SANITY_PASS`
- `COPYWRITER_PASS`
- `TECH_PASS`
- `CLIENT_LANGUAGE_PASS`
- `POST_RENDER_PASS`

Deploy repo: `evskrutyak-bit/brandos-clients`, path `alian-cat/`.

Изменены:

- `alian-cat/M2/M2-02-RYNOK-MIR.html` — заменён placeholder на финальный HTML synthesis (1489 строк / 112 KB).
- `alian-cat/index.html` — карточка `M2-02 · Синтез` переведена в `Готово / v2.0 / 2026-05-23`.

Не менялось:

- `M2-02-RYNOK-MIR-DR.html` — уже опубликованный research layer не трогался.
- `sources.zip` — не обновлялся; source-bundle остаётся отдельным пайплайном.
- Legacy repo `evskrutyak-bit/alien-cat` — не используется.

Live:

- https://clients.brand-os.ru/alian-cat/M2/M2-02-RYNOK-MIR.html?v=3dd5a5f
- https://clients.brand-os.ru/alian-cat/?v=3dd5a5f

Live verification:

- Hub card: `data-version="v2.0"`, `data-status="Готово"`, `data-date="2026-05-23"`.
- Stop-list after copywriter pass: 0 hits на live. Перед commit найден и исправлен последний остаток `премиум-восприятие` → «делает бренд менее дорогим в глазах покупателя».
- Internal kitchen grep на live synthesis: 0 hits.
- Hero stat-cards: ровно 4.

## M2-03 SYNTHESIS publish (2026-05-25, commit `b0fd1bc`)

Опубликован M2-03 «Продукт — синтез» после полного маршрута candidate v1.2:

- `CLIENT_READY_PASS`
- `HTML_BRIEF_ACCEPTED`
- `TECH_PASS`
- `CONTENT_SYNC_PASS`
- `CLIENT_LANGUAGE_PASS`
- `POST_RENDER_PASS`
- `VISUAL_REVIEW_PASS` (`VISUAL_SMOKE_PASS` + `DESIGN_REVIEW_PASS`)
- `HTML_READY 4-pass`
- `DEPLOY_QC_PASS`

Deploy repo: `evskrutyak-bit/brandos-clients`, path `alian-cat/`.

Изменены:

- `alian-cat/M2/M2-03-SYNTHESIS.html` — новый live HTML synthesis.
- `alian-cat/index.html` — карточка M2-03 · Синтез переведена на `M2-03 готов / v1.0 / 25 мая 2026` и ведёт на `M2/M2-03-SYNTHESIS.html`.

Не менялось:

- `M2-03-SYNTHESIS.md` — source MD не трогался на deploy-этапе.
- `M2-03-PRODUKT.html` — старый placeholder не используется как актуальный M2-03 route.
- `M2-03-PRODUKT-DR.html` — глубокое исследование не публиковалось как отдельный клиентский DR layer.
- `sources.zip` — не обновлялся; source-bundle остаётся отдельным пайплайном.
- Legacy repo `evskrutyak-bit/alien-cat` — не используется.

Live:

- https://clients.brand-os.ru/alian-cat/M2/M2-03-SYNTHESIS.html?v=b0fd1bc
- https://clients.brand-os.ru/alian-cat/?v=b0fd1bc

Live verification:

- HTML md5 source/deploy/live: `f0482c97cbe68aaa0c3bfcac0af95ef5`.
- HTML size source/deploy/live: `135287`.
- Hub md5 deploy/live: `1eba012d68338b4d47e6c99f40072b2e`.
- Hub size deploy/live: `77093`.
- HTTP: M2-03 URL `200`, `server: GitHub.com`, `content-length: 135287`.
- Hub card: `href="M2/M2-03-SYNTHESIS.html"`, `data-version="v1.0"`, `data-status="M2-03 готов"`, `data-date="25 мая 2026"`.
- Final live language grep: 0 hits по pipeline-маркерам, запрещённым рамкам v1.2, M3-директивным формулировкам, `noindex/nofollow`.
- Backlink: M2-03 HTML содержит ссылку на хаб `href="../"` с `aria-label="Вернуться в хаб Alien Cat"`.

## M2 package publish (2026-06-06, commit `053dbef`)

Опубликована единая M2-волна после owner-acceptance и pre-deploy проверки ссылок.

Deploy repo: `evskrutyak-bit/brandos-clients`, path `alian-cat/`, branch `main`.

Изменены:

- `alian-cat/index.html` и `alian-cat/BrandOS-Hub.html` — хаб обновлён: M2 = 11 документов, M2 опубликован, M2-04/M2-05/M2-03 research больше не «Пересобирается».
- `alian-cat/M2/M2-03-PRODUKT-DR.html` — опубликован M2-03 RESEARCH, provenance `3b3b2b1a8b770237`.
- `alian-cat/M2/M2-03-SYNTHESIS.html` — micro-fix reveal + provenance `534e6bccdb6745aa`.
- `alian-cat/M2/M2-04-TSA-DR.html` — опубликован M2-04 RESEARCH, provenance `0cd14c9bd5e0747e`.
- `alian-cat/M2/M2-04-TSA.html` — опубликован M2-04 SYNTHESIS, provenance `e23dd6532f4fbfe5`.
- `alian-cat/M2/M2-05-KONKURENTY-DR.html` — опубликован M2-05 RESEARCH, provenance `d6712e0a419130d2`.
- `alian-cat/M2/M2-05-KONKURENTY.html` — опубликован M2-05 SYNTHESIS, provenance `e549415d43ea63d3`.
- `alian-cat/M2/M2-06-KARTINA.html` — опубликована M2-06 KARTINA, provenance `2c60c5ea0468301c`.
- `M2-01-RYNOK-RF.html`, `M2-01-RYNOK-RF-DR.html`, `M2-02-RYNOK-MIR.html` — только link-fix старых битых ссылок внутри M2.

Важно по URL-схеме:

- Сохранена legacy live-схема: `M2-03-PRODUKT-DR.html`, `M2-04-TSA-DR.html`, `M2-05-KONKURENTY-DR.html`.
- Deploy-time URL-remap сделан только в deploy-копиях, не в принятых локальных source HTML/MD:
  - M2-04 SYNTHESIS: `M2-04-RESEARCH.html` → `M2-04-TSA-DR.html`.
  - M2-05 SYNTHESIS: `M2-05-RESEARCH.html` → `M2-05-KONKURENTY-DR.html`.
  - M2-05 RESEARCH: `../../M2-04-ЦА/html/M2-04-RESEARCH.html` → `M2-04-TSA-DR.html`.

Pre-push checks:

- `git diff --check` — PASS.
- Link-resolution по 14 HTML-файлам (`alian-cat/*.html` + `alian-cat/M2/*.html`) — PASS.
- Deploy copies vs local accepted HTML:
  - M2-03 RESEARCH, M2-03 SYNTHESIS, M2-04 RESEARCH, M2-06 KARTINA — byte-identical to accepted local HTML.
  - M2-04 SYNTHESIS, M2-05 RESEARCH, M2-05 SYNTHESIS — отличаются только `href`-строками deploy-time remap.
- Provenance check по 7 source MD → deploy HTML — PASS.
- Hub grep: `Пересобирается`, `развилк`, `локальный хаб перед деплоем`, `Подготовить деплой` — 0.

Live verification:

- Remote `origin/main` = `053dbef9c26066061ac5f4d2a60259501a9a8cc9`.
- Live HEAD с `?v=053dbef` отдаёт новые размеры:
  - Hub `76850`.
  - M2-03 RESEARCH `218619`.
  - M2-03 SYNTHESIS `135916`.
  - M2-04 RESEARCH `172137`.
  - M2-04 SYNTHESIS `74860`.
  - M2-05 RESEARCH `252767`.
  - M2-05 SYNTHESIS `97199`.
  - M2-06 KARTINA `97766`.
- Live content grep:
  - 7 provenance-комментов найдены и совпадают с source MD.
  - Hub содержит `M2 опубликован`; не содержит старых `Пересобирается` / `развилк`.
  - Live remap-ссылки: M2-04 SYNTHESIS → `M2-04-TSA-DR.html`; M2-05 SYNTHESIS → `M2-05-KONKURENTY-DR.html`; M2-05 RESEARCH → `M2-04-TSA-DR.html`.

Не менялось:

- `sources.zip` — не обновлялся; source-bundle остаётся отдельным пайплайном.
- Legacy repo `evskrutyak-bit/alien-cat` — не используется.

## M5 package publish (2026-07-16, commits `e6e3c8c` → `55e2e04` → `edec5fd`)

Опубликован M5 «Конкуренты» после owner-acceptance пяти клиентских MD и owner-gate по пересобранному индексу.

Deploy repo: `evskrutyak-bit/brandos-clients`, path `alian-cat/`, branch `main`.

Изменены:

- `alian-cat/index.html` — хаб пересобран из `alian-cat.config.json`: M0=2, M1=6, M2=11, M3=6, M4=6, M5=5.
- `alian-cat/M5/M5-01-KARTA-POLYA.html`
- `alian-cat/M5/M5-02-01-TEDDY-ROOM.html`
- `alian-cat/M5/M5-02-02-CATSBY.html`
- `alian-cat/M5/M5-03-SRAVNITELNAYA-MATRICA.html`
- `alian-cat/M5/M5-04-SINTEZ-KONKURENTOV.html`

Не менялось:

- M5 source MD — содержание не редактировалось на deploy-этапе.
- M0–M4 live-карточки — сохранены через извлечение текущего live-конфига перед добавлением M5.
- Внутренние M5-файлы не опубликованы: `M5-04-ROUNDTABLE-OUTPUT.md`, `M5-02-research/`, `*-SOURCE-LEDGER.md`, `*-LIVE-FACTPACK-*`, `*-ITERATION-LOG.md`, `*-TASK.md`.
- `sources.zip` — не обновлялся.
- Legacy repo `evskrutyak-bit/alien-cat` — не используется.

Deploy notes:

- Первый deploy: `e6e3c8c hub(alian-cat): M5 Конкуренты`.
- Preview-файл был сразу снят отдельным коммитом: `55e2e04 hub(alian-cat): убрать preview из публикации`; live `index.preview.html` отдаёт `404`.
- После live-QC поправлен мобильный overflow таблиц M5-03/M5-04: `edec5fd hub(alian-cat): правка мобильных таблиц M5`.

Live:

- https://clients.brand-os.ru/alian-cat/
- https://clients.brand-os.ru/alian-cat/M5/M5-01-KARTA-POLYA.html
- https://clients.brand-os.ru/alian-cat/M5/M5-02-01-TEDDY-ROOM.html
- https://clients.brand-os.ru/alian-cat/M5/M5-02-02-CATSBY.html
- https://clients.brand-os.ru/alian-cat/M5/M5-03-SRAVNITELNAYA-MATRICA.html
- https://clients.brand-os.ru/alian-cat/M5/M5-04-SINTEZ-KONKURENTOV.html

Live verification:

- `M5_LIVE_DEPLOY_QC: PASS`: source hash comments совпадают с MD; MD units найдены в live visible text; таблицы/бейджи/ссылки на хаб рендерятся; mobile overflow после patch отсутствует.
- `CLIENT_LANGUAGE_PASS`
  - checker: Codex live verifier — builder != verifier
  - scope: live URL visible text, 5 M5 pages
  - method: real Skill(client-language-guard v1.4) live-grep after publish; StatiCrypt decrypt; visible body+title only
  - findings: 0 blockers по правилам 1–9; false-positive hits reviewed separately (`снять чехол/постирать`, `замерщик/замер до покупки` как сервис конкурента, английские слова как имена брендов/товаров)
  - verdict: PASS
