# M5 — задача Codex: HTML + деплой всего модуля (Alien Cat)

> От методолога проекта AC → Codex. M5 закрыт owner-PASS (все 5 клиентских артефактов). Твоя зона — сборка HTML и деплой (Claude/продакшн на это не отвлекаются). Содержание MD НЕ менять — только рендер. Перед пушем в brandos-clients — owner-gate на пересобранный индекс.

## Контекст
- M5 Конкуренты закрыт содержательно, owner-PASS 2026-07-16. Клиентские MD готовы, разметка `brandos-artifacts` в них есть (`:::table-brandos`, `[[green:]]/[[amber:]]`, frontmatter nav+hero_stats+provenance).
- **CLIENT_LANGUAGE_PASS уже пройден** (guard v1.3, evidence в `M5-04-ITERATION-LOG.md`) — язык чист, не трогать.

## На хаб — только 5 клиентских документов
```
M5-конкуренты/M5-01-KARTA-POLYA.md
M5-конкуренты/M5-02-01-TEDDY-ROOM.md
M5-конкуренты/M5-02-02-CATSBY.md
M5-конкуренты/M5-03-SRAVNITELNAYA-MATRICA.md
M5-конкуренты/M5-04-SINTEZ-KONKURENTOV.md
```
**НЕ публиковать (внутренние):** `M5-04-ROUNDTABLE-OUTPUT.md`, `M5-02-research/`, `*-SOURCE-LEDGER.md`, `*-LIVE-FACTPACK-*`, `*-ITERATION-LOG.md`, `*-TASK.md`, `*-DECISION-FRAME`, `M5-PLAN`.

## Шаг 1 — HTML из АКТУАЛЬНЫХ MD
- Собрать HTML каждого из 5 через `scripts/brandos_artifact_build.py <md> --out html/<name>.html`.
- **Только из текущих MD.** Устаревший `html/M5-01-KARTA-POLYA.html` был удалён (рассинхрон после correction) — собрать свежий. Ни один старый HTML не публиковать.
- Verbatim: текст HTML == текст MD. Проверить badge-рендер (`[[green:]]/[[amber:]]` → span) и таблицы.

## Шаг 2 — конфиг хаба (инфра-долг: его нет)
- `projects/brandos-hub/skill/examples/alian-cat.config.json` **отсутствует** (alian-cat исторически деплоил ты вручную; в `examples/` только picnic/loft). `deploy.sh` без него не отработает.
- Собрать конфиг по образцу `picnic.config.json`/`loft-prostranstvo.config.json`, **точно отражая live M0–M4** (текущие карточки в `/tmp/brandos-clients/alian-cat/` — M0, M1, M2, M3, M4) + добавить блок **M5** (5 карточек: карта поля, досье Teddy Room, досье Catsby, сравнительная матрица, синтез).
- ⚠ `render.py` пересобирает индекс ЦЕЛИКОМ из конфига, а live-индекс StatiCrypt-зашифрован. Неточный конфиг СЛОМАЕТ live M0–M4. Поэтому: собрать конфиг → `render.py` → **показать owner пересобранный `index.html` (M0–M4 не съехали?) ДО пуша.**

## Шаг 3 — deploy
- `deploy.sh alian-cat "hub(alian-cat): M5 Конкуренты"` — render index + bundle MD + staticrypt (пароль `~/.secrets/hub-access.env`) + push в `brandos-clients` → `clients.brand-os.ru/alian-cat/M5/`.
- Пуш в brandos-clients — только после owner-gate по индексу (Шаг 2).

## Шаг 4 — DEPLOY_QC (независимый, не самосертификация)
- После деплоя — независимая проверка live (playwright venv `~/.venvs/playwright`, decrypt in-process, пароль из secrets): source==MD verbatim по 5 документам; badge/таблицы рендерятся; hub-return present; staticrypt-пароль работает; честный мобайл-viewport. Результат — owner.

## Границы
- Содержание MD не менять (только рендер). Язык не трогать (guard пройден).
- Live M0–M4 не ломать (owner-gate на индекс до пуша).
- На хаб — только 5 клиентских; внутренние не публиковать.

*M5 Codex deploy-task · Alien Cat · 2026-07-16 · HTML из актуальных MD + конфиг хаба + deploy + independent QC. M5 owner-PASS, CLIENT_LANGUAGE_PASS пройден.*
