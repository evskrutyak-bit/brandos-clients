# M5-01 SOURCE-LEDGER — провенанс фактов карты конкурентного поля Alien Cat

> Companion к `M5-01-KARTA-POLYA.md`. Каждое число, имя, цена, оператор из тела карты — строка здесь. Живой слой (6 фокус-игроков) — captured_at 2026-07-15, реальные URL из фактпака `M5-01-LIVE-FACTPACK-2026-07-15.md`. Слой M2-05 — source = M2-05 (`_data/M2-05-KONKURENTY.data.md`) плюс первичный URL из его раздела 11. confidence: high — снято/проверено; medium — оговорка/каркас одного игрока; low — самозаявление, не верифицировано.
>
> source_type: `website-scrape` (firecrawl 2026-07-15), `telegram-counter` (t.me/s/), `research-extract` (M2-05), `self-claim` (самозаявление игрока), `brand-file` (brand/ Alien Cat).

| claim_id | player | fact | source_url | source_type | captured_at | confidence | section |
|---|---|---|---|---|---|---|---|
| hero-players-25 | field | 25 игроков в сводном реестре поля | _data/M2-05-KONKURENTY.data.md §2 | research-extract | 2026-07-14 | high | hero |
| hero-clusters-6 | field | 6 кластеров по типу игрока | M5-01 (кластеризация) | derived | 2026-07-15 | high | hero |
| hero-focus-6 | field | 6 игроков в фокусе (Catsby, Teddy, Cat Brand, Hunnkatt, CatioCat, Pet БМФ) | M5-01 AUTHOR-PROMPT | derived | 2026-07-15 | high | hero |
| hero-range-low | TOMEOW | нижняя граница поля 490 ₽ (картонный домик) | tomeow.homezoomarket.ru (M2-05 §1) | research-extract | 2026-07-14 | high | hero |
| hero-range-high | CatioCat | верхняя граница поля 560 000 ₽ (дерево 260 см) | catiocat.ru | website-scrape | 2026-07-15 | medium | hero |
| ac-product | Alien Cat | интерьерное дерево для кошки, ручная работа, настоящая ветвь | brand/profile.md | brand-file | 2026-07-14 | high | intro |
| ac-material | Alien Cat | ветвь, пропитанная льняным маслом, канат намотан вручную, искусственный мех «под сибирскую норку», холлофайбер | brand/profile.md; brand/offer-core.md | brand-file | 2026-07-14 | high | intro |
| ac-line-5 | Alien Cat | 5 форматов: S 20–35 / M 38–57 / L 58–74 / XL 75–100 / XXL от 100 тыс. ₽ | brand/offer-core.md (M3-02) | brand-file | 2026-07-14 | high | intro |
| ac-load-10 | Alien Cat | нагрузка до 10 кг (потолок); вес изделия 15–30 кг | brand/profile.md | brand-file | 2026-07-14 | high | intro |
| ac-load-context | конкуренты | заявленная нагрузка конкурентов 30–45 кг (Catsby 30, Hunnkatt VAKKER 30, Catastrophic ≈38, RHRQuality 40, CatioCat Grand Catio под мейн-куна ~45) — их данные, не спека Alien Cat. Примечание: «40–60 кг» у CatioCat в M2-05 §4 — это ВЕС изделия для доставки, не нагрузка; в агрегат нагрузки не брать | _data/M2-05-KONKURENTY.data.md §3, §9 (нагрузка); §4 (вес изделия) | research-extract | 2026-07-15 | high | intro |
| ac-height | Alien Cat | высота 120–270 см; гарантия 12 мес; приходит собранным | brand/profile.md; brand/offer-core.md | brand-file | 2026-07-14 | high | intro |
| ac-avito | Alien Cat | Avito — основной канал, 20–30 обращений и ~10 заказов в месяц | brand/profile.md | brand-file | 2026-07-14 | high | intro |
| catsby-city | Catsby Family | СПб, скандинавский минимализм | catsby-family.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catsby-price | Catsby Family | цены сайта 16 460–51 500 ₽ (WALL/VINE/STAND/TREE) | catsby-family.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catsby-warranty | Catsby Family | гарантия 6 мес (для 2+ питомцев — 3 мес); возврат 7 дней | catsby-family.ru/guarantee | website-scrape | 2026-07-15 | high | cluster-1 |
| catsby-warranty-fix | Catsby Family | ⚠ backward-исправление M2-05: было «2 года (03.06)» → на 2026-07-15 «6 мес» | catsby-family.ru/guarantee | website-scrape | 2026-07-15 | high | cluster-1 |
| catsby-installments | Catsby Family | оплата частями ×10 мес (сумма платежа зависит от модели; на карточках примеры вида «2179 ₽ × 10 мес») | catsby-family.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catsby-material | Catsby Family | массив дуба 20 мм, хлопковый канат, гипоаллергенный фетр, масла+воск, биоразлагаемая упаковка | catsby-family.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catsby-modular | Catsby Family | «12000+ вариантов», «поменяйте только сточенные столбики», магнитные крышки | catsby-family.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catsby-ar | Catsby Family | примерка в дополненной реальности (/ar), сборка ~12 мин | catsby-family.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catsby-load | Catsby Family | нагрузка динамическая 30 кг (данные Catsby) | catsby-family.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catsby-tg | Catsby Family | Telegram ~1,53 тыс. подписчиков | t.me/s/catsby_family | telegram-counter | 2026-07-15 | high | cluster-1 |
| teddy-city | Teddy Room | Нижний Новгород, лофт/индастриал, столярная мастерская | teddy-room.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| teddy-founder | Teddy Room | основатель назван лично — Александр Ложкин (видео-приветствие) | teddy-room.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| teddy-price | Teddy Room | цены в наличии 10 950–34 750 ₽ (Cat-nail 10 950; PiPiCat 17 890; Double Qvadro 34 390; Loft 34 490; Safe Home до 34 750) | teddy-room.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| teddy-catalog | Teddy Room | кошки и собаки — отдельные разделы; кастом — раздел «Уникальные проекты» | teddy-room.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| teddy-material | Teddy Room | интерьерная фанера + кавказский дуб, эмаль, воск; лофт — ядровая древесина, чугун, сталь | teddy-room.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| teddy-service | Teddy Room | видео-обзоры, группа ВК, подарочные сертификаты | teddy-room.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| pettel | PETTEL | Москва, интерьерные объекты, дизайнер Ольга Швецова, 12 000–20 000 ₽ | design-milk.com; domasan.ru (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-1 |
| murrwoof | Murr and Woof / PURR MURR | Москва, арт-объект, AD Russia 2019; исторически 40 000–150 000+ ₽; активность под старым именем не прослеживается | admagazine.ru 2019 (M2-05 §12) | research-extract | 2026-07-14 | medium | cluster-1 |
| catbrand-city | Cat Brand | Алтай (Новоалтайск/Барнаул), ИП Кобызев Е.Ю., плетение из ивового прута | cat-brand.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catbrand-price | Cat Brand | цены 1 150–62 000 ₽ (домики 7 500–12 800; настенные 11 600–29 000; комплексы 25 000–62 000; Умка 62 000; Тиида+гамак 50 000) | cat-brand.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catbrand-price-fix | Cat Brand | ⚠ M2-05 давал 7 000–31 000 ₽ → на 2026-07-15 шире (1 150–62 000) | cat-brand.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catbrand-material | Cat Brand | ивовый прут, хлопковый канат, краски на водной основе; «канат прослужит до 8 лет»; съёмные чехлы | cat-brand.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| catbrand-reviews | Cat Brand | «Более 1000 отзывов» — заявлено на сайте, не верифицировано | cat-brand.ru | self-claim | 2026-07-15 | low | cluster-1 |
| catbrand-claim | Cat Brand | самозаявление «не имеет аналогов… живут более чем в 10 странах мира» — не верифицировано | cat-brand.ru | self-claim | 2026-07-15 | low | cluster-1 |
| catbrand-channels | Cat Brand | Telegram (t.me/Irina_CatBrand), WhatsApp, ВК (vk.com/cat_brand) | cat-brand.ru | website-scrape | 2026-07-15 | high | cluster-1 |
| katacombas | Katacombas | СПб, «Wabi-Sabi Woodstock», 4 000–8 000 ₽, 2 офлайн-точки, медиа-блог, TikTok | poleznyj.katacombas.com (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-1 |
| kotam | КотаМ | domik-koshki.ru, модульный дизайн, от 2 500 ₽ когтеточка / от 6 000 ₽ настенный, примерка в доп. реальности, 3D, гарантия 12 мес | domik-koshki.ru (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-2 |
| mybobr | Мы Бобры | Москва+МО, «инстинктивный зоодизайн», 3 450–50 000 ₽, монтаж, беговые колёса, гарантия 5 лет | mybobr.ru (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-2 |
| hunnkatt-city | Hunnkatt | Красногорск/Нахабино, работа под заказ, «создаём миры» | hunnkatt.com | website-scrape | 2026-07-15 | high | cluster-2 |
| hunnkatt-price | Hunnkatt | Svart 23 380 ₽; Ekorn MAX 27 660 ₽ (было 29 200); Pute decor 4 300 ₽; Sjakk «цена по запросу»; коридор 4 300–27 660 ₽ | hunnkatt.com | website-scrape | 2026-07-15 | high | cluster-2 |
| hunnkatt-installments | Hunnkatt | оплата частями «Долями»: 4 платежа по 25% | hunnkatt.com | website-scrape | 2026-07-15 | high | cluster-2 |
| hunnkatt-series | Hunnkatt | серии: Home 11, BASIC 15, VAKKER 22, ROM 7, SOLID 8, Kattform 7 | hunnkatt.com | website-scrape | 2026-07-15 | high | cluster-2 |
| hunnkatt-showroom | Hunnkatt | шоу-рум Красногорск, Нахабино, Новая Лесная 9к2, ВТ–СБ 9–18 | hunnkatt.com | website-scrape | 2026-07-15 | high | cluster-2 |
| hunnkatt-tg | Hunnkatt | Telegram основной канал (t.me/hunnkattshop), визуализация бесплатно, менеджер зоопсихолог+дизайнер; счётчик подписчиков — нет данных | hunnkatt.com; t.me/s/hunnkattshop | website-scrape | 2026-07-15 | high | cluster-2 |
| hunnkatt-load | Hunnkatt | серия VAKKER до 30 кг (данные Hunnkatt) | hunnkatt.com (M2-05 §2) | research-extract | 2026-07-14 | medium | cluster-2 |
| pushok | Пушок | СПб, 19 лет, собственное производство, ~15 500–38 700 ₽, усиленная серия на 3 ножки, видео на 20+ моделей | pushok-spb.ru (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-2 |
| catiocat-price | CatioCat | цены 98 000–560 000 ₽ (Альберо 98–123 тыс.; Катио 180 см 148 450; Тиволи 225 см 297 350; 260 см 560 000) | catiocat.ru | website-scrape | 2026-07-15 | high | cluster-3 |
| catiocat-price-fix | CatioCat | ⚠ M2-05 давал 146 550–297 350 ₽ типовые → на 2026-07-15 шире вниз и вверх (98 000–560 000) | catiocat.ru | website-scrape | 2026-07-15 | high | cluster-3 |
| catiocat-mainecoon | CatioCat | раздел «Мейн-Кун»: «каждое дерево масштабируется для Мейн-Куна» | catiocat.ru | website-scrape | 2026-07-15 | high | cluster-3 |
| catiocat-material | CatioCat | натуральный ствол, массив сосны/лиственницы, силиконовая листва RealTouch, масла Borma Wachs/SayerLack; доставка собранным | catiocat.ru; catiocat.ru/modeli-dereviev (M2-05 §2) | research-extract | 2026-07-15 | high | cluster-3 |
| catiocat-caveat | CatioCat | ультра-каркас 98–560 тыс. ₽ не доказан как платёжеспособный сегмент РФ | _data/M2-06-KARTINA.data.md §5 | research-extract | 2026-07-15 | medium | cluster-3 |
| petbmf-who | Pet БМФ / БРИСИ | Москва, БРИСИ «Бабаевская Мебельная Фабрика», производитель | pet.b-mf.ru | website-scrape | 2026-07-15 | high | cluster-4 |
| petbmf-price | Pet БМФ / БРИСИ | цены 4 999–19 999 ₽ (Мульти-1 4 999; Атланта 9 999; Комфорт-Ультра 19 999) | pet.b-mf.ru | website-scrape | 2026-07-15 | high | cluster-4 |
| petbmf-service | Pet БМФ / БРИСИ | индивидуальный заказ + вызов замерщика; ремонт своих изделий; сменные элементы; бонус 5%; экспресс-доставка+сборка; режим 8:00–23:00 | pet.b-mf.ru | website-scrape | 2026-07-15 | high | cluster-4 |
| petbmf-material | Pet БМФ / БРИСИ | материал ковролин/плюш (масс-сегмент) | pet.b-mf.ru | website-scrape | 2026-07-15 | high | cluster-4 |
| petbmf-channels | Pet БМФ / БРИСИ | WhatsApp/Viber/Telegram, Instagram (pet.bmf), ВК (pet_bmf), YouTube | pet.b-mf.ru | website-scrape | 2026-07-15 | high | cluster-4 |
| petbmf-claim | Pet БМФ / БРИСИ | самозаявления «Первыми в Москве» / «Единственная в СНГ» — не верифицированы, на главной 2026-07-15 не выведены | pet.b-mf.ru (M2-05 §4) | self-claim | 2026-07-15 | low | cluster-4 |
| tomeow | TOMEOW / ТУМЯУ | масс-картон, 490 ₽, картон 6–12 мес, самозаявление «№1» (не верифицировано) | tomeow.homezoomarket.ru (M2-05 §1) | research-extract | 2026-07-14 | low | cluster-5 |
| artcarton | ArtCarton | масс-картон, 2 090–3 890 ₽, картон 3 года, бонусы | artcarton.ru (M2-05 §1) | research-extract | 2026-07-14 | high | cluster-5 |
| komodpet | Komod-Pet | кубы МДФ+шпон, коряги под заказ, цена нет данных | komod-pet.ru (M2-05 §1) | research-extract | 2026-07-14 | medium | cluster-5 |
| kotoschastye | KotoSчастье | смежный игрок реестра, данных мало (наблюдательный список) | _data/M2-05-KONKURENTY.data.md §1 | research-extract | 2026-07-14 | low | cluster-5 |
| kotomoto-yocat | KotoMoto / yocat | новые, наблюдательный список, данных мало | kotomoto.store; yocat.ru (M2-05 §1) | research-extract | 2026-07-14 | low | cluster-5 |
| pettails | PetTails | массмаркет, плюшевые комплексы, маркетплейсы | _data/M2-05-KONKURENTY.data.md §1 | research-extract | 2026-07-14 | medium | cluster-5 |
| trixie | Trixie | импорт, 1 499–43 020 ₽, плюш/башни, гарантия 1 год | десяток ритейлеров (M2-05 §1,§6) | research-extract | 2026-07-14 | high | cluster-5 |
| catit | Catit Vesper | импорт (Испания), 1 452–14 872 ₽, кубы МДФ+шпон, memory foam, Ozon Сплит | дропшипперы (M2-05 §1) | research-extract | 2026-07-14 | high | cluster-5 |
| ikea | IKEA Lurvig | массмаркет, МДФ+шпон, цена нет данных | зоомагазины (M2-05 §1) | research-extract | 2026-07-14 | medium | cluster-5 |
| zoonik | Зооник | массмаркет, плюш, 1 954–3 597 ₽ | magizoo.ru (M2-05 §1) | research-extract | 2026-07-14 | high | cluster-5 |
| avito-masters | мастера Avito / Ярмарка Мастеров | коряги под заказ, 2 100–27 000+ ₽ | Avito, Ярмарка Мастеров (M2-05 §1) | research-extract | 2026-07-14 | medium | cluster-5 |
| tuftpaw | Tuft+Paw | США, $130–500, дизайнерский лоток Cove $199 | tuftandpaw.com (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| refinedfeline | The Refined Feline | США, дизайнерская мебель, цена нет данных | M2-05 §2 | research-extract | 2026-07-14 | low | cluster-6 |
| rhrquality | RHRQuality | Нидерланды/Великобритания, €169–589 + £529, крупные породы до 40 кг (их данные) | rhrpets.com/co.uk (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| hauspanther | Hauspanther | США, медиа+продукт, цена нет данных | M2-05 §2 | research-extract | 2026-07-14 | medium | cluster-6 |
| lucybalu | LucyBalu | Германия, дизайн-коллаборации (Karl Lagerfeld/sieger/Krüger), полной матрицы нет | lucybalu.com (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| miacara | MiaCara | Германия, €19.95–599+, 52 продукта, 10+ дизайнеров, Torre от Regina Mol | miacara.com (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| goldtatze | Goldtatze | Германия, €119.90–599+, настенно-потолочные, гарантия 5 лет, сизаль из агавы | goldtatze.de (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| catastrophic | Catastrophic Creations | США, $33–877, настенная система, патент-крепёж, ≈38 кг/полка (их данные) | catastrophicreations.com (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| kbspets | KBSPETS | США, $299+, «все элементы сменные», возврат 45 дней, Climate Neutral | kbspets.com (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| mau | Mau | США, $299–699, «все элементы сменные», «дерево за каждую покупку» | maupets.com (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| armarkat | Armarkat | США, $27–54+, гарантия 6 мес, бесплатные сменные элементы | armarkat.com (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| rinn | RINN NEKO | Япония, ¥1 000 000, греческий мрамор, лимит 22 шт/год | rinn.co.jp/neko (M2-05 §2) | research-extract | 2026-07-14 | high | cluster-6 |
| hicat | Hicat | Великобритания, под заказ от пола до потолка, AVM Wool, высота от 222 см, цена нет данных | hicat.co.uk (M2-05 §2) | research-extract | 2026-07-14 | medium | cluster-6 |
| ws-litter | field | тумбы под лоток в РФ почти пусты; закрытую тумбу-туалет держит только Hunnkatt (Skap) | _data/M2-05 §7; M2-06 §1 | research-extract | 2026-07-14 | high | whitespace |
| ws-litter-design | field | дизайнерский лоток уровня Tuft+Paw Cove ($199) в РФ на 2026 не представлен | _data/M2-05 §7 (тренд 8) | research-extract | 2026-07-14 | high | whitespace |
| ws-wall | field | настенные «без сверления» для аренды в РФ слабо заняты (сигнал слабый) | _data/M2-06 §2 (Г12) | research-extract | 2026-07-15 | medium | whitespace |
| ws-parts | field | сменные элементы как отдельная линия в РФ у немногих (Pet БМФ, КотаМ, Catsby частично); в США — стандарт | _data/M2-05 §9 п.5 | research-extract | 2026-07-14 | high | whitespace |
| ws-eco | field | публичный язык экологичности в премиуме РФ не отстроен | _data/M2-06 §5 | research-extract | 2026-07-15 | medium | whitespace |
| ws-line-arch | field | целостный мебельный язык + публичная архитектура линейки нигде не артикулированы (плоская витрина у всех) | _data/M2-06 §1 (П1,П2) | research-extract | 2026-07-15 | high | whitespace |
| ws-ar | field | примерка в дополненной реальности — норма канала (Catsby, КотаМ, Пушок), не преимущество | _data/M2-05 §7 (тренд 4); M2-06 §5 | research-extract | 2026-07-14 | high | whitespace |

---

## Разрешение 5 расхождений с M2-05 (в пользу живого фактпака 2026-07-15)

| # | Расхождение | M2-05 | Фактпак 2026-07-15 (верно) | claim_id | Как отражено в карте |
|---|---|---|---|---|---|
| 1 | Catsby гарантия | «2 года (03.06)» | 6 мес (для 2+ кошек — 3 мес) | catsby-warranty, catsby-warranty-fix | таблица и карточка Catsby: гарантия 6 мес; в «Осторожно» помечено, что M2-05 устарел |
| 2 | Catsby цена сайта | 16 460–41 772 ₽ | 16 460–51 500 ₽ | catsby-price | таблица и карточка: коридор до 51 500 ₽ |
| 3 | CatioCat цена | 146 550–297 350 ₽ типовые | 98 000–560 000 ₽ | catiocat-price, catiocat-price-fix | таблица и карточка: 98 000–560 000 ₽; hero-range-high = 560 000 ₽ |
| 4 | Cat Brand цена | 7 000–31 000 ₽ | 1 150–62 000 ₽ | catbrand-price, catbrand-price-fix | таблица и карточка: 1 150–62 000 ₽, флагман Умка 62 000 ₽ |
| 5 | Teddy Room основатель | без имени | Александр Ложкин | teddy-founder | карточка Teddy Room: основатель назван лично |

*M5-01 SOURCE-LEDGER · Alien Cat · 2026-07-15 · живой слой из фактпака (реальные URL, captured_at 2026-07-15), слой M2-05 с первичными URL из его раздела 11 · рабочий companion, не клиентский артефакт.*
