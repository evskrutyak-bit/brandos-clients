# M5-02 SOURCE LEDGER — Catsby Family

> Проверяемое сырьё: каждый факт/число из `catsby-RESEARCH.md` = строка. player = catsby везде. captured_at = 2026-07-15 везде (живой ресёрч). confidence: high (снято дословно с первоисточника), med (косвенно/сниппет), low (одиночный сигнал/самозаявление). section = блок RESEARCH.

| claim_id | fact | source_url | source_type | confidence | section |
|---|---|---|---|---|---|
| CB-01 | Юрлицо ООО «КЭТСБИ ФЭМИЛИ», на Авито с апреля 2021 | https://www.avito.ru/brands/i201960281 | marketplace/seller-page | high | 0 |
| CB-02 | Каналы: сайт, ВК, Telegram, WhatsApp, Max, тел +7(812)223-51-26 | https://catsby-family.ru | brand-site | high | 0 |
| CB-03 | Город СПб; адрес шоурума Б. Сампсониевский пр., 60Р (Выборгская) | https://yandex.ru/maps/org/ketsbi_femili/53739572243/ | maps | high | 0 |
| CB-04 | Модель: прямые продажи + маркетплейсы + Avito | https://catsby-family.ru + https://vk.com/catsby_family | brand-site/social | high | 0 |
| CB-05 | «ЧПУ-производство» на сайте прямо не заявлено (нет данных) | https://catsby-family.ru | brand-site | med | 0 |
| CB-06 | Имя основателя/лица бренда публично не выведено | https://catsby-family.ru | brand-site | med | 0 |
| CB-07 | WALL 16 460–45 440 ₽ (2–4 уровня), рассрочка ×10 мес | https://catsby-family.ru | brand-site | high | 1 |
| CB-08 | VINE 20 740–48 090 ₽ (2–4 уровня) | https://catsby-family.ru | brand-site | high | 1 |
| CB-09 | STAND 21 790–32 690 ₽ | https://catsby-family.ru | brand-site | high | 1 |
| CB-10 | TREE 34 810–51 500 ₽ (враспор, без сверления, 4 ур.) | https://catsby-family.ru | brand-site | high | 1 |
| CB-11 | Итоговый коридор сайта ~16 460–51 500 ₽ | https://catsby-family.ru | brand-site | high | 1 |
| CB-12 | Ozon-витрина (VK-market): POST 9 018 ₽ (было 22 980) | https://vk.com/catsby_family | marketplace-embed | high | 1 |
| CB-13 | Ozon-витрина: STAND-лежанка 16 320 ₽ (было 52 012 — раздутый якорь) | https://vk.com/catsby_family | marketplace-embed | high | 1 |
| CB-14 | Ozon-витрина: комплекс с домиком 10 151 ₽ (было 31 103) | https://vk.com/catsby_family | marketplace-embed | high | 1 |
| CB-15 | Ozon-витрина: VINE 118 см 20 960 ₽; 145 см 27 650 ₽; 175 см 28 310 ₽ | https://vk.com/catsby_family | marketplace-embed | high | 1 |
| CB-16 | Avito: лоты «старого образца»/фанерная версия 6 000–11 000 ₽ | https://www.avito.ru/brands/i201960281 | marketplace/seller-page | high | 1 |
| CB-17 | Avito-описание: «Комплекс старого образца… у старого образца фетр вклеен и лежанки нет. Толщина каната 6 мм» | https://www.avito.ru/brands/i201960281 | marketplace/seller-page | high | 1 |
| CB-18 | Wildberries тег «Когтеточки catsby family — 30 товаров» | https://www.wildberries.ru/catalog/tags/kogtetoczki-i-igrovye-kompleksy-catsby-family | marketplace | med | 1 |
| CB-19 | WB число отзывов/цены — нет данных (JS-оболочка) | https://www.wildberries.ru/catalog/tags/kogtetoczki-i-igrovye-kompleksy-catsby-family | marketplace | low | 1 |
| CB-20 | Гарантия 6 мес; для 2+ питомцев 3 мес | https://catsby-family.ru/guarantee | brand-site | high | 1 |
| CB-21 | Гарантия покрывает прорыв верёвки/фурнитуру/каркас; не покрывает износ и эстетику | https://catsby-family.ru/guarantee | brand-site | high | 1 |
| CB-22 | Возврат 7 дней надлежащего качества, перевозку платит клиент | https://catsby-family.ru/guarantee | brand-site | high | 1 |
| CB-23 | Возврат ненадлежащего — care@catsby-family.ru, 3 раб. дня, замена 14 (экспертиза 20) | https://catsby-family.ru/guarantee | brand-site | high | 1 |
| CB-24 | Рассрочка ×10 мес; в отзыве упомянута Халва | https://catsby-family.ru + Яндекс отзыв Виктория Р. | brand-site/maps | high | 1 |
| CB-25 | Сборка ~12 мин, инструмент+крепёж в комплекте, дюбели не входят | https://catsby-family.ru | brand-site | high | 1 |
| CB-26 | Сайт HTTP 200, каталог с вариациями, FAQ 14 вопросов, /ar, /installment, /guarantee | https://catsby-family.ru/faq | brand-site | high | 2 |
| CB-27 | Слоганы: «Современная мебель для кошек», «Предмет искусства в вашем доме», «в скандинавском стиле» | https://catsby-family.ru | brand-site | high | 2 |
| CB-28 | ВКонтакте — 2,4 тыс. подписчиков (2.4K), 750 постов, витрина товаров | https://vk.com/catsby_family | social | high | 2 |
| CB-29 | Telegram — 1,53 тыс. подписчиков (1.53K) + бот catsby_family_bot | https://t.me/s/catsby_family | social | high | 2 |
| CB-30 | Instagram существует, число подписчиков — нет данных | https://www.instagram.com/catsby_family/ | social | low | 2 |
| CB-31 | Avito — 5,0 из 5, 46 отзывов (44×5★, 2×4★), 372 подписчика, «Надёжный продавец» | https://www.avito.ru/brands/i201960281 | marketplace/seller-page | high | 2 |
| CB-32 | Ozon ROLL натуральный дуб (id 238749759) — 226 отзывов | https://www.ozon.ru/product/...roll-238749759/reviews/ | marketplace | med | 2 |
| CB-33 | Ozon агрегированное число отзывов/рейтинг — нет данных (капча/403) | https://www.ozon.ru/category/...catsby-family-100486179/review/ | marketplace | low | 2 |
| CB-34 | Яндекс.Карты — 95 отзывов, рейтинг ~5 | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 2 |
| CB-35 | irecommend: WALL 6 отз., TREE 5 отз. (ср.5), миски 7 отз. | https://irecommend.ru/catalog/list/46-2298696-2311704 | review-site | high | 2 |
| CB-36 | Telegram частота ~2–4/нед, контент обучающий+продуктовый+промо, тон тёплый | https://t.me/s/catsby_family | social | med | 3 |
| CB-37 | Промо: миска в подарок при заказе от 25 000 ₽, промокод ЛЕТО, до 15.07.2026 | https://vk.com/catsby_family | social | high | 3 |
| CB-38 | Кросс-постинг/коллаб с PETKIT RUSSIA, PETHOUSE в ленте ВК | https://vk.com/catsby_family | social | high | 3 |
| CB-39 | AR (/ar): веб-примерка ~19 каталожных SKU через смартфон, не конфигуратор | https://catsby-family.ru/ar | brand-site | high | 3 |
| CB-40 | AR не уникален для РФ (также КотаМ, Пушок) — предохранитель | _data/M2-05 | prior-research | med | 3 |
| CB-41 | VoC+ «Качество дерева превосходное… всё устойчивое» — Мария Якунина, Яндекс, 25 апр | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-42 | VoC+ «мерседес в мире кошачьих когтеточек… всё продуманно» — Avito | https://www.avito.ru/brands/i201960281 | marketplace | high | 4 |
| CB-43 | VoC+ «нет убогого ковролина… денег своих стоит» — «1462», сайт | https://catsby-family.ru | brand-site | med | 4 |
| CB-44 | VoC+ «сделан из массива, другие из фанеры, что удешевляет вид» — Ксения Сокол, Яндекс, 10 авг 2025 | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-45 | VoC+ «инструкция, отвёртка и ключ… примерить в доп. реальности» — Анастасия П., Яндекс, 25 мар 2023 | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-46 | VoC+ «единственная фирма, которая делает чёрный канат… рассрочка с халвой» — Виктория Р., Яндекс, 5 янв 2023 | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-47 | VoC+ «за 3 года канат выглядит отлично» — Ксения, Яндекс, 31 дек 2025; ср. cate s. «не распушились» | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-48 | VoC+ «менеджер сам позвонил уточнить расчёт… докупить и подогнать под потолок» — Алевтина К., Яндекс, 4 фев 2025 | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-49 | VoC+ доставка/упаковка «материала не пожалели», «вкусные коробки» [КЛАСТЕР] | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-50 | VoC− «сорвана резьба у детали… сборка трудоёмче ожидаемого» — Елена Царицына, Яндекс, 25 ноя 2025 (4★) | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-51 | VoC− «вибрирует… резьба на столбе навинчивается под углом» — Алевтина К., Яндекс, 4 фев 2025 | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-52 | VoC− «дюбеля коротковаты»; «отверстие под шуруп шире шурупа» [КЛАСТЕР крепёж] — Avito | https://www.avito.ru/brands/i201960281 | marketplace | high | 4 |
| CB-53 | VoC− «когтеточка короче заявленной на 10 см… описание оставляют прежним» — Avito (критично) | https://www.avito.ru/brands/i201960281 | marketplace | high | 4 |
| CB-54 | VoC− «клиентоориентированность на низком уровне… подарок в обмен на отзыв… не лучше других в ценовом диапазоне» — Наталья Смирнова, Яндекс, 14 ноя 2025 (3★) | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-55 | VoC− «больше цветов ткани, пока только серый» (Ксения Сокол); «шире ассортимент домиков/лежанок» (Dina L.) | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-56 | VoC− «платформы маловаты» для крупного кота — irecommend TREE | https://irecommend.ru/content/khoroshii-i-nadezhnyi-igrovoi-dom-dlya-kotov | review-site | high | 4 |
| CB-57 | VoC− фетровый домик часто снимают («кот не оценил»/«не помещается») [КЛАСТЕР] | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-58 | VoC− цена высокая, «но того стоит» [КЛАСТЕР сквозной] | https://yandex.ru/maps/org/ketsbi_femili/53739572243/reviews/ | maps | high | 4 |
| CB-59 | Индивидуализация: цвет дуба ×3 × канат ×2 × уровни 2–4 × полки канат/фетр × подгон высоты; раздела «кастом» на сайте нет | https://catsby-family.ru/faq | brand-site | high | 6 |
| CB-60 | Нагрузка 30 кг = грузоподъёмность («выдерживает динамическую нагрузку 30 кг»), не вес изделия | https://catsby-family.ru | brand-site | high | 7 |
| CB-61 | Подтверждение 30 кг = вес питомцев: «выдерживают пушистиков весом до 30 кг… даже 5 кошек»; вес изделия WALL-4 ~16 кг | https://irecommend.ru/content/poleznaya-zona-dlya-kotikov-i-kogti-mozhno-potochit-i-pospat-i-poprygat-i-spryatatsya-v-domi | review-site | high | 7 |
| CB-62 | Самозаявления: «12000+ вариантов», «предмет искусства», «двойное встречное плетение каната» — не измерены | https://catsby-family.ru | brand-site | med | 7 |

*Ledger: 62 строки. player=catsby, captured_at=2026-07-15. Ozon/WB счётчики частично [НЕТ ДАННЫХ] из-за защиты (капча/JS). Число отзывов по площадкам: Avito 46, Яндекс 95, Ozon ROLL 226, irecommend WALL 6/TREE 5/миски 7, WB — нет данных.*
