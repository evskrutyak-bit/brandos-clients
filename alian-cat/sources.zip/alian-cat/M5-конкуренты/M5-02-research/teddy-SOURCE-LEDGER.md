# teddy-SOURCE-LEDGER — Teddy Room (M5-02, Alien Cat)

> Каждое число/цена/подписчики/рейтинг/дата — отдельная строка. Player = Teddy Room во всех. captured_at = 2026-07-15.
> source_type: site=сайт бренда; site-catalog=подстраница каталога; pr-advertorial=рекламная статья; social=соцсеть/видео; marketplace=Avito/VK-маркет; maps=Яндекс Карты; directory=каталог-агрегатор.
> confidence: high=прямой первоисточник/бренд; med=агрегатор или рекламный материал (самозаявление); low=сниппет/косвенно.

| claim_id | fact | source_url | source_type | captured_at | confidence | section |
|---|---|---|---|---|---|---|
| TR-01 | Юрлицо: ИП Ложкин Александр Сергеевич | https://teddy-room.ru/contacts | site | 2026-07-15 | high | Профиль |
| TR-02 | Основатель Александр Ложкин — лицо бренда (видео-приветствие, подпись) | https://teddy-room.ru/ | site | 2026-07-15 | high | Профиль |
| TR-03 | Город Нижний Новгород | https://www.kp.ru/putevoditel/spetsproekty/teddy-room/ | pr-advertorial | 2026-07-15 | high | Профиль |
| TR-04 | Офлайн-адрес: Нижний Новгород, ул. Родионова, 181А; режим 10:00–20:00; самовывоз | https://yandex.md/maps/org/teddyroom/61032674275/ ; https://www.vippe.ru/...-teddyroom | maps/directory | 2026-07-15 | med | Профиль |
| TR-05 | Старт 2016 (питомник морских свинок → мебель); «за 5 лет 60 изделий» | https://teddy-room.ru/about-us | site | 2026-07-15 | high | Профиль |
| TR-06 | На Avito с января 2019 | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | high | Профиль |
| TR-07 | «+2500 котиков и собак» (самозаявление) | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | med | Профиль |
| TR-08 | Когтеточка Cat-nail concept — 10 950 ₽ (в наличии) | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-09 | Qvadro Wood House 11 970 ₽; Plus Gray 17 970 ₽; Qvadro Table 15 970 ₽ | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-10 | Домик Little White Future — 12 380 ₽ | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-11 | Плетёный домик Spider Future Black — 11 690 ₽ | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-12 | Тумба под лоток PiPiCat House Door White — 17 890 ₽ | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-13 | Тумба под лоток PiPiCat House Door Oak — 23 890 ₽ (Out of stock) | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-14 | Комплекс Oak Cat Bobbin — 23 790 ₽ | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-15 | Safe Home Wood 32 890 ₽; Gray 34 680 ₽; вариация 34 750 ₽ (5 размеров) | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-16 | Industrial Craft Loft (домик-тумба) — 34 490 ₽ | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-17 | Double Qvadro Wood House — 34 390 ₽ (новинки + под заказ) | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-18 | Коридор «в наличии» ~10 950–34 750 ₽ | https://teddy-room.ru/ | site | 2026-07-15 | high | Цены |
| TR-19 | «Уникальные проекты»/индивидуальные — часть «цена по запросу» (VictorianEngland, Console Oak, Safe Slope, Loft-лежанка) | https://teddy-room.ru/catalog/products-for-cats/individual-projects | site-catalog | 2026-07-15 | high | Цены |
| TR-20 | VK-маркет — 39 товаров; Тумба-вольер Safe Home Wood black 28 750 ₽ | https://vk.com/market-139881468 | marketplace | 2026-07-15 | high | Цены |
| TR-21 | Материалы: интерьерная фанера + кавказский дуб, эмаль, мебельный воск; лофт — ядровая древесина, чугунные фитинги, стальные трубы; плетёнка — бумажная лоза | https://teddy-room.ru/ | site | 2026-07-15 | high | Материалы |
| TR-22 | «протестировали 10 видов покрытий; более 40 домашних животных» (самозаявление) | https://mebel-dlya-zhivotnih.orgs.biz/ | directory | 2026-07-15 | med | Материалы |
| TR-23 | Нагрузка: «тумбы для питомцев весом до 12–14 кг» (вес питомца, не грузоподъёмность полки/вес изделия) | https://vkvideo.ru/@teddyroomnn | social | 2026-07-15 | high | Нагрузка |
| TR-24 | Числовой грузоподъёмности комплексов Teddy не заявляет | https://teddy-room.ru/ | site | 2026-07-15 | med | Нагрузка |
| TR-25 | Сайт Tilda, HTTP 200, живой; тел. +7 (996) 004-93-30 | https://teddy-room.ru/ | site | 2026-07-15 | high | Где виден |
| TR-26 | VK-группа vk.com/teddyroomnn — ~2,8 тыс. подписчиков, 661 запись | https://vk.com/teddyroomnn | social | 2026-07-15 | med | Где виден |
| TR-27 | VK Видео teddyroomnn — 2 771 подписчик, 119 видео, 20 154 просмотра, создан 10.02.2017 | https://vkvideo.ru/@teddyroomnn | social | 2026-07-15 | high | Где виден |
| TR-28 | YouTube-канал «Teddy Room Мебель» существует | https://www.youtube.com/channel/UCCFD7y0MxLactVD34cfGfbQ | social | 2026-07-15 | high | Где виден |
| TR-29 | Pinterest InstTeddyRoomnn существует | https://www.pinterest.com/instteddyroomnn/ | social | 2026-07-15 | high | Где виден |
| TR-30 | Avito бренд-страница: 5,0 / 24 оценки, 483 подписчика, 11 покупок с Авито Доставкой, 462 завершённых объявления | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | high | Где виден / VoC |
| TR-31 | Ozon/WB/Яндекс Маркет под брендом TeddyRoom на 2026-07-15 не обнаружено | (Firecrawl search Ozon/WB/Маркет) | marketplace | 2026-07-15 | med | Где виден |
| TR-32 | KP-адверториал 28.04.2025, маркер «Реклама ООО Яндекс» | https://www.kp.ru/putevoditel/spetsproekty/teddy-room/ | pr-advertorial | 2026-07-15 | high | Где виден / Каналы |
| TR-33 | Каналы: Яндекс Директ 5+ лет, Яндекс Бизнес, таргет, SEO, контент-маркетинг; сайт — основной приём | https://www.kp.ru/putevoditel/spetsproekty/teddy-room/ | pr-advertorial | 2026-07-15 | med | Каналы |
| TR-34 | Метрики 2024 (Директ, самозаявление): 429 000+ показов РСЯ, 23 000+ поиск, 4000+ переходов, лид 1224 ₽ | https://www.kp.ru/putevoditel/spetsproekty/teddy-room/ | pr-advertorial | 2026-07-15 | med | Каналы |
| TR-35 | Партнёрский канал: питомники, зоомагазины, блогеры | https://www.kp.ru/putevoditel/spetsproekty/teddy-room/ | pr-advertorial | 2026-07-15 | med | Каналы |
| TR-36 | Планы 2025: выход в офлайн-ретейл + модернизация производства; вывод неэффективных позиций | https://www.kp.ru/putevoditel/spetsproekty/teddy-room/ | pr-advertorial | 2026-07-15 | med | Каналы |
| TR-37 | Кастом = раздел «Уникальные проекты» + форма «заказать уникальное изделие»; примеры в видео (лофт, колеровка, угловой домик) | https://teddy-room.ru/ ; https://vkvideo.ru/@teddyroomnn | site/social | 2026-07-15 | high | Каналы/кастом |
| TR-38 | Слоганы: «Интерьерные решения для дома, где есть место питомцам»; «Создавать лучшую в мире мебель для людей и их питомцев» | https://teddy-room.ru/ ; https://teddy-room.ru/about-us | site | 2026-07-15 | high | Контент |
| TR-39 | Avito рейтинг 5,0 (23×5★, 1×4★ из 24) | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | high | VoC |
| TR-40 | Яндекс Карты: 5,0; 41 оценка; 32 отзыва; Качество 100%(28)/Кастом 100%(17)/Персонал 100%(13) | https://yandex.md/maps/org/teddyroom/61032674275/reviews/ | maps | 2026-07-15 | high | VoC |
| TR-41 | Каталог xtool.ru: 76 оценок; плюсы Качество 85% / Кастом 48% / Персонал 41% | https://nijniy-novgorod.xtool.ru/teddyroom/ | directory | 2026-07-15 | med | VoC |
| TR-42 | Минус (дословно): «немного задержали по срокам, но это не критично» | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | high | VoC-минус |
| TR-43 | Минус (дословно): сломалась полка через полгода → Александр прислал замену | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | high | VoC-минус |
| TR-44 | Минус (дословно): кот не пошёл в тумбу-туалет (не брак; продавец объяснил в ответе) | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | high | VoC-минус |
| TR-45 | Плюс-кластер: качество/долговечность (домику 6 лет / когтеточке 3 года «как новый») | https://yandex.md/maps/org/teddyroom/61032674275/reviews/ | maps | 2026-07-15 | high | VoC-плюс |
| TR-46 | Плюс-кластер: аккуратная упаковка + лёгкая сборка ~15 мин | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | high | VoC-плюс |
| TR-47 | Плюс-кластер: личный сервис основателя, ответы на отзывы, подарок при доставке | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | high | VoC-плюс |
| TR-48 | «100+ видео-отзывов» РЕФУТ: 119 видео всего, ~9 видео-отзывов (плейлист «Отзывы»); ~110 ФОТО-отзывов на /reviews (2018–2021) | https://vkvideo.ru/@teddyroomnn ; https://teddy-room.ru/reviews | social/site | 2026-07-15 | high | Спорное |
| TR-49 | Срок кастома (единичный отзыв): «чуть больше 2 недель» на тумбу под лоток | https://www.avito.ru/brands/i155526909 | marketplace | 2026-07-15 | med | Спорное |
| TR-50 | «Рассрочка» числится в способах оплаты каталога-агрегатора; на сайте бренда как обещание не выведена | https://nijniy-novgorod.xtool.ru/teddyroom/ | directory | 2026-07-15 | low | Спорное |
| TR-51 | Гарантия/возврат Teddy прямым текстом на сайте не сняты — нет данных | https://teddy-room.ru/ | site | 2026-07-15 | low | Спорное |

*teddy-SOURCE-LEDGER.md · 51 строк · Alien Cat M5-02 · Teddy Room · 2026-07-15.*
