# alian-cat — исходники проекта BrandOS

Все артефакты в Markdown (для loft — также docx/pdf первоисточников DR).
Загружай в AI-инструменты команды как контекст для работы со своим брендом.

## Что внутри

- `alian-cat/` — артефакты по модулям M0-M11 (структура повторяет хаб)
- `manifest.json` — метаданные пакета (slug, hub_version, generated_at, files)


## Поддержка

Хаб с интерактивной версией: https://clients.brand-os.ru/alian-cat/
Контакт: BrandOS · brand-os.ru
